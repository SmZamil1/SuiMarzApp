package com.smarzbd.app.api;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.smarzbd.app.utils.Constants;
import com.smarzbd.app.utils.SessionManager;

import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {

    private static final String TAG    = "ApiClient";
    private static final String MARKER = "SMRZOK";   // unique wrapper added by PHP

    private static Retrofit       retrofit       = null;
    private static SessionManager sessionManager = null;

    public static ApiService getService(Context context) {
        if (retrofit == null || sessionManager == null) {
            sessionManager = new SessionManager(context);

            // ── Cookie interceptor ────────────────────────────────
            Interceptor cookieInterceptor = chain -> {
                String cookie = sessionManager.getSessionCookie();
                Request.Builder builder = chain.request().newBuilder();
                if (cookie != null && !cookie.isEmpty())
                    builder.addHeader("Cookie", cookie);
                // Look like a real Android app browser
                builder.addHeader("User-Agent",
                    "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/91.0 Mobile Safari/537.36");
                Request  request  = builder.build();
                Response response = chain.proceed(request);
                String setCookie  = response.header("Set-Cookie");
                if (setCookie != null && setCookie.contains("PHPSESSID"))
                    sessionManager.saveSessionCookie(setCookie.split(";")[0]);
                return response;
            };

            // ── SMRZOK extractor ─────────────────────────────────
            // PHP wraps every response: SMRZOK{"success":...}SMRZOK
            // InfinityFree will NEVER inject the string "SMRZOK"
            // so extraction is 100% reliable regardless of what they inject.
            Interceptor smrzExtractor = chain -> {
                Response response = chain.proceed(chain.request());
                try {
                    ResponseBody body = response.body();
                    if (body == null) return response;

                    String raw = body.string();
                    Log.d(TAG, "RAW[" + raw.length() + "]: "
                        + raw.substring(0, Math.min(400, raw.length())));

                    String clean;
                    int start = raw.indexOf(MARKER);
                    int end   = raw.lastIndexOf(MARKER);

                    if (start != -1 && end != -1 && end > start) {
                        // Extract the JSON between our markers
                        clean = raw.substring(start + MARKER.length(), end);
                        Log.d(TAG, "EXTRACTED: " + clean);
                    } else {
                        // No marker found = InfinityFree is blocking the request
                        // (showing anti-bot page / security challenge / suspended page)
                        Log.w(TAG, "SMRZOK marker not found. Server may be blocked.");
                        clean = "{\"success\":false,"
                              + "\"message\":\"Cannot connect to server. "
                              + "Try again in a moment.\"}";
                    }

                    return response.newBuilder()
                        .body(ResponseBody.create(
                            MediaType.parse("application/json; charset=utf-8"),
                            clean))
                        .build();

                } catch (Exception e) {
                    Log.e(TAG, "Extractor error: " + e.getMessage());
                }
                return response;
            };

            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(cookieInterceptor)
                    .addInterceptor(smrzExtractor)
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS)
                    .build();

            Gson gson = new GsonBuilder().setLenient().create();

            retrofit = new Retrofit.Builder()
                    .baseUrl(Constants.BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();
        }
        return retrofit.create(ApiService.class);
    }

    public static void reset() {
        retrofit       = null;
        sessionManager = null;
    }
}
