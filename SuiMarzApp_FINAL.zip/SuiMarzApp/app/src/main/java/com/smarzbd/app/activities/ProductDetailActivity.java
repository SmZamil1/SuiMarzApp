package com.smarzbd.app.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.smarzbd.app.R;
import com.smarzbd.app.api.ApiClient;
import com.smarzbd.app.api.ApiService;
import com.smarzbd.app.models.ApiResponse;
import com.smarzbd.app.models.Product;
import com.smarzbd.app.models.ProductResponse;
import com.smarzbd.app.utils.Constants;
import com.smarzbd.app.utils.SessionManager;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductDetailActivity extends AppCompatActivity {

    private ImageView  ivProduct;
    private TextView   tvName, tvPrice, tvOldPrice, tvDescription, tvStock;
    private Button     btnAddToCart;
    private ProgressBar progressBar;

    private ApiService    apiService;
    private SessionManager session;
    private int           productId;
    private String        selectedSize = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> finish());

        apiService  = ApiClient.getService(this);
        session     = new SessionManager(this);
        productId   = getIntent().getIntExtra(Constants.EXTRA_PRODUCT_ID, -1);

        ivProduct    = findViewById(R.id.iv_product);
        tvName       = findViewById(R.id.tv_name);
        tvPrice      = findViewById(R.id.tv_price);
        tvOldPrice   = findViewById(R.id.tv_old_price);
        tvDescription= findViewById(R.id.tv_description);
        tvStock      = findViewById(R.id.tv_stock);
        btnAddToCart = findViewById(R.id.btn_add_to_cart);
        progressBar  = findViewById(R.id.progress_bar);

        btnAddToCart.setOnClickListener(v -> addToCart());
        loadProduct();
    }

    private void loadProduct() {
        if (productId == -1) { finish(); return; }
        progressBar.setVisibility(View.VISIBLE);

        Map<String, Object> body = new HashMap<>();
        body.put("product_id", productId);
        body.put("limit", 1);

        apiService.getProducts(body).enqueue(new Callback<ProductResponse>() {
            @Override
            public void onResponse(Call<ProductResponse> call, Response<ProductResponse> r) {
                progressBar.setVisibility(View.GONE);
                if (r.isSuccessful() && r.body() != null && r.body().products != null
                        && !r.body().products.isEmpty()) {
                    bindProduct(r.body().products.get(0));
                }
            }
            @Override
            public void onFailure(Call<ProductResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(ProductDetailActivity.this, "Failed to load product", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void bindProduct(Product p) {
        if (getSupportActionBar() != null) getSupportActionBar().setTitle(p.name);
        tvName.setText(p.name);
        tvPrice.setText("৳" + String.format("%.0f", p.price));
        tvDescription.setText(p.description != null ? p.description : "");
        tvStock.setText("In Stock: " + p.stock);

        if (p.oldPrice > 0 && p.oldPrice > p.price) {
            tvOldPrice.setVisibility(View.VISIBLE);
            tvOldPrice.setText("৳" + String.format("%.0f", p.oldPrice));
        } else {
            tvOldPrice.setVisibility(View.GONE);
        }

        String imgUrl = Constants.BASE_URL + "uploads/products/" + p.image;
        Glide.with(this).load(imgUrl)
             .placeholder(R.drawable.placeholder_product)
             .centerCrop().into(ivProduct);

        btnAddToCart.setEnabled(p.stock > 0);
        btnAddToCart.setText(p.stock > 0 ? "Add to Cart" : "Out of Stock");
    }

    private void addToCart() {
        if (!session.isLoggedIn()) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, String> fields = new HashMap<>();
        fields.put("product_id", String.valueOf(productId));
        fields.put("quantity",   "1");
        fields.put("size",       selectedSize);

        btnAddToCart.setEnabled(false);
        apiService.addToCart(fields).enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> r) {
                btnAddToCart.setEnabled(true);
                if (r.isSuccessful() && r.body() != null && r.body().success) {
                    Toast.makeText(ProductDetailActivity.this, "Added to cart!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ProductDetailActivity.this,
                        r.body() != null ? r.body().message : "Failed", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                btnAddToCart.setEnabled(true);
                Toast.makeText(ProductDetailActivity.this, "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
