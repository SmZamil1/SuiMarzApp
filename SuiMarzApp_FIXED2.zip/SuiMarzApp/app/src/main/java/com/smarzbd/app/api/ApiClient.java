package com.smarzbd.app.api;

import android.content.Context;

import com.smarzbd.app.utils.Constants;
import com.smarzbd.app.utils.SessionManager;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {

    private static Retrofit retrofit = null;
    private static SessionManager sessionManager;

    public static ApiService getService(Context context) {
        if (retrofit == null || sessionManager == null) {
            sessionManager = new SessionManager(context);

            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.setLevel(HttpLoggingInterceptor.Level.BODY);

            // Cookie interceptor: attach saved PHPSESSID to every request
            Interceptor cookieInterceptor = new Interceptor() {
                @Override
                public Response intercept(Chain chain) throws IOException {
                    String cookie = sessionManager.getSessionCookie();
                    Request.Builder builder = chain.request().newBuilder();
                    if (cookie != null && !cookie.isEmpty()) {
                        builder.addHeader("Cookie", cookie);
                    }
                    Request request = builder.build();
                    Response response = chain.proceed(request);

                    // Save PHPSESSID from response if present
                    String setCookie = response.header("Set-Cookie");
                    if (setCookie != null && setCookie.contains("PHPSESSID")) {
                        String sessionCookie = setCookie.split(";")[0];
                        sessionManager.saveSessionCookie(sessionCookie);
                    }
                    return response;
                }
            };

            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(logging)
                    .addInterceptor(cookieInterceptor)
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS)
                    .build();

            retrofit = new Retrofit.Builder()
                    .baseUrl(Constants.BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit.create(ApiService.class);
    }

    // Call this on logout to reset the instance (clears cookie)
    public static void reset() {
        retrofit = null;
        sessionManager = null;
    }
}
