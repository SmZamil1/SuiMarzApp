package com.smarzbd.app.api;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.smarzbd.app.utils.Constants;
import com.smarzbd.app.utils.SessionManager;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {

    private static final String TAG    = "SMARZ";
    private static final String MARKER = "SMRZOK";

    private static Retrofit       retrofit       = null;
    private static SessionManager sessionManager = null;

    public static ApiService getService(Context context) {
        if (retrofit == null || sessionManager == null) {
            sessionManager = new SessionManager(context);

            Interceptor headersInterceptor = chain -> {
                String allCookies = sessionManager.getAllCookies();
                Request.Builder b = chain.request().newBuilder()
                    .header("User-Agent",
                        "Mozilla/5.0 (Linux; Android 11; SM-G991B) "
                        + "AppleWebKit/537.36 (KHTML, like Gecko) "
                        + "Chrome/112.0.0.0 Mobile Safari/537.36")
                    .header("Accept",
                        "application/json, text/plain, */*")
                    // ── DO NOT set Accept-Encoding manually ──────────────
                    // OkHttp adds it automatically AND auto-decompresses.
                    // Setting it manually disables auto-decompression
                    // → causes gzip bytes to appear as garbled characters.
                    .header("Accept-Language",  "en-US,en;q=0.9")
                    .header("X-Requested-With", "XMLHttpRequest")
                    .header("Origin",   Constants.BASE_URL.replaceAll("/$",""))
                    .header("Referer",  Constants.BASE_URL)
                    .header("Connection", "keep-alive")
                    .header("Sec-Fetch-Dest", "empty")
                    .header("Sec-Fetch-Mode", "cors")
                    .header("Sec-Fetch-Site", "same-origin");

                if (!allCookies.isEmpty())
                    b.header("Cookie", allCookies);

                Response res = chain.proceed(b.build());

                // Save PHPSESSID for session persistence
                String setCookie = res.header("Set-Cookie");
                if (setCookie != null && setCookie.contains("PHPSESSID"))
                    sessionManager.saveSessionCookie(setCookie.split(";")[0]);

                return res;
            };

            // Extract clean JSON from any server response
            Interceptor jsonInterceptor = chain -> {
                Response response = chain.proceed(chain.request());
                try {
                    ResponseBody body = response.body();
                    if (body == null) return response;

                    // OkHttp auto-decompresses gzip when we didn't set
                    // Accept-Encoding manually, so body.string() = plain text
                    String raw  = body.string();
                    int    code = response.code();
                    Log.d(TAG, "HTTP " + code + " [" + raw.length() + "]: "
                        + raw.substring(0, Math.min(300, raw.length())));

                    String json  = extractJson(raw);
                    String clean = sanitizeJsonEscapes(json);
                    Log.d(TAG, "→ " + clean);

                    return response.newBuilder()
                        .code(200).message("OK")
                        .body(ResponseBody.create(
                            MediaType.parse("application/json; charset=utf-8"),
                            clean))
                        .build();

                } catch (Exception e) {
                    Log.e(TAG, "Interceptor: " + e.getMessage());
                }
                return response;
            };

            OkHttpClient client = new OkHttpClient.Builder()
                    .protocols(Arrays.asList(Protocol.HTTP_1_1))
                    .addInterceptor(headersInterceptor)
                    .addInterceptor(jsonInterceptor)
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS)
                    .build();

            Gson gson = new GsonBuilder().setLenient().create();

            retrofit = new Retrofit.Builder()
                    .baseUrl(Constants.BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();
        }
        return retrofit.create(ApiService.class);
    }

    /**
     * Fix invalid JSON escape sequences before Gson parses.
     * Valid escapes: \" \\ \/ \b \f \n \r \t \uXXXX
     * Everything else (like \' \e \s \d) → strip the backslash.
     */
    private static String sanitizeJsonEscapes(String json) {
        if (json == null || json.isEmpty()) return json;
        StringBuilder sb = new StringBuilder(json.length());
        boolean inStr = false;
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (!inStr) {
                if (c == '"') inStr = true;
                sb.append(c);
            } else {
                if (c == '\\' && i + 1 < json.length()) {
                    char next = json.charAt(i + 1);
                    // Valid JSON escape sequences
                    if (next == '"' || next == '\\' || next == '/' ||
                        next == 'b' || next == 'f'  || next == 'n' ||
                        next == 'r' || next == 't'  || next == 'u') {
                        sb.append(c);  // keep the backslash
                    } else {
                        // Invalid escape — drop the backslash, keep the char
                        // e.g. \' → '   \e → e   etc.
                        i++; // skip the backslash
                        sb.append(next);
                        continue;
                    }
                } else if (c == '"') {
                    inStr = false;
                    sb.append(c);
                    continue;
                } else {
                    sb.append(c);
                    continue;
                }
                sb.append(c);
            }
        }
        return sb.toString();
    }

    private static String extractJson(String raw) {
        if (raw == null || raw.isEmpty())
            return fail("Empty server response");

        // Strategy 1: SMRZOK markers
        int ms = raw.indexOf(MARKER), me = raw.lastIndexOf(MARKER);
        if (ms != -1 && me > ms)
            return raw.substring(ms + MARKER.length(), me).trim();

        // Strategy 2: Already clean JSON
        String t = raw.trim();
        if (t.startsWith("{") && t.endsWith("}") && t.contains("success"))
            return t;

        // Strategy 3: Find {"success": and extract balanced JSON
        for (String pat : new String[]{"{\"success\":", "{ \"success\":"}) {
            int i = raw.indexOf(pat);
            if (i != -1) {
                String j = extractBalanced(raw.substring(i));
                if (j != null) return j;
            }
        }

        // Strategy 4: Any JSON object with "success"
        for (int end = raw.length() - 1; end >= 0; end--) {
            if (raw.charAt(end) == '}') {
                for (int s = end; s >= 0; s--) {
                    if (raw.charAt(s) == '{') {
                        String c = raw.substring(s, end + 1);
                        if (c.contains("success")) return c;
                        break;
                    }
                }
            }
        }

        String preview = raw.trim()
            .substring(0, Math.min(60, raw.trim().length()))
            .replaceAll("[\"'<>]", "");
        return fail("Unexpected: " + preview);
    }

    private static String extractBalanced(String s) {
        if (s == null || !s.startsWith("{")) return null;
        int d = 0; boolean str = false, esc = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (esc)       { esc = false; continue; }
            if (c == '\\') { esc = true;  continue; }
            if (c == '"')  { str = !str;  continue; }
            if (str)       continue;
            if (c == '{')  d++;
            else if (c == '}') { if (--d == 0) return s.substring(0, i + 1); }
        }
        return null;
    }

    private static String fail(String msg) {
        return "{\"success\":false,\"message\":\"" + msg + "\"}";
    }

    public static void reset() { retrofit = null; sessionManager = null; }
}
