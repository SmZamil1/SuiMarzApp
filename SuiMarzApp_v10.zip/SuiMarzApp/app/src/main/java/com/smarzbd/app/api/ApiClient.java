package com.smarzbd.app.api;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.smarzbd.app.utils.Constants;
import com.smarzbd.app.utils.SessionManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {

    private static final String TAG    = "SMARZ";
    private static final String MARKER = "SMRZOK";

    private static Retrofit       retrofit       = null;
    private static SessionManager sessionManager = null;

    private static final List<Cookie> cookieStore = new ArrayList<>();
    private static final CookieJar cookieJar = new CookieJar() {
        @Override
        public void saveFromResponse(HttpUrl url, List<Cookie> cookies) {
            synchronized (cookieStore) {
                for (Cookie c : cookies) {
                    cookieStore.removeIf(x -> x.name().equals(c.name()));
                    cookieStore.add(c);
                }
            }
        }
        @Override
        public List<Cookie> loadForRequest(HttpUrl url) {
            synchronized (cookieStore) {
                List<Cookie> valid = new ArrayList<>();
                for (Cookie c : cookieStore) {
                    if (c.matches(url)) valid.add(c);
                }
                return valid;
            }
        }
    };

    public static ApiService getService(Context context) {
        if (retrofit == null || sessionManager == null) {
            sessionManager = new SessionManager(context);

            Interceptor ajaxInterceptor = chain -> {
                String savedCookie = sessionManager.getSessionCookie();
                Request.Builder b = chain.request().newBuilder()
                    // ── AJAX headers (not browser-page headers!) ─────
                    // These tell InfinityFree/Cloudflare this is an API
                    // call, NOT a browser page load → no HTML injection
                    .header("User-Agent",
                        "Mozilla/5.0 (Linux; Android 11; SM-G991B) "
                        + "AppleWebKit/537.36 (KHTML, like Gecko) "
                        + "Chrome/112.0.0.0 Mobile Safari/537.36")
                    .header("Accept",
                        "application/json, text/plain, */*")   // ← JSON, not HTML
                    .header("Accept-Language",     "en-US,en;q=0.9")
                    .header("Accept-Encoding",     "gzip, deflate, br")
                    .header("Content-Type",
                        "application/x-www-form-urlencoded")
                    .header("X-Requested-With",    "XMLHttpRequest") // ← AJAX flag
                    .header("Origin",
                        Constants.BASE_URL.replaceAll("/$", ""))
                    .header("Referer",             Constants.BASE_URL)
                    .header("Connection",          "keep-alive")
                    // ── AJAX Sec-Fetch (not navigation!) ─────────────
                    .header("Sec-Fetch-Dest",      "empty")    // ← not "document"
                    .header("Sec-Fetch-Mode",      "cors")     // ← not "navigate"
                    .header("Sec-Fetch-Site",      "same-origin");

                if (savedCookie != null && !savedCookie.isEmpty())
                    b.header("Cookie", savedCookie);

                Response res = chain.proceed(b.build());

                String setCookie = res.header("Set-Cookie");
                if (setCookie != null && setCookie.contains("PHPSESSID"))
                    sessionManager.saveSessionCookie(setCookie.split(";")[0]);

                return res;
            };

            // Force HTTP 200 and extract JSON from any response body
            Interceptor jsonInterceptor = chain -> {
                Response response = chain.proceed(chain.request());
                try {
                    ResponseBody body = response.body();
                    if (body == null) return response;

                    String raw  = body.string();
                    int    code = response.code();
                    // Log first 500 chars so we can see what server returns
                    Log.d(TAG, "HTTP " + code + " ["
                        + raw.length() + " bytes]: "
                        + raw.substring(0, Math.min(500, raw.length())));

                    String clean = extractJson(raw);
                    Log.d(TAG, "→ " + clean);

                    return response.newBuilder()
                        .code(200).message("OK")
                        .body(ResponseBody.create(
                            MediaType.parse("application/json; charset=utf-8"),
                            clean))
                        .build();

                } catch (Exception e) {
                    Log.e(TAG, "Interceptor: " + e.getMessage());
                }
                return response;
            };

            OkHttpClient client = new OkHttpClient.Builder()
                    .protocols(Arrays.asList(Protocol.HTTP_1_1))
                    .cookieJar(cookieJar)
                    .addInterceptor(ajaxInterceptor)
                    .addInterceptor(jsonInterceptor)
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS)
                    .build();

            Gson gson = new GsonBuilder().setLenient().create();

            retrofit = new Retrofit.Builder()
                    .baseUrl(Constants.BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();
        }
        return retrofit.create(ApiService.class);
    }

    private static String extractJson(String raw) {
        if (raw == null || raw.isEmpty())
            return fail("Empty server response");

        // Strategy 1: SMRZOK markers
        int ms = raw.indexOf(MARKER), me = raw.lastIndexOf(MARKER);
        if (ms != -1 && me > ms)
            return raw.substring(ms + MARKER.length(), me).trim();

        // Strategy 2: Already clean JSON
        String t = raw.trim();
        if (t.startsWith("{") && t.endsWith("}") && t.contains("success"))
            return t;

        // Strategy 3: Find {"success": balanced object
        for (String pat : new String[]{"{\"success\":", "{ \"success\":"}) {
            int i = raw.indexOf(pat);
            if (i != -1) {
                String j = extractBalanced(raw.substring(i));
                if (j != null) return j;
            }
        }

        // Strategy 4: Any JSON object with "success" key
        for (int end = raw.length() - 1; end >= 0; end--) {
            if (raw.charAt(end) == '}') {
                for (int s = end; s >= 0; s--) {
                    if (raw.charAt(s) == '{') {
                        String c = raw.substring(s, end + 1);
                        if (c.contains("success")) return c;
                        break;
                    }
                }
            }
        }

        // Show first 60 chars in error so user can report what server returned
        String preview = raw.trim().substring(0, Math.min(60, raw.trim().length()))
                           .replaceAll("[\"']", "");
        return fail("Unexpected: " + preview);
    }

    private static String extractBalanced(String s) {
        if (s == null || !s.startsWith("{")) return null;
        int d = 0; boolean str = false, esc = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (esc)       { esc = false; continue; }
            if (c == '\\') { esc = true;  continue; }
            if (c == '"')  { str = !str;  continue; }
            if (str)       continue;
            if (c == '{')  d++;
            else if (c == '}') { if (--d == 0) return s.substring(0, i + 1); }
        }
        return null;
    }

    private static String fail(String msg) {
        return "{\"success\":false,\"message\":\"" + msg + "\"}";
    }

    public static void reset() { retrofit = null; sessionManager = null; }
}
