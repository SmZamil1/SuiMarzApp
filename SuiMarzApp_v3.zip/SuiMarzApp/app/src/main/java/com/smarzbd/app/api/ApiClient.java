package com.smarzbd.app.api;

import android.content.Context;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.smarzbd.app.utils.Constants;
import com.smarzbd.app.utils.SessionManager;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {
    private static Retrofit       retrofit       = null;
    private static SessionManager sessionManager = null;

    public static ApiService getService(Context context) {
        if (retrofit == null || sessionManager == null) {
            sessionManager = new SessionManager(context);
            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.setLevel(HttpLoggingInterceptor.Level.BODY);

            Interceptor cookieInterceptor = chain -> {
                String cookie = sessionManager.getSessionCookie();
                Request.Builder builder = chain.request().newBuilder();
                if (cookie != null && !cookie.isEmpty()) builder.addHeader("Cookie", cookie);
                Request request   = builder.build();
                Response response = chain.proceed(request);
                String setCookie  = response.header("Set-Cookie");
                if (setCookie != null && setCookie.contains("PHPSESSID"))
                    sessionManager.saveSessionCookie(setCookie.split(";")[0]);
                return response;
            };

            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(logging)
                    .addInterceptor(cookieInterceptor)
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS)
                    .build();

            // Lenient Gson handles any BOM or stray chars from free hosting
            Gson gson = new GsonBuilder().setLenient().create();

            retrofit = new Retrofit.Builder()
                    .baseUrl(Constants.BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();
        }
        return retrofit.create(ApiService.class);
    }

    public static void reset() { retrofit = null; sessionManager = null; }
}
