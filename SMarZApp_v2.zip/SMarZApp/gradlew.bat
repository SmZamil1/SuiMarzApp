@rem Gradle startup script for Windows
@rem Add default JVM options here.
@if "%JAVA_HOME%" == "" (echo JAVA_HOME not set && exit /b 1)
"%JAVA_HOME%\bin\java.exe" -jar "%~dp0gradle\wrapper\gradle-wrapper.jar" %*
