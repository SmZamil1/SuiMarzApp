# Add project specific ProGuard rules here.
-keep class com.smarzbd.app.models.** { *; }
-keep class com.google.gson.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
