package com.smarzbd.app.activities;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.smarzbd.app.R;
import com.smarzbd.app.network.ApiClient;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OrderDetailActivity extends AppCompatActivity {

    private TextView tvOrderNumber, tvStatus, tvTotal, tvAddress, tvPhone,
            tvPayment, tvDate, tvNote;
    private LinearLayout layoutItems;
    private ProgressBar progressBar;
    private final Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        tvOrderNumber = findViewById(R.id.tv_order_number);
        tvStatus = findViewById(R.id.tv_status);
        tvTotal = findViewById(R.id.tv_total);
        tvAddress = findViewById(R.id.tv_address);
        tvPhone = findViewById(R.id.tv_phone);
        tvPayment = findViewById(R.id.tv_payment);
        tvDate = findViewById(R.id.tv_date);
        tvNote = findViewById(R.id.tv_note);
        layoutItems = findViewById(R.id.layout_items);
        progressBar = findViewById(R.id.progress_bar);

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        int orderId = getIntent().getIntExtra("order_id", 0);
        if (orderId > 0) loadOrder(orderId);
        else finish();
    }

    private void loadOrder(int orderId) {
        progressBar.setVisibility(View.VISIBLE);
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                Map<String, String> fields = new HashMap<>();
                fields.put("order_id", String.valueOf(orderId));
                String resp = ApiClient.getInstance(this).postForm("/api/orders/get_order_detail.php", fields);
                JsonObject obj = gson.fromJson(resp, JsonObject.class);

                new Handler(Looper.getMainLooper()).post(() -> {
                    progressBar.setVisibility(View.GONE);
                    if (obj.has("success") && obj.get("success").getAsBoolean()) {
                        JsonObject order = obj.getAsJsonObject("order");
                        displayOrder(order);
                        if (obj.has("items")) displayItems(obj.getAsJsonArray("items"));
                    }
                });
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> progressBar.setVisibility(View.GONE));
            }
            exec.shutdown();
        });
    }

    private void displayOrder(JsonObject order) {
        tvOrderNumber.setText("#" + getString(order, "order_number"));
        String status = getString(order, "status");
        tvStatus.setText(status.toUpperCase());
        setStatusColor(status);
        tvTotal.setText("৳" + String.format("%.2f", order.get("total").getAsDouble()));
        tvAddress.setText(getString(order, "address"));
        tvPhone.setText(getString(order, "phone"));
        tvPayment.setText(getString(order, "payment_method").toUpperCase());
        tvDate.setText(getString(order, "created_at"));
        String note = getString(order, "note");
        if (!note.isEmpty()) { tvNote.setVisibility(View.VISIBLE); tvNote.setText("Note: " + note); }
        else tvNote.setVisibility(View.GONE);
    }

    private void setStatusColor(String status) {
        int color;
        switch (status.toLowerCase()) {
            case "delivered": color = getColor(R.color.green); break;
            case "shipped": color = getColor(R.color.primary); break;
            case "cancelled": color = getColor(R.color.red); break;
            default: color = getColor(R.color.orange); break;
        }
        tvStatus.setTextColor(color);
    }

    private void displayItems(JsonArray items) {
        layoutItems.removeAllViews();
        for (int i = 0; i < items.size(); i++) {
            JsonObject item = items.get(i).getAsJsonObject();
            View v = getLayoutInflater().inflate(R.layout.item_order_product, layoutItems, false);
            ((TextView) v.findViewById(R.id.tv_product_name)).setText(getString(item, "name"));
            double price = item.get("price").getAsDouble();
            int qty = item.get("quantity").getAsInt();
            ((TextView) v.findViewById(R.id.tv_product_price)).setText(
                    "৳" + String.format("%.0f", price) + " × " + qty + " = ৳" + String.format("%.0f", price * qty));
            layoutItems.addView(v);
        }
    }

    private String getString(JsonObject obj, String key) {
        try {
            if (obj.has(key) && !obj.get(key).isJsonNull()) return obj.get(key).getAsString();
        } catch (Exception ignored) {}
        return "";
    }
}
