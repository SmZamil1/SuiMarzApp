package com.smarzbd.app.models;

public class User {
    public int user_id;
    public String name;
    public String email;
    public String phone;

    public User() {}
    public User(int id, String name, String email, String phone) {
        this.user_id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
    }
}
