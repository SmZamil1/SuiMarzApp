package com.smarzbd.app.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.smarzbd.app.R;

/** Stub — profile is handled by ProfileFragment inside MainActivity */
public class ProfileActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        finish(); // immediately go back; never launched directly
    }
}
