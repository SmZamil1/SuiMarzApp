package com.smarzbd.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.smarzbd.app.R;
import com.smarzbd.app.activities.LoginActivity;
import com.smarzbd.app.adapters.OrderAdapter;
import com.smarzbd.app.models.Order;
import com.smarzbd.app.network.ApiClient;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OrdersFragment extends Fragment {

    private RecyclerView rvOrders;
    private SwipeRefreshLayout swipeRefresh;
    private LinearLayout layoutEmpty, layoutLoginRequired;
    private final List<Order> orders = new ArrayList<>();
    private OrderAdapter adapter;
    private final Gson gson = new Gson();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_orders, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rvOrders = view.findViewById(R.id.rv_orders);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        layoutEmpty = view.findViewById(R.id.layout_empty);
        layoutLoginRequired = view.findViewById(R.id.layout_login_required);

        rvOrders.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new OrderAdapter(orders, getContext());
        rvOrders.setAdapter(adapter);

        swipeRefresh.setColorSchemeResources(R.color.primary, R.color.accent);
        swipeRefresh.setOnRefreshListener(this::loadOrders);

        view.findViewById(R.id.btn_login).setOnClickListener(v ->
                startActivity(new Intent(getActivity(), LoginActivity.class)));

        loadOrders();
    }

    private void loadOrders() {
        if (!ApiClient.getInstance(requireContext()).isLoggedIn()) {
            layoutLoginRequired.setVisibility(View.VISIBLE);
            layoutEmpty.setVisibility(View.GONE);
            rvOrders.setVisibility(View.GONE);
            swipeRefresh.setRefreshing(false);
            return;
        }
        layoutLoginRequired.setVisibility(View.GONE);
        swipeRefresh.setRefreshing(true);

        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String resp = ApiClient.getInstance(requireContext()).get("/api/orders/get_orders.php");
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                List<Order> list = new ArrayList<>();
                if (obj.has("success") && obj.get("success").getAsBoolean()) {
                    if (obj.has("orders")) {
                        JsonArray arr = obj.getAsJsonArray("orders");
                        for (int i = 0; i < arr.size(); i++)
                            list.add(gson.fromJson(arr.get(i), Order.class));
                    }
                }
                new Handler(Looper.getMainLooper()).post(() -> {
                    orders.clear();
                    orders.addAll(list);
                    adapter.notifyDataSetChanged();
                    swipeRefresh.setRefreshing(false);
                    if (list.isEmpty()) {
                        layoutEmpty.setVisibility(View.VISIBLE);
                        rvOrders.setVisibility(View.GONE);
                    } else {
                        layoutEmpty.setVisibility(View.GONE);
                        rvOrders.setVisibility(View.VISIBLE);
                    }
                });
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    swipeRefresh.setRefreshing(false);
                    Toast.makeText(getContext(), "Failed to load orders", Toast.LENGTH_SHORT).show();
                });
            }
            exec.shutdown();
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        loadOrders();
    }
}
