package com.smarzbd.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewpager2.widget.ViewPager2;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.smarzbd.app.R;
import com.smarzbd.app.activities.NotificationsActivity;
import com.smarzbd.app.activities.SearchActivity;
import com.smarzbd.app.adapters.BannerAdapter;
import com.smarzbd.app.adapters.CategoryChipAdapter;
import com.smarzbd.app.adapters.ProductAdapter;
import com.smarzbd.app.models.Category;
import com.smarzbd.app.models.Product;
import com.smarzbd.app.network.ApiClient;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HomeFragment extends Fragment {

    private ViewPager2 bannerPager;
    private LinearLayout bannerDots;
    private RecyclerView rvFeatured, rvPopular;
    private TextView tvNotifBadge;
    private SwipeRefreshLayout swipeRefresh;
    private LinearLayout categoryChips;
    private BannerAdapter bannerAdapter;
    private ProductAdapter featuredAdapter, popularAdapter;
    private final List<String> banners = new ArrayList<>();
    private final List<Product> featured = new ArrayList<>();
    private final List<Product> popular = new ArrayList<>();
    private Timer bannerTimer;
    private int currentBanner = 0;
    private final Gson gson = new Gson();
    private int selectedCatId = -1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        bannerPager = view.findViewById(R.id.banner_pager);
        bannerDots = view.findViewById(R.id.banner_dots);
        rvFeatured = view.findViewById(R.id.rv_featured);
        rvPopular = view.findViewById(R.id.rv_popular);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        categoryChips = view.findViewById(R.id.category_chips);
        tvNotifBadge = view.findViewById(R.id.tv_notif_badge);

        view.findViewById(R.id.btn_search).setOnClickListener(v ->
                startActivity(new Intent(getActivity(), SearchActivity.class)));
        view.findViewById(R.id.btn_notifications).setOnClickListener(v ->
                startActivity(new Intent(getActivity(), NotificationsActivity.class)));
        view.findViewById(R.id.tv_see_all_featured).setOnClickListener(v -> {
            Intent i = new Intent(getActivity(), com.smarzbd.app.activities.AllProductsActivity.class);
            i.putExtra("type", "featured"); startActivity(i);
        });
        view.findViewById(R.id.tv_see_all_popular).setOnClickListener(v -> {
            Intent i = new Intent(getActivity(), com.smarzbd.app.activities.AllProductsActivity.class);
            i.putExtra("type", "popular"); startActivity(i);
        });

        // Setup RecyclerViews
        rvFeatured.setLayoutManager(new GridLayoutManager(getContext(), 2));
        featuredAdapter = new ProductAdapter(featured, getContext());
        rvFeatured.setAdapter(featuredAdapter);
        rvFeatured.setNestedScrollingEnabled(false);

        rvPopular.setLayoutManager(new GridLayoutManager(getContext(), 2));
        popularAdapter = new ProductAdapter(popular, getContext());
        rvPopular.setAdapter(popularAdapter);
        rvPopular.setNestedScrollingEnabled(false);

        // Banner
        bannerAdapter = new BannerAdapter(banners, getContext());
        bannerPager.setAdapter(bannerAdapter);

        swipeRefresh.setColorSchemeResources(R.color.primary, R.color.accent);
        swipeRefresh.setOnRefreshListener(this::loadAll);

        loadAll();
    }

    private void loadAll() {
        loadBanners();
        loadCategories();
        loadFeatured();
        loadPopular();
        loadNotifBadge();
    }

    private void loadBanners() {
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            List<String> urls = new ArrayList<>();
            try {
                String resp = ApiClient.getInstance(requireContext())
                        .get("/api/get_banners.php");
                // Try to parse — may not exist on this server
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                if (obj.has("banners")) {
                    JsonArray arr = obj.getAsJsonArray("banners");
                    for (int i = 0; i < arr.size(); i++) {
                        JsonObject b = arr.get(i).getAsJsonObject();
                        String img = b.has("image") ? b.get("image").getAsString() : "";
                        if (!img.isEmpty())
                            urls.add(ApiClient.BASE_URL + "/uploads/banners/" + img);
                    }
                }
            } catch (Exception e) {
                // Banner API may not exist — silently ignore
            }
            new Handler(Looper.getMainLooper()).post(() -> {
                banners.clear();
                banners.addAll(urls);
                bannerAdapter.notifyDataSetChanged();
                if (!banners.isEmpty()) {
                    setupBannerDots();
                    startBannerAuto();
                }
            });
            exec.shutdown();
        });
    }

    private void setupBannerDots() {
        bannerDots.removeAllViews();
        for (int i = 0; i < banners.size(); i++) {
            View dot = new View(getContext());
            int size = (int) (8 * getResources().getDisplayMetrics().density);
            int margin = (int) (4 * getResources().getDisplayMetrics().density);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            lp.setMargins(margin, 0, margin, 0);
            dot.setLayoutParams(lp);
            dot.setBackgroundResource(i == 0 ? R.drawable.dot_active : R.drawable.dot_inactive);
            bannerDots.addView(dot);
        }
        bannerPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                currentBanner = position;
                updateDots(position);
            }
        });
    }

    private void updateDots(int pos) {
        for (int i = 0; i < bannerDots.getChildCount(); i++) {
            bannerDots.getChildAt(i).setBackgroundResource(
                    i == pos ? R.drawable.dot_active : R.drawable.dot_inactive);
        }
    }

    private void startBannerAuto() {
        if (bannerTimer != null) bannerTimer.cancel();
        if (banners.size() <= 1) return;
        bannerTimer = new Timer();
        bannerTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                new Handler(Looper.getMainLooper()).post(() -> {
                    if (bannerPager == null || banners.isEmpty()) return;
                    currentBanner = (currentBanner + 1) % banners.size();
                    bannerPager.setCurrentItem(currentBanner, true);
                });
            }
        }, 3000, 3000);
    }

    private void loadCategories() {
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String resp = ApiClient.getInstance(requireContext()).get("/api/get_categories.php");
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                List<Category> cats = new ArrayList<>();
                if (obj.has("categories")) {
                    JsonArray arr = obj.getAsJsonArray("categories");
                    for (int i = 0; i < arr.size(); i++) {
                        cats.add(gson.fromJson(arr.get(i), Category.class));
                    }
                }
                new Handler(Looper.getMainLooper()).post(() -> buildCategoryChips(cats));
            } catch (Exception e) { e.printStackTrace(); }
            exec.shutdown();
        });
    }

    private void buildCategoryChips(List<Category> cats) {
        if (getContext() == null) return;
        categoryChips.removeAllViews();
        // "All" chip
        addCategoryChip("All", -1, true);
        for (Category c : cats) addCategoryChip(c.name, c.id, false);
    }

    private void addCategoryChip(String name, int catId, boolean selected) {
        TextView chip = new TextView(getContext());
        chip.setText(name);
        chip.setTag(catId);
        int dp = (int) getResources().getDisplayMetrics().density;
        chip.setPadding(16 * dp, 8 * dp, 16 * dp, 8 * dp);
        chip.setTextSize(14);
        chip.setBackgroundResource(selected ? R.drawable.chip_selected : R.drawable.chip_unselected);
        chip.setTextColor(selected ?
                getResources().getColor(R.color.white, null) :
                getResources().getColor(R.color.text_primary, null));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 8 * dp, 0);
        chip.setLayoutParams(lp);
        chip.setOnClickListener(v -> {
            selectedCatId = catId;
            // Reset all chips
            for (int i = 0; i < categoryChips.getChildCount(); i++) {
                View cv = categoryChips.getChildAt(i);
                cv.setBackgroundResource(R.drawable.chip_unselected);
                if (cv instanceof TextView)
                    ((TextView) cv).setTextColor(getResources().getColor(R.color.text_primary, null));
            }
            chip.setBackgroundResource(R.drawable.chip_selected);
            chip.setTextColor(getResources().getColor(R.color.white, null));
            filterProducts(catId);
        });
        categoryChips.addView(chip);
    }

    private void filterProducts(int catId) {
        loadFeaturedWithCat(catId);
        loadPopularWithCat(catId);
    }

    private void loadFeatured() { loadFeaturedWithCat(selectedCatId); }
    private void loadPopular() { loadPopularWithCat(selectedCatId); }

    private void loadFeaturedWithCat(int catId) {
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String catParam = catId == -1 ? "all" : String.valueOf(catId);
                String body = "{\"type\":\"featured\",\"category\":\"" + catParam + "\",\"limit\":8}";
                String resp = ApiClient.getInstance(requireContext()).postJson("/api/get_products.php", body);
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                List<Product> list = new ArrayList<>();
                if (obj.has("products")) {
                    JsonArray arr = obj.getAsJsonArray("products");
                    for (int i = 0; i < arr.size(); i++)
                        list.add(gson.fromJson(arr.get(i), Product.class));
                }
                new Handler(Looper.getMainLooper()).post(() -> {
                    featured.clear(); featured.addAll(list);
                    featuredAdapter.notifyDataSetChanged();
                    swipeRefresh.setRefreshing(false);
                });
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> swipeRefresh.setRefreshing(false));
            }
            exec.shutdown();
        });
    }

    private void loadPopularWithCat(int catId) {
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String catParam = catId == -1 ? "all" : String.valueOf(catId);
                String body = "{\"type\":\"popular\",\"category\":\"" + catParam + "\",\"limit\":8}";
                String resp = ApiClient.getInstance(requireContext()).postJson("/api/get_products.php", body);
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                List<Product> list = new ArrayList<>();
                if (obj.has("products")) {
                    JsonArray arr = obj.getAsJsonArray("products");
                    for (int i = 0; i < arr.size(); i++)
                        list.add(gson.fromJson(arr.get(i), Product.class));
                }
                new Handler(Looper.getMainLooper()).post(() -> {
                    popular.clear(); popular.addAll(list);
                    popularAdapter.notifyDataSetChanged();
                });
            } catch (Exception e) { e.printStackTrace(); }
            exec.shutdown();
        });
    }

    private void loadNotifBadge() {
        if (!ApiClient.getInstance(requireContext()).isLoggedIn()) return;
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String resp = ApiClient.getInstance(requireContext()).get("/api/get_notifications.php");
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                int unread = obj.has("unread_count") ? obj.get("unread_count").getAsInt() : 0;
                new Handler(Looper.getMainLooper()).post(() -> {
                    if (tvNotifBadge != null) {
                        tvNotifBadge.setVisibility(unread > 0 ? View.VISIBLE : View.GONE);
                        tvNotifBadge.setText(String.valueOf(unread));
                    }
                });
            } catch (Exception e) { e.printStackTrace(); }
            exec.shutdown();
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (bannerTimer != null) { bannerTimer.cancel(); bannerTimer = null; }
    }
}
