package com.smarzbd.app.models;

public class CartItem {
    public int id;
    public int product_id;
    public String name;
    public double price;
    public int quantity;
    public double subtotal;
    public String size;
    public String image;

    public String getImageUrl() {
        if (image == null || image.isEmpty()) return "";
        if (image.startsWith("http")) return image;
        return com.smarzbd.app.network.ApiClient.BASE_URL + "/uploads/products/" + image;
    }
}
