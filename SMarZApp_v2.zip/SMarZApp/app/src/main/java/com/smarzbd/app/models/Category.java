package com.smarzbd.app.models;

public class Category {
    public int id;
    public String name;
    public String image;

    public String getImageUrl() {
        if (image == null || image.isEmpty()) return "";
        if (image.startsWith("http")) return image;
        return com.smarzbd.app.network.ApiClient.BASE_URL + "/uploads/categories/" + image;
    }
}
