package com.smarzbd.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.smarzbd.app.R;
import com.smarzbd.app.models.User;
import com.smarzbd.app.network.ApiClient;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RegisterActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPhone, etPassword, etConfirmPassword;
    private Button btnRegister;
    private ProgressBar progressBar;
    private final Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        etName = findViewById(R.id.et_name);
        etEmail = findViewById(R.id.et_email);
        etPhone = findViewById(R.id.et_phone);
        etPassword = findViewById(R.id.et_password);
        etConfirmPassword = findViewById(R.id.et_confirm_password);
        btnRegister = findViewById(R.id.btn_register);
        progressBar = findViewById(R.id.progress_bar);

        btnRegister.setOnClickListener(v -> attemptRegister());
        findViewById(R.id.tv_login).setOnClickListener(v -> finish());
        findViewById(R.id.btn_back).setOnClickListener(v -> finish());
    }

    private void attemptRegister() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirm = etConfirmPassword.getText().toString().trim();

        if (name.isEmpty()) { etName.setError("Name required"); etName.requestFocus(); return; }
        if (email.isEmpty()) { etEmail.setError("Email required"); etEmail.requestFocus(); return; }
        if (phone.isEmpty()) { etPhone.setError("Phone required"); etPhone.requestFocus(); return; }
        if (password.length() < 6) { etPassword.setError("Min 6 characters"); etPassword.requestFocus(); return; }
        if (!password.equals(confirm)) { etConfirmPassword.setError("Passwords don't match"); etConfirmPassword.requestFocus(); return; }

        setLoading(true);
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                Map<String, String> fields = new HashMap<>();
                fields.put("name", name);
                fields.put("email", email);
                fields.put("phone", phone);
                fields.put("password", password);
                fields.put("confirm_password", confirm);
                String resp = ApiClient.getInstance(this).postForm("/api/auth/register.php", fields);
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                boolean success = obj.has("success") && obj.get("success").getAsBoolean();
                new Handler(Looper.getMainLooper()).post(() -> {
                    setLoading(false);
                    if (success) {
                        User user = new User(
                                obj.get("user_id").getAsInt(), name, email, phone);
                        ApiClient.getInstance(this).saveUser(user);
                        Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    } else {
                        String msg = obj.has("message") ? obj.get("message").getAsString() : "Registration failed";
                        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    setLoading(false);
                    Toast.makeText(this, "Network error. Please try again.", Toast.LENGTH_LONG).show();
                });
            }
            exec.shutdown();
        });
    }

    private void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnRegister.setEnabled(!loading);
        btnRegister.setText(loading ? "Registering..." : "Create Account");
    }
}
