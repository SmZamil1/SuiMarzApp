package com.smarzbd.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.smarzbd.app.R;
import com.smarzbd.app.models.Category;

import java.util.List;

public class CategoryChipAdapter extends RecyclerView.Adapter<CategoryChipAdapter.VH> {

    public interface OnChipClick { void onClick(int catId); }

    private final List<Category> categories;
    private final Context context;
    private final OnChipClick listener;
    private int selectedPos = 0;

    public CategoryChipAdapter(List<Category> cats, Context ctx, OnChipClick l) {
        this.categories = cats; this.context = ctx; this.listener = l;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_chip, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Category c = categories.get(pos);
        h.tv.setText(c.name);
        h.tv.setBackgroundResource(pos == selectedPos ? R.drawable.chip_selected : R.drawable.chip_unselected);
        h.tv.setTextColor(pos == selectedPos ?
                context.getColor(R.color.white) : context.getColor(R.color.text_primary));
        h.itemView.setOnClickListener(v -> {
            int old = selectedPos;
            selectedPos = pos;
            notifyItemChanged(old);
            notifyItemChanged(pos);
            if (listener != null) listener.onClick(c.id);
        });
    }

    @Override
    public int getItemCount() { return categories.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tv;
        VH(View v) { super(v); tv = v.findViewById(R.id.tv_chip); }
    }
}
