package com.smarzbd.app.activities;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.smarzbd.app.R;
import com.smarzbd.app.adapters.ProductAdapter;
import com.smarzbd.app.models.Product;
import com.smarzbd.app.network.ApiClient;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AllProductsActivity extends AppCompatActivity {

    private RecyclerView rvProducts;
    private SwipeRefreshLayout swipeRefresh;
    private TextView tvTitle;
    private final List<Product> products = new ArrayList<>();
    private ProductAdapter adapter;
    private final Gson gson = new Gson();
    private String type = "featured";
    private int categoryId = -1;
    private String categoryName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_products);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        type = getIntent().getStringExtra("type") != null ? getIntent().getStringExtra("type") : "featured";
        categoryId = getIntent().getIntExtra("category_id", -1);
        categoryName = getIntent().getStringExtra("category_name") != null ?
                getIntent().getStringExtra("category_name") : "";

        rvProducts = findViewById(R.id.rv_products);
        swipeRefresh = findViewById(R.id.swipe_refresh);
        tvTitle = findViewById(R.id.tv_title);

        if (!categoryName.isEmpty()) tvTitle.setText(categoryName);
        else tvTitle.setText(type.equals("popular") ? "Popular Products" : "All Products");

        rvProducts.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new ProductAdapter(products, this);
        rvProducts.setAdapter(adapter);

        swipeRefresh.setColorSchemeResources(R.color.primary, R.color.accent);
        swipeRefresh.setOnRefreshListener(this::load);

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        load();
    }

    private void load() {
        swipeRefresh.setRefreshing(true);
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String catParam = categoryId == -1 ? "all" : String.valueOf(categoryId);
                String body = "{\"type\":\"" + type + "\",\"category\":\"" + catParam + "\",\"limit\":50}";
                String resp = ApiClient.getInstance(this).postJson("/api/get_products.php", body);
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                List<Product> list = new ArrayList<>();
                if (obj.has("products")) {
                    JsonArray arr = obj.getAsJsonArray("products");
                    for (int i = 0; i < arr.size(); i++)
                        list.add(gson.fromJson(arr.get(i), Product.class));
                }
                new Handler(Looper.getMainLooper()).post(() -> {
                    products.clear(); products.addAll(list);
                    adapter.notifyDataSetChanged();
                    swipeRefresh.setRefreshing(false);
                });
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    swipeRefresh.setRefreshing(false);
                    Toast.makeText(this, "Failed to load products", Toast.LENGTH_SHORT).show();
                });
            }
            exec.shutdown();
        });
    }
}
