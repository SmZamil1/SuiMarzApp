package com.smarzbd.app.activities;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.smarzbd.app.R;
import com.smarzbd.app.adapters.NotificationAdapter;
import com.smarzbd.app.models.Notification;
import com.smarzbd.app.network.ApiClient;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class NotificationsActivity extends AppCompatActivity {

    private RecyclerView rvNotifications;
    private SwipeRefreshLayout swipeRefresh;
    private LinearLayout layoutEmpty;
    private final List<Notification> notifications = new ArrayList<>();
    private NotificationAdapter adapter;
    private final Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        rvNotifications = findViewById(R.id.rv_notifications);
        swipeRefresh = findViewById(R.id.swipe_refresh);
        layoutEmpty = findViewById(R.id.layout_empty);

        rvNotifications.setLayoutManager(new LinearLayoutManager(this));
        adapter = new NotificationAdapter(notifications, this);
        rvNotifications.setAdapter(adapter);

        swipeRefresh.setColorSchemeResources(R.color.primary, R.color.accent);
        swipeRefresh.setOnRefreshListener(this::load);

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        load();
    }

    private void load() {
        if (!ApiClient.getInstance(this).isLoggedIn()) {
            layoutEmpty.setVisibility(View.VISIBLE);
            swipeRefresh.setRefreshing(false);
            return;
        }
        swipeRefresh.setRefreshing(true);
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String resp = ApiClient.getInstance(this).get("/api/get_notifications.php");
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                List<Notification> list = new ArrayList<>();
                if (obj.has("notifications")) {
                    JsonArray arr = obj.getAsJsonArray("notifications");
                    for (int i = 0; i < arr.size(); i++)
                        list.add(gson.fromJson(arr.get(i), Notification.class));
                }
                new Handler(Looper.getMainLooper()).post(() -> {
                    notifications.clear(); notifications.addAll(list);
                    adapter.notifyDataSetChanged();
                    swipeRefresh.setRefreshing(false);
                    layoutEmpty.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
                });
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    swipeRefresh.setRefreshing(false);
                    Toast.makeText(this, "Failed to load notifications", Toast.LENGTH_SHORT).show();
                });
            }
            exec.shutdown();
        });
    }
}
