package com.smarzbd.app.models;

public class Product {
    public int id;
    public String name;
    public String description;
    public double price;
    public double old_price;
    public int stock;
    public String image;
    public String main_image;
    public int category_id;
    public double rating;
    public int sales_count;
    public int discount;
    public String created_at;

    public String getImageUrl() {
        String img = (image != null && !image.isEmpty()) ? image : main_image;
        if (img == null || img.isEmpty()) return "";
        if (img.startsWith("http")) return img;
        return com.smarzbd.app.network.ApiClient.BASE_URL + "/uploads/products/" + img;
    }

    public double getDiscountedPrice() {
        if (discount > 0) return price - (price * discount / 100.0);
        return price;
    }
}
