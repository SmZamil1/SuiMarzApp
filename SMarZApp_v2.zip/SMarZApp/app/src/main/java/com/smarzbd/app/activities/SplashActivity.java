package com.smarzbd.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.view.animation.AnimationSet;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.smarzbd.app.R;
import com.smarzbd.app.network.ApiClient;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);

        TextView tvLogo = findViewById(R.id.tv_logo);
        TextView tvTagline = findViewById(R.id.tv_tagline);

        // Animate logo
        AnimationSet anim = new AnimationSet(true);
        ScaleAnimation scale = new ScaleAnimation(0.5f, 1f, 0.5f, 1f,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        scale.setDuration(600);
        AlphaAnimation alpha = new AlphaAnimation(0f, 1f);
        alpha.setDuration(600);
        anim.addAnimation(scale);
        anim.addAnimation(alpha);
        tvLogo.startAnimation(anim);

        AlphaAnimation fadeTagline = new AlphaAnimation(0f, 1f);
        fadeTagline.setDuration(800);
        fadeTagline.setStartOffset(400);
        fadeTagline.setFillAfter(true);
        tvTagline.startAnimation(fadeTagline);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }, 1800);
    }
}
