package com.smarzbd.app.activities;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.smarzbd.app.R;
import com.smarzbd.app.adapters.ProductAdapter;
import com.smarzbd.app.models.Product;
import com.smarzbd.app.network.ApiClient;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SearchActivity extends AppCompatActivity {

    private EditText etSearch;
    private RecyclerView rvResults;
    private LinearLayout layoutEmpty;
    private final List<Product> results = new ArrayList<>();
    private ProductAdapter adapter;
    private final Gson gson = new Gson();
    private Handler searchHandler = new Handler(Looper.getMainLooper());
    private Runnable searchRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        etSearch = findViewById(R.id.et_search);
        rvResults = findViewById(R.id.rv_results);
        layoutEmpty = findViewById(R.id.layout_empty);

        rvResults.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new ProductAdapter(results, this);
        rvResults.setAdapter(adapter);

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                if (searchRunnable != null) searchHandler.removeCallbacks(searchRunnable);
                searchRunnable = () -> search(s.toString().trim());
                searchHandler.postDelayed(searchRunnable, 400);
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        etSearch.requestFocus();
    }

    private void search(String query) {
        if (query.length() < 2) {
            results.clear();
            adapter.notifyDataSetChanged();
            layoutEmpty.setVisibility(View.GONE);
            return;
        }
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String resp = ApiClient.getInstance(this).get("/api/get_all_products.php");
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                List<Product> list = new ArrayList<>();
                String q = query.toLowerCase();
                // Handle both {products:[]} and {success:true, products:[]}
                JsonArray arr = null;
                if (obj.has("products") && obj.get("products").isJsonArray()) {
                    arr = obj.getAsJsonArray("products");
                }
                if (arr != null) {
                    for (int i = 0; i < arr.size(); i++) {
                        Product p = gson.fromJson(arr.get(i), Product.class);
                        if (p.name != null && p.name.toLowerCase().contains(q)) list.add(p);
                        else if (p.description != null && p.description.toLowerCase().contains(q)) list.add(p);
                    }
                }
                new Handler(Looper.getMainLooper()).post(() -> {
                    results.clear(); results.addAll(list);
                    adapter.notifyDataSetChanged();
                    layoutEmpty.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
                });
            } catch (Exception e) { e.printStackTrace(); }
            exec.shutdown();
        });
    }
}
