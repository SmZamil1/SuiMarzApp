package com.smarzbd.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.smarzbd.app.R;
import com.smarzbd.app.models.Category;

import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.VH> {

    public interface OnCategoryClick { void onClick(Category cat); }

    private final List<Category> categories;
    private final Context context;
    private final OnCategoryClick listener;

    public CategoryAdapter(List<Category> categories, Context context, OnCategoryClick listener) {
        this.categories = categories;
        this.context = context;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_category, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Category c = categories.get(pos);
        h.tvName.setText(c.name);
        String imgUrl = c.getImageUrl();
        if (!imgUrl.isEmpty()) {
            Glide.with(context).load(imgUrl)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .centerCrop()
                    .placeholder(R.drawable.placeholder_category)
                    .into(h.iv);
        } else {
            h.iv.setImageResource(R.drawable.placeholder_category);
        }
        h.itemView.setOnClickListener(v -> { if (listener != null) listener.onClick(c); });
    }

    @Override
    public int getItemCount() { return categories.size(); }

    static class VH extends RecyclerView.ViewHolder {
        ImageView iv; TextView tvName;
        VH(View v) { super(v); iv = v.findViewById(R.id.iv_category); tvName = v.findViewById(R.id.tv_name); }
    }
}
