package com.smarzbd.app.models;

public class Notification {
    public int id;
    public String title;
    public String message;
    public String type;
    public int is_read;
    public String created_at;
}
