package com.smarzbd.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.smarzbd.app.R;
import com.smarzbd.app.models.Notification;

import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.VH> {

    private final List<Notification> items;
    private final Context context;

    public NotificationAdapter(List<Notification> items, Context context) {
        this.items = items; this.context = context;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_notification, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Notification n = items.get(pos);
        h.tvTitle.setText(n.title);
        h.tvMessage.setText(n.message);
        h.tvDate.setText(n.created_at);
        h.itemView.setAlpha(n.is_read == 1 ? 0.7f : 1f);
        h.tvDot.setVisibility(n.is_read == 0 ? View.VISIBLE : View.INVISIBLE);
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvTitle, tvMessage, tvDate, tvDot;
        VH(View v) {
            super(v);
            tvTitle = v.findViewById(R.id.tv_title);
            tvMessage = v.findViewById(R.id.tv_message);
            tvDate = v.findViewById(R.id.tv_date);
            tvDot = v.findViewById(R.id.tv_dot);
        }
    }
}
