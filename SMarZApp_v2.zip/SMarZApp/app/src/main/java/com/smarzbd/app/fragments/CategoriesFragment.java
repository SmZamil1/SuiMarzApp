package com.smarzbd.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.smarzbd.app.R;
import com.smarzbd.app.activities.AllProductsActivity;
import com.smarzbd.app.adapters.CategoryAdapter;
import com.smarzbd.app.models.Category;
import com.smarzbd.app.network.ApiClient;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CategoriesFragment extends Fragment {

    private RecyclerView rvCategories;
    private SwipeRefreshLayout swipeRefresh;
    private final List<Category> categories = new ArrayList<>();
    private CategoryAdapter adapter;
    private final Gson gson = new Gson();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_categories, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rvCategories = view.findViewById(R.id.rv_categories);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);

        rvCategories.setLayoutManager(new GridLayoutManager(getContext(), 2));
        adapter = new CategoryAdapter(categories, getContext(), cat -> {
            Intent i = new Intent(getActivity(), AllProductsActivity.class);
            i.putExtra("category_id", cat.id);
            i.putExtra("category_name", cat.name);
            startActivity(i);
        });
        rvCategories.setAdapter(adapter);

        swipeRefresh.setColorSchemeResources(R.color.primary, R.color.accent);
        swipeRefresh.setOnRefreshListener(this::loadCategories);
        loadCategories();
    }

    private void loadCategories() {
        swipeRefresh.setRefreshing(true);
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String resp = ApiClient.getInstance(requireContext()).get("/api/get_categories.php");
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                List<Category> list = new ArrayList<>();
                if (obj.has("categories")) {
                    JsonArray arr = obj.getAsJsonArray("categories");
                    for (int i = 0; i < arr.size(); i++)
                        list.add(gson.fromJson(arr.get(i), Category.class));
                }
                new Handler(Looper.getMainLooper()).post(() -> {
                    categories.clear(); categories.addAll(list);
                    adapter.notifyDataSetChanged();
                    swipeRefresh.setRefreshing(false);
                });
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    swipeRefresh.setRefreshing(false);
                    Toast.makeText(getContext(), "Failed to load categories", Toast.LENGTH_SHORT).show();
                });
            }
            exec.shutdown();
        });
    }
}
