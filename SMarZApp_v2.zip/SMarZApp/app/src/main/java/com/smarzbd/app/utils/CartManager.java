package com.smarzbd.app.utils;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.smarzbd.app.network.ApiClient;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CartManager {

    public interface CartCountListener {
        void onCartCountChanged(int count);
    }

    private static CartManager instance;
    private final Context context;
    private CartCountListener listener;
    private int count = 0;

    private CartManager(Context ctx) { this.context = ctx.getApplicationContext(); }

    public static synchronized CartManager getInstance(Context ctx) {
        if (instance == null) instance = new CartManager(ctx);
        return instance;
    }

    public void setListener(CartCountListener l) { this.listener = l; }

    public int getCount() { return count; }

    public void refreshCount() {
        if (!ApiClient.getInstance(context).isLoggedIn()) {
            count = 0;
            notifyListener();
            return;
        }
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String resp = ApiClient.getInstance(context).get("/api/cart/get_cart.php");
                JsonObject obj = new Gson().fromJson(resp, JsonObject.class);
                if (obj.has("count")) {
                    count = obj.get("count").getAsInt();
                } else {
                    count = 0;
                }
            } catch (Exception e) {
                count = 0;
            }
            notifyListener();
            exec.shutdown();
        });
    }

    private void notifyListener() {
        if (listener != null) {
            new Handler(Looper.getMainLooper()).post(() -> listener.onCartCountChanged(count));
        }
    }

    public void increment() { count++; notifyListener(); }
    public void decrement() { if (count > 0) { count--; notifyListener(); } }
    public void reset() { count = 0; notifyListener(); }
}
