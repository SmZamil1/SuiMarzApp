package com.smarzbd.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.smarzbd.app.R;
import com.smarzbd.app.models.User;
import com.smarzbd.app.network.ApiClient;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LoginActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private Button btnLogin;
    private ProgressBar progressBar;
    private final Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        etEmail    = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        btnLogin   = findViewById(R.id.btn_login);
        progressBar = findViewById(R.id.progress_bar);

        btnLogin.setOnClickListener(v -> attemptLogin());
        findViewById(R.id.tv_register).setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));
        findViewById(R.id.btn_back).setOnClickListener(v -> finish());
    }

    private void attemptLogin() {
        String email    = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (email.isEmpty())    { etEmail.setError("Email required");    etEmail.requestFocus();    return; }
        if (password.isEmpty()) { etPassword.setError("Password required"); etPassword.requestFocus(); return; }

        setLoading(true);

        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                // Step 1: warm-up GET to establish session & bypass bot check
                try { ApiClient.getInstance(this).get("/api/auth/login.php"); } catch (Exception ignored) {}

                // Step 2: actual login POST
                Map<String, String> fields = new HashMap<>();
                fields.put("email", email);
                fields.put("password", password);
                String resp = ApiClient.getInstance(this).postForm("/api/auth/login.php", fields);

                JsonObject obj;
                try {
                    obj = gson.fromJson(resp, JsonObject.class);
                } catch (Exception e) {
                    throw new Exception("Server returned unexpected response. Please try again.");
                }

                boolean success = obj.has("success") && obj.get("success").getAsBoolean();
                new Handler(Looper.getMainLooper()).post(() -> {
                    setLoading(false);
                    if (success) {
                        User user = new User(
                                obj.get("user_id").getAsInt(),
                                obj.has("name")  && !obj.get("name").isJsonNull()  ? obj.get("name").getAsString()  : "",
                                obj.has("email") && !obj.get("email").isJsonNull() ? obj.get("email").getAsString() : "",
                                obj.has("phone") && !obj.get("phone").isJsonNull() ? obj.get("phone").getAsString() : ""
                        );
                        ApiClient.getInstance(this).saveUser(user);
                        Toast.makeText(this, "Welcome, " + user.name + "!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    } else {
                        String msg = obj.has("message") ? obj.get("message").getAsString() : "Login failed";
                        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                String errMsg = e.getMessage() != null ? e.getMessage() : "Network error. Please try again.";
                new Handler(Looper.getMainLooper()).post(() -> {
                    setLoading(false);
                    Toast.makeText(this, errMsg, Toast.LENGTH_LONG).show();
                });
            }
            exec.shutdown();
        });
    }

    private void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnLogin.setEnabled(!loading);
        btnLogin.setText(loading ? "Logging in..." : "Login");
    }
}
