package com.smarzbd.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.smarzbd.app.R;
import com.smarzbd.app.adapters.ProductAdapter;
import com.smarzbd.app.models.Product;
import com.smarzbd.app.network.ApiClient;
import com.smarzbd.app.utils.CartManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProductDetailActivity extends AppCompatActivity {

    private ImageView ivProduct;
    private TextView tvName, tvPrice, tvOldPrice, tvStock, tvDescription, tvDiscount;
    private Button btnAddToCart, btnBuyNow;
    private LinearLayout layoutSizes, sizeButtonContainer;
    private ProgressBar progressBar;
    private RecyclerView rvRelated;
    private TextView tvQuantity;
    private View btnMinus, btnPlus;

    private Product product;
    private String selectedSize = "";
    private int quantity = 1;
    private final Gson gson = new Gson();
    private final List<Product> related = new ArrayList<>();
    private ProductAdapter relatedAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        ivProduct = findViewById(R.id.iv_product);
        tvName = findViewById(R.id.tv_name);
        tvPrice = findViewById(R.id.tv_price);
        tvOldPrice = findViewById(R.id.tv_old_price);
        tvStock = findViewById(R.id.tv_stock);
        tvDescription = findViewById(R.id.tv_description);
        tvDiscount = findViewById(R.id.tv_discount);
        btnAddToCart = findViewById(R.id.btn_add_to_cart);
        btnBuyNow = findViewById(R.id.btn_buy_now);
        layoutSizes = findViewById(R.id.layout_sizes);
        sizeButtonContainer = findViewById(R.id.size_button_container);
        progressBar = findViewById(R.id.progress_bar);
        rvRelated = findViewById(R.id.rv_related);
        tvQuantity = findViewById(R.id.tv_quantity);
        btnMinus = findViewById(R.id.btn_minus);
        btnPlus = findViewById(R.id.btn_plus);

        findViewById(R.id.btn_back).setOnClickListener(v -> onBackPressed());

        rvRelated.setLayoutManager(new GridLayoutManager(this, 2));
        relatedAdapter = new ProductAdapter(related, this);
        rvRelated.setAdapter(relatedAdapter);
        rvRelated.setNestedScrollingEnabled(false);

        btnMinus.setOnClickListener(v -> {
            if (quantity > 1) { quantity--; tvQuantity.setText(String.valueOf(quantity)); }
        });
        btnPlus.setOnClickListener(v -> {
            int maxStock = product != null ? product.stock : 99;
            if (quantity < maxStock) { quantity++; tvQuantity.setText(String.valueOf(quantity)); }
        });

        btnAddToCart.setOnClickListener(v -> addToCart(false));
        btnBuyNow.setOnClickListener(v -> addToCart(true));

        int productId = getIntent().getIntExtra("product_id", 0);
        if (productId > 0) loadProduct(productId);
        else finish();
    }

    private void loadProduct(int id) {
        progressBar.setVisibility(View.VISIBLE);
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String body = "{\"product_id\":" + id + "}";
                String resp = ApiClient.getInstance(this).postJson("/api/get_products.php", body);
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                Product p = null;
                if (obj.has("products")) {
                    JsonArray arr = obj.getAsJsonArray("products");
                    if (arr.size() > 0) p = gson.fromJson(arr.get(0), Product.class);
                }
                Product finalProduct = p;
                new Handler(Looper.getMainLooper()).post(() -> {
                    progressBar.setVisibility(View.GONE);
                    if (finalProduct != null) {
                        product = finalProduct;
                        displayProduct();
                        loadSizes(id);
                        loadRelated(finalProduct.category_id, id);
                    } else {
                        Toast.makeText(this, "Product not found", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(this, "Network error", Toast.LENGTH_SHORT).show();
                    finish();
                });
            }
            exec.shutdown();
        });
    }

    private void displayProduct() {
        tvName.setText(product.name);
        tvDescription.setText(product.description);

        // Fix price display — use double directly, never parse from string
        double price = product.price;
        double discountedPrice = product.getDiscountedPrice();

        tvPrice.setText(String.format("৳%.0f", discountedPrice));

        if (product.discount > 0 && product.old_price > 0) {
            tvOldPrice.setVisibility(View.VISIBLE);
            tvOldPrice.setPaintFlags(tvOldPrice.getPaintFlags() | android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
            tvOldPrice.setText(String.format("৳%.0f", price));
            tvDiscount.setVisibility(View.VISIBLE);
            tvDiscount.setText("-" + product.discount + "%");
        } else if (product.old_price > 0 && product.old_price > price) {
            tvOldPrice.setVisibility(View.VISIBLE);
            tvOldPrice.setText(String.format("৳%.0f", product.old_price));
            tvDiscount.setVisibility(View.GONE);
        } else {
            tvOldPrice.setVisibility(View.GONE);
            tvDiscount.setVisibility(View.GONE);
        }

        if (product.stock > 0) {
            tvStock.setText("In Stock: " + product.stock);
            tvStock.setTextColor(getColor(R.color.green));
            btnAddToCart.setEnabled(true);
            btnBuyNow.setEnabled(true);
        } else {
            tvStock.setText("Out of Stock");
            tvStock.setTextColor(getColor(R.color.red));
            btnAddToCart.setEnabled(false);
            btnBuyNow.setEnabled(false);
        }

        String imgUrl = product.getImageUrl();
        if (!imgUrl.isEmpty()) {
            Glide.with(this)
                    .load(imgUrl)
                    .placeholder(R.drawable.placeholder_product)
                    .error(R.drawable.placeholder_product)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .centerCrop()
                    .into(ivProduct);
        }
    }

    private void loadSizes(int productId) {
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String body = "{\"product_id\":" + productId + "}";
                String resp = ApiClient.getInstance(this).postJson("/api/get_product_sizes.php", body);
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                boolean hasSizes = obj.has("has_sizes") && obj.get("has_sizes").getAsBoolean();
                List<String> sizes = new ArrayList<>();
                if (hasSizes && obj.has("sizes")) {
                    JsonArray arr = obj.getAsJsonArray("sizes");
                    for (int i = 0; i < arr.size(); i++) sizes.add(arr.get(i).getAsString());
                }
                new Handler(Looper.getMainLooper()).post(() -> {
                    if (hasSizes && !sizes.isEmpty()) {
                        layoutSizes.setVisibility(View.VISIBLE);
                        buildSizeButtons(sizes);
                    } else {
                        layoutSizes.setVisibility(View.GONE);
                    }
                });
            } catch (Exception e) { e.printStackTrace(); }
            exec.shutdown();
        });
    }

    private void buildSizeButtons(List<String> sizes) {
        sizeButtonContainer.removeAllViews();
        for (String size : sizes) {
            Button btn = new Button(this);
            btn.setText(size);
            btn.setTextSize(13);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 16, 0);
            btn.setLayoutParams(lp);
            btn.setBackgroundResource(R.drawable.size_btn_unselected);
            btn.setOnClickListener(v -> {
                selectedSize = size;
                for (int i = 0; i < sizeButtonContainer.getChildCount(); i++) {
                    sizeButtonContainer.getChildAt(i).setBackgroundResource(R.drawable.size_btn_unselected);
                }
                btn.setBackgroundResource(R.drawable.size_btn_selected);
            });
            sizeButtonContainer.addView(btn);
        }
        // Auto-select first
        if (!sizes.isEmpty()) {
            selectedSize = sizes.get(0);
            if (sizeButtonContainer.getChildCount() > 0)
                sizeButtonContainer.getChildAt(0).setBackgroundResource(R.drawable.size_btn_selected);
        }
    }

    private void loadRelated(int catId, int excludeId) {
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String body = "{\"type\":\"featured\",\"category\":\"" + catId + "\",\"limit\":6}";
                String resp = ApiClient.getInstance(this).postJson("/api/get_products.php", body);
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                List<Product> list = new ArrayList<>();
                if (obj.has("products")) {
                    JsonArray arr = obj.getAsJsonArray("products");
                    for (int i = 0; i < arr.size(); i++) {
                        Product p = gson.fromJson(arr.get(i), Product.class);
                        if (p.id != excludeId) list.add(p);
                    }
                }
                new Handler(Looper.getMainLooper()).post(() -> {
                    related.clear(); related.addAll(list);
                    relatedAdapter.notifyDataSetChanged();
                });
            } catch (Exception e) { e.printStackTrace(); }
            exec.shutdown();
        });
    }

    private void addToCart(boolean buyNow) {
        if (!ApiClient.getInstance(this).isLoggedIn()) {
            startActivity(new Intent(this, LoginActivity.class));
            return;
        }
        if (product == null) return;

        // Check if size required
        if (layoutSizes.getVisibility() == View.VISIBLE && selectedSize.isEmpty()) {
            Toast.makeText(this, "Please select a size", Toast.LENGTH_SHORT).show();
            return;
        }

        btnAddToCart.setEnabled(false);
        btnBuyNow.setEnabled(false);

        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String body = "{\"product_id\":" + product.id +
                        ",\"quantity\":" + quantity +
                        ",\"size\":\"" + selectedSize + "\"}";
                String resp = ApiClient.getInstance(this).postJson("/api/add_to_cart.php", body);
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                boolean success = obj.has("success") && obj.get("success").getAsBoolean();
                String msg = obj.has("message") ? obj.get("message").getAsString() : "";

                new Handler(Looper.getMainLooper()).post(() -> {
                    btnAddToCart.setEnabled(true);
                    btnBuyNow.setEnabled(true);
                    if (success) {
                        CartManager.getInstance(this).increment();
                        if (buyNow) {
                            // Go to cart/checkout
                            if (MainActivity.instance != null) {
                                finish();
                                MainActivity.instance.navigateToCart();
                            } else {
                                Intent intent = new Intent(this, MainActivity.class);
                                intent.putExtra("open_cart", true);
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);
                            }
                        } else {
                            Toast.makeText(this, "✓ Added to cart!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, msg.isEmpty() ? "Failed to add to cart" : msg, Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    btnAddToCart.setEnabled(true);
                    btnBuyNow.setEnabled(true);
                    Toast.makeText(this, "Network error", Toast.LENGTH_SHORT).show();
                });
            }
            exec.shutdown();
        });
    }
}
