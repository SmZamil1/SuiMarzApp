package com.smarzbd.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.smarzbd.app.R;
import com.smarzbd.app.activities.LoginActivity;
import com.smarzbd.app.models.User;
import com.smarzbd.app.network.ApiClient;
import com.smarzbd.app.utils.CartManager;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProfileFragment extends Fragment {

    private TextView tvName, tvEmail, tvPhone;
    private LinearLayout layoutLoggedIn, layoutGuest;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvName = view.findViewById(R.id.tv_name);
        tvEmail = view.findViewById(R.id.tv_email);
        tvPhone = view.findViewById(R.id.tv_phone);
        layoutLoggedIn = view.findViewById(R.id.layout_logged_in);
        layoutGuest = view.findViewById(R.id.layout_guest);

        view.findViewById(R.id.btn_login_guest).setOnClickListener(v ->
                startActivity(new Intent(getActivity(), LoginActivity.class)));

        view.findViewById(R.id.btn_logout).setOnClickListener(v -> confirmLogout());

        view.findViewById(R.id.btn_my_orders).setOnClickListener(v -> {
            if (getActivity() instanceof com.smarzbd.app.activities.MainActivity) {
                ((com.smarzbd.app.activities.MainActivity) getActivity()).navigateToOrders();
            }
        });

        view.findViewById(R.id.btn_change_password).setOnClickListener(v ->
                Toast.makeText(getContext(), "Visit website to change password", Toast.LENGTH_LONG).show());

        loadProfile();
    }

    private void loadProfile() {
        ApiClient api = ApiClient.getInstance(requireContext());
        if (!api.isLoggedIn()) {
            layoutGuest.setVisibility(View.VISIBLE);
            layoutLoggedIn.setVisibility(View.GONE);
            return;
        }
        layoutGuest.setVisibility(View.GONE);
        layoutLoggedIn.setVisibility(View.VISIBLE);

        User user = api.getSavedUser();
        if (user != null) {
            tvName.setText(user.name != null ? user.name : "");
            tvEmail.setText(user.email != null ? user.email : "");
            tvPhone.setText(user.phone != null ? user.phone : "");
        }

        // Refresh from server
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String resp = api.get("/api/auth/profile.php");
                JsonObject obj = new Gson().fromJson(resp, JsonObject.class);
                if (obj.has("success") && obj.get("success").getAsBoolean()) {
                    User fresh = new User(
                            obj.get("user_id").getAsInt(),
                            obj.has("name") ? obj.get("name").getAsString() : "",
                            obj.has("email") ? obj.get("email").getAsString() : "",
                            obj.has("phone") ? obj.get("phone").getAsString() : ""
                    );
                    api.saveUser(fresh);
                    new Handler(Looper.getMainLooper()).post(() -> {
                        tvName.setText(fresh.name);
                        tvEmail.setText(fresh.email);
                        tvPhone.setText(fresh.phone);
                    });
                }
            } catch (Exception e) { e.printStackTrace(); }
            exec.shutdown();
        });
    }

    private void confirmLogout() {
        new AlertDialog.Builder(requireContext())
                .setTitle("Logout")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Logout", (d, w) -> performLogout())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void performLogout() {
        // Clear local session FIRST before any network call
        ApiClient api = ApiClient.getInstance(requireContext());
        CartManager.getInstance(requireContext()).reset();

        // Run server logout in background — never block UI thread
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                api.logout(); // does network + clears prefs
            } catch (Exception e) {
                e.printStackTrace();
            }
            new Handler(Looper.getMainLooper()).post(() -> {
                // Navigate to login
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            });
            exec.shutdown();
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        loadProfile();
    }
}
