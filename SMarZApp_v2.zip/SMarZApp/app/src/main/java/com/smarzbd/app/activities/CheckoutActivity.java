package com.smarzbd.app.activities;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.smarzbd.app.R;
import com.smarzbd.app.models.CartItem;
import com.smarzbd.app.network.ApiClient;
import com.smarzbd.app.utils.CartManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CheckoutActivity extends AppCompatActivity {

    private EditText etAddress, etPhone, etNote, etPaymentNumber;
    private RadioGroup rgPayment;
    private RadioButton rbCOD, rbBkash, rbNagad;
    private Button btnPlaceOrder;
    private ProgressBar progressBar;
    private TextView tvSubtotal, tvShipping, tvTotal, tvBkashNumber, tvNagadNumber;
    private LinearLayout layoutPaymentNumber, layoutOrderItems;
    private LinearLayout layoutBkashInfo, layoutNagadInfo;

    private final List<CartItem> cartItems = new ArrayList<>();
    private double cartTotal = 0;
    private double shippingFee = 0;
    private String bkashNumber = "";
    private String nagadNumber = "";
    private final Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        etAddress = findViewById(R.id.et_address);
        etPhone = findViewById(R.id.et_phone);
        etNote = findViewById(R.id.et_note);
        etPaymentNumber = findViewById(R.id.et_payment_number);
        rgPayment = findViewById(R.id.rg_payment);
        rbCOD = findViewById(R.id.rb_cod);
        rbBkash = findViewById(R.id.rb_bkash);
        rbNagad = findViewById(R.id.rb_nagad);
        btnPlaceOrder = findViewById(R.id.btn_place_order);
        progressBar = findViewById(R.id.progress_bar);
        tvSubtotal = findViewById(R.id.tv_subtotal);
        tvShipping = findViewById(R.id.tv_shipping);
        tvTotal = findViewById(R.id.tv_total);
        tvBkashNumber = findViewById(R.id.tv_bkash_number);
        tvNagadNumber = findViewById(R.id.tv_nagad_number);
        layoutPaymentNumber = findViewById(R.id.layout_payment_number);
        layoutOrderItems = findViewById(R.id.layout_order_items);
        layoutBkashInfo = findViewById(R.id.layout_bkash_info);
        layoutNagadInfo = findViewById(R.id.layout_nagad_info);

        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        // Pre-fill phone from profile
        com.smarzbd.app.models.User user = ApiClient.getInstance(this).getSavedUser();
        if (user != null && user.phone != null && !user.phone.isEmpty())
            etPhone.setText(user.phone);

        rgPayment.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rb_cod) {
                layoutPaymentNumber.setVisibility(View.GONE);
                layoutBkashInfo.setVisibility(View.GONE);
                layoutNagadInfo.setVisibility(View.GONE);
            } else if (checkedId == R.id.rb_bkash) {
                layoutPaymentNumber.setVisibility(View.VISIBLE);
                layoutBkashInfo.setVisibility(View.VISIBLE);
                layoutNagadInfo.setVisibility(View.GONE);
                ((TextView) findViewById(R.id.tv_payment_label)).setText("bKash Payment Number");
            } else if (checkedId == R.id.rb_nagad) {
                layoutPaymentNumber.setVisibility(View.VISIBLE);
                layoutBkashInfo.setVisibility(View.GONE);
                layoutNagadInfo.setVisibility(View.VISIBLE);
                ((TextView) findViewById(R.id.tv_payment_label)).setText("Nagad Payment Number");
            }
        });

        btnPlaceOrder.setOnClickListener(v -> placeOrder());

        loadCart();
        loadPaymentSettings();
    }

    private void loadCart() {
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String resp = ApiClient.getInstance(this).get("/api/cart/get_cart.php");
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                List<CartItem> items = new ArrayList<>();
                double total = 0;
                if (obj.has("success") && obj.get("success").getAsBoolean()) {
                    if (obj.has("items")) {
                        JsonArray arr = obj.getAsJsonArray("items");
                        for (int i = 0; i < arr.size(); i++)
                            items.add(gson.fromJson(arr.get(i), CartItem.class));
                    }
                    total = obj.has("total") ? obj.get("total").getAsDouble() : 0;
                }
                double finalTotal = total;
                new Handler(Looper.getMainLooper()).post(() -> {
                    cartItems.clear();
                    cartItems.addAll(items);
                    cartTotal = finalTotal;
                    buildOrderSummary();
                    updateTotals();
                });
            } catch (Exception e) { e.printStackTrace(); }
            exec.shutdown();
        });
    }

    private void loadPaymentSettings() {
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String resp = ApiClient.getInstance(this).get("/api/get_payment_settings.php");
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                if (obj.has("success") && obj.get("success").getAsBoolean()) {
                    bkashNumber = obj.has("bkash_number") ? obj.get("bkash_number").getAsString() : "";
                    nagadNumber = obj.has("nagad_number") ? obj.get("nagad_number").getAsString() : "";
                }
                new Handler(Looper.getMainLooper()).post(() -> {
                    tvBkashNumber.setText("Send to: " + bkashNumber);
                    tvNagadNumber.setText("Send to: " + nagadNumber);
                });
            } catch (Exception e) { e.printStackTrace(); }
            exec.shutdown();
        });
    }

    private void buildOrderSummary() {
        layoutOrderItems.removeAllViews();
        for (CartItem item : cartItems) {
            TextView tv = new TextView(this);
            String sizeText = (item.size != null && !item.size.isEmpty()) ? " (" + item.size + ")" : "";
            tv.setText(item.name + sizeText + " × " + item.quantity + "  —  ৳" +
                    String.format("%.0f", item.price * item.quantity));
            tv.setTextSize(14);
            tv.setPadding(0, 8, 0, 8);
            tv.setTextColor(getColor(R.color.text_secondary));
            layoutOrderItems.addView(tv);
        }
    }

    private void updateTotals() {
        double total = cartTotal + shippingFee;
        tvSubtotal.setText(String.format("৳%.2f", cartTotal));
        tvShipping.setText(shippingFee > 0 ? String.format("৳%.2f", shippingFee) : "Free");
        tvTotal.setText(String.format("৳%.2f", total));
    }

    private void placeOrder() {
        String address = etAddress.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String note = etNote.getText().toString().trim();

        if (address.isEmpty()) { etAddress.setError("Address required"); etAddress.requestFocus(); return; }
        if (phone.isEmpty()) { etPhone.setError("Phone required"); etPhone.requestFocus(); return; }
        if (cartItems.isEmpty()) { Toast.makeText(this, "Cart is empty", Toast.LENGTH_SHORT).show(); return; }

        int selectedId = rgPayment.getCheckedRadioButtonId();
        String paymentMethod = "cod";
        String paymentNumber = "";

        if (selectedId == R.id.rb_bkash) {
            paymentMethod = "bkash";
            paymentNumber = etPaymentNumber.getText().toString().trim();
            if (paymentNumber.isEmpty()) {
                etPaymentNumber.setError("Enter your bKash number");
                etPaymentNumber.requestFocus();
                return;
            }
        } else if (selectedId == R.id.rb_nagad) {
            paymentMethod = "nagad";
            paymentNumber = etPaymentNumber.getText().toString().trim();
            if (paymentNumber.isEmpty()) {
                etPaymentNumber.setError("Enter your Nagad number");
                etPaymentNumber.requestFocus();
                return;
            }
        }

        setLoading(true);
        String finalPaymentMethod = paymentMethod;
        String finalPaymentNumber = paymentNumber;

        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                Map<String, String> fields = new HashMap<>();
                fields.put("address", address);
                fields.put("phone", phone);
                fields.put("note", note);
                fields.put("payment_method", finalPaymentMethod);
                fields.put("payment_number", finalPaymentNumber);

                String resp = ApiClient.getInstance(this).postForm("/api/handle_payment.php", fields);
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                boolean success = obj.has("success") && obj.get("success").getAsBoolean();
                String msg = obj.has("message") ? obj.get("message").getAsString() : "";
                String orderNum = obj.has("order_number") ? obj.get("order_number").getAsString() : "";

                new Handler(Looper.getMainLooper()).post(() -> {
                    setLoading(false);
                    if (success) {
                        CartManager.getInstance(this).reset();
                        Toast.makeText(this, "Order placed! " + orderNum, Toast.LENGTH_LONG).show();
                        finish();
                        if (MainActivity.instance != null)
                            MainActivity.instance.navigateToOrders();
                    } else {
                        Toast.makeText(this, msg.isEmpty() ? "Order failed" : msg, Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    setLoading(false);
                    Toast.makeText(this, "Network error. Please try again.", Toast.LENGTH_LONG).show();
                });
            }
            exec.shutdown();
        });
    }

    private void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnPlaceOrder.setEnabled(!loading);
        btnPlaceOrder.setText(loading ? "Placing Order..." : "Place Order");
    }
}
