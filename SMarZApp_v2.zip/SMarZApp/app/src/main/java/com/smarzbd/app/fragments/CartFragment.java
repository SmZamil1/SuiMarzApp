package com.smarzbd.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.smarzbd.app.R;
import com.smarzbd.app.activities.CheckoutActivity;
import com.smarzbd.app.activities.LoginActivity;
import com.smarzbd.app.adapters.CartAdapter;
import com.smarzbd.app.models.CartItem;
import com.smarzbd.app.network.ApiClient;
import com.smarzbd.app.utils.CartManager;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CartFragment extends Fragment {

    private RecyclerView rvCart;
    private TextView tvTotal, tvEmpty, tvItemCount;
    private Button btnCheckout;
    private SwipeRefreshLayout swipeRefresh;
    private LinearLayout layoutCartContent, layoutEmpty, layoutLoginRequired;
    private final List<CartItem> cartItems = new ArrayList<>();
    private CartAdapter adapter;
    private final Gson gson = new Gson();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cart, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        rvCart = view.findViewById(R.id.rv_cart);
        tvTotal = view.findViewById(R.id.tv_total);
        tvItemCount = view.findViewById(R.id.tv_item_count);
        btnCheckout = view.findViewById(R.id.btn_checkout);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        layoutCartContent = view.findViewById(R.id.layout_cart_content);
        layoutEmpty = view.findViewById(R.id.layout_empty);
        layoutLoginRequired = view.findViewById(R.id.layout_login_required);

        rvCart.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new CartAdapter(cartItems, getContext(), this::onItemRemoved);
        rvCart.setAdapter(adapter);

        swipeRefresh.setColorSchemeResources(R.color.primary, R.color.accent);
        swipeRefresh.setOnRefreshListener(this::loadCart);

        btnCheckout.setOnClickListener(v -> {
            if (cartItems.isEmpty()) {
                Toast.makeText(getContext(), "Cart is empty", Toast.LENGTH_SHORT).show();
                return;
            }
            startActivity(new Intent(getActivity(), CheckoutActivity.class));
        });

        view.findViewById(R.id.btn_login).setOnClickListener(v ->
                startActivity(new Intent(getActivity(), LoginActivity.class)));

        loadCart();
    }

    private void loadCart() {
        if (!ApiClient.getInstance(requireContext()).isLoggedIn()) {
            layoutLoginRequired.setVisibility(View.VISIBLE);
            layoutCartContent.setVisibility(View.GONE);
            layoutEmpty.setVisibility(View.GONE);
            swipeRefresh.setRefreshing(false);
            return;
        }
        layoutLoginRequired.setVisibility(View.GONE);
        swipeRefresh.setRefreshing(true);

        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                String resp = ApiClient.getInstance(requireContext()).get("/api/cart/get_cart.php");
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                List<CartItem> items = new ArrayList<>();
                double total = 0;
                if (obj.has("success") && obj.get("success").getAsBoolean()) {
                    if (obj.has("items")) {
                        JsonArray arr = obj.getAsJsonArray("items");
                        for (int i = 0; i < arr.size(); i++)
                            items.add(gson.fromJson(arr.get(i), CartItem.class));
                    }
                    total = obj.has("total") ? obj.get("total").getAsDouble() : 0;
                }
                double finalTotal = total;
                new Handler(Looper.getMainLooper()).post(() -> {
                    cartItems.clear();
                    cartItems.addAll(items);
                    adapter.notifyDataSetChanged();
                    tvTotal.setText(String.format("৳%.2f", finalTotal));
                    tvItemCount.setText(items.size() + " item" + (items.size() != 1 ? "s" : ""));
                    if (items.isEmpty()) {
                        layoutEmpty.setVisibility(View.VISIBLE);
                        layoutCartContent.setVisibility(View.GONE);
                    } else {
                        layoutEmpty.setVisibility(View.GONE);
                        layoutCartContent.setVisibility(View.VISIBLE);
                    }
                    swipeRefresh.setRefreshing(false);
                    CartManager.getInstance(requireContext()).refreshCount();
                });
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    swipeRefresh.setRefreshing(false);
                    Toast.makeText(getContext(), "Failed to load cart", Toast.LENGTH_SHORT).show();
                });
            }
            exec.shutdown();
        });
    }

    private void onItemRemoved() {
        loadCart();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadCart();
    }
}
