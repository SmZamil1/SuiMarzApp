package com.smarzbd.app.network;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.smarzbd.app.models.User;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.FormBody;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ApiClient {

    public static final String BASE_URL = "https://marzbd.42web.io";
    public static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    // InfinityFree requires these headers or it returns bot-protection HTML
    private static final String USER_AGENT =
            "Mozilla/5.0 (Linux; Android 11; Pixel 5) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/120.0.0.0 Mobile Safari/537.36";

    private static final String PREFS_NAME = "SMarZPrefs";
    private static final String KEY_USER   = "logged_user";

    private static ApiClient instance;
    private final OkHttpClient client;
    private final Context context;
    private final Gson gson = new Gson();

    // In-memory cookie store
    private final Map<String, List<Cookie>> cookieStore = new HashMap<>();

    private ApiClient(Context ctx) {
        this.context = ctx.getApplicationContext();
        client = new OkHttpClient.Builder()
                .connectTimeout(25, TimeUnit.SECONDS)
                .readTimeout(35, TimeUnit.SECONDS)
                .writeTimeout(25, TimeUnit.SECONDS)
                .cookieJar(new CookieJar() {
                    @Override
                    public void saveFromResponse(HttpUrl url, List<Cookie> cookies) {
                        cookieStore.put(url.host(), cookies);
                        for (Cookie c : cookies) {
                            if (c.name().equals("PHPSESSID")) {
                                getPrefs().edit()
                                        .putString("PHPSESSID", c.value() + "|" + url.host())
                                        .apply();
                            }
                        }
                    }
                    @Override
                    public List<Cookie> loadForRequest(HttpUrl url) {
                        List<Cookie> cookies = cookieStore.get(url.host());
                        if (cookies != null) return cookies;
                        String saved = getPrefs().getString("PHPSESSID", null);
                        if (saved != null && saved.contains("|")) {
                            String[] parts = saved.split("\\|");
                            if (parts.length == 2 && url.host().equals(parts[1])) {
                                List<Cookie> restored = new ArrayList<>();
                                restored.add(new Cookie.Builder()
                                        .name("PHPSESSID").value(parts[0])
                                        .domain(url.host()).path("/").build());
                                cookieStore.put(url.host(), restored);
                                return restored;
                            }
                        }
                        return new ArrayList<>();
                    }
                })
                .build();
    }

    public static synchronized ApiClient getInstance(Context ctx) {
        if (instance == null) instance = new ApiClient(ctx);
        return instance;
    }

    private SharedPreferences getPrefs() {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // ─── Add browser-like headers to every request ─────────────────────────
    private Request.Builder baseBuilder(String url) {
        return new Request.Builder()
                .url(url)
                .header("User-Agent", USER_AGENT)
                .header("Accept", "application/json, text/plain, */*")
                .header("Accept-Language", "en-US,en;q=0.9")
                .header("Referer", BASE_URL + "/")
                .header("X-Requested-With", "XMLHttpRequest");
    }

    // ─── User session helpers ───────────────────────────────────────────────

    public void saveUser(User user) {
        getPrefs().edit().putString(KEY_USER, gson.toJson(user)).apply();
    }

    public User getSavedUser() {
        String json = getPrefs().getString(KEY_USER, null);
        if (json == null) return null;
        try { return gson.fromJson(json, User.class); } catch (Exception e) { return null; }
    }

    public boolean isLoggedIn() {
        return getSavedUser() != null;
    }

    public void logout() {
        getPrefs().edit().remove(KEY_USER).remove("PHPSESSID").apply();
        cookieStore.clear();
        try {
            Request req = baseBuilder(BASE_URL + "/api/auth/logout.php")
                    .post(new FormBody.Builder().build()).build();
            client.newCall(req).execute().close();
        } catch (Exception ignored) {}
    }

    // ─── HTTP helpers ───────────────────────────────────────────────────────

    /**
     * POST JSON body. Strips any HTML preamble InfinityFree may inject.
     */
    public String postJson(String path, String json) throws IOException {
        RequestBody body = RequestBody.create(json, JSON);
        Request req = baseBuilder(BASE_URL + path)
                .header("Content-Type", "application/json")
                .post(body).build();
        try (Response resp = client.newCall(req).execute()) {
            String raw = resp.body() != null ? resp.body().string() : "";
            return stripHtml(raw);
        }
    }

    /**
     * POST form fields. Strips any HTML preamble.
     */
    public String postForm(String path, Map<String, String> fields) throws IOException {
        FormBody.Builder builder = new FormBody.Builder();
        if (fields != null)
            for (Map.Entry<String, String> e : fields.entrySet())
                builder.add(e.getKey(), e.getValue());
        Request req = baseBuilder(BASE_URL + path).post(builder.build()).build();
        try (Response resp = client.newCall(req).execute()) {
            String raw = resp.body() != null ? resp.body().string() : "";
            return stripHtml(raw);
        }
    }

    /**
     * GET. Strips any HTML preamble.
     */
    public String get(String path) throws IOException {
        Request req = baseBuilder(BASE_URL + path).get().build();
        try (Response resp = client.newCall(req).execute()) {
            String raw = resp.body() != null ? resp.body().string() : "";
            return stripHtml(raw);
        }
    }

    /**
     * InfinityFree sometimes prepends HTML bot-check content before the JSON.
     * Find the first '{' or '[' and return from there.
     */
    private String stripHtml(String raw) {
        if (raw == null || raw.isEmpty()) return "{}";
        int jsonStart = -1;
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            if (c == '{' || c == '[') { jsonStart = i; break; }
        }
        if (jsonStart == -1) return "{}";
        return raw.substring(jsonStart).trim();
    }
}
