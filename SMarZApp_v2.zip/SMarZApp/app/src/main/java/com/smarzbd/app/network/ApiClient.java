package com.smarzbd.app.network;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.smarzbd.app.models.User;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.FormBody;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ApiClient {

    public static final String BASE_URL = "https://marzbd.42web.io";
    public static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    private static final String PREFS_NAME = "SMarZPrefs";
    private static final String KEY_COOKIES = "session_cookies";
    private static final String KEY_USER = "logged_user";

    private static ApiClient instance;
    private final OkHttpClient client;
    private final Context context;
    private final Gson gson = new Gson();

    // In-memory cookie store (persists per session)
    private final Map<String, List<Cookie>> cookieStore = new HashMap<>();

    private ApiClient(Context ctx) {
        this.context = ctx.getApplicationContext();
        client = new OkHttpClient.Builder()
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(20, TimeUnit.SECONDS)
                .cookieJar(new CookieJar() {
                    @Override
                    public void saveFromResponse(HttpUrl url, List<Cookie> cookies) {
                        cookieStore.put(url.host(), cookies);
                        // Persist PHPSESSID
                        for (Cookie c : cookies) {
                            if (c.name().equals("PHPSESSID")) {
                                getPrefs().edit().putString("PHPSESSID", c.value() + "|" + url.host()).apply();
                            }
                        }
                    }
                    @Override
                    public List<Cookie> loadForRequest(HttpUrl url) {
                        List<Cookie> cookies = cookieStore.get(url.host());
                        if (cookies != null) return cookies;
                        // Try restoring from prefs
                        String saved = getPrefs().getString("PHPSESSID", null);
                        if (saved != null && saved.contains("|")) {
                            String[] parts = saved.split("\\|");
                            if (parts.length == 2 && url.host().equals(parts[1])) {
                                List<Cookie> restored = new ArrayList<>();
                                restored.add(new Cookie.Builder()
                                        .name("PHPSESSID").value(parts[0])
                                        .domain(url.host()).path("/").build());
                                cookieStore.put(url.host(), restored);
                                return restored;
                            }
                        }
                        return new ArrayList<>();
                    }
                })
                .build();
    }

    public static synchronized ApiClient getInstance(Context ctx) {
        if (instance == null) instance = new ApiClient(ctx);
        return instance;
    }

    private SharedPreferences getPrefs() {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // ─── User session helpers ───────────────────────────────────────────────

    public void saveUser(User user) {
        getPrefs().edit().putString(KEY_USER, gson.toJson(user)).apply();
    }

    public User getSavedUser() {
        String json = getPrefs().getString(KEY_USER, null);
        if (json == null) return null;
        try { return gson.fromJson(json, User.class); } catch (Exception e) { return null; }
    }

    public boolean isLoggedIn() {
        return getSavedUser() != null;
    }

    public void logout() {
        getPrefs().edit()
                .remove(KEY_USER)
                .remove("PHPSESSID")
                .apply();
        cookieStore.clear();
        // Fire server-side logout (best-effort, don't crash on failure)
        try {
            RequestBody body = new FormBody.Builder().build();
            Request req = new Request.Builder()
                    .url(BASE_URL + "/api/auth/logout.php")
                    .post(body).build();
            client.newCall(req).execute().close();
        } catch (Exception ignored) {}
    }

    // ─── Raw HTTP helpers ───────────────────────────────────────────────────

    /** POST with JSON body, returns response string */
    public String postJson(String path, String json) throws IOException {
        RequestBody body = RequestBody.create(json, JSON);
        Request req = new Request.Builder().url(BASE_URL + path).post(body).build();
        try (Response resp = client.newCall(req).execute()) {
            return resp.body() != null ? resp.body().string() : "";
        }
    }

    /** POST with form fields, returns response string */
    public String postForm(String path, Map<String, String> fields) throws IOException {
        FormBody.Builder builder = new FormBody.Builder();
        if (fields != null) for (Map.Entry<String, String> e : fields.entrySet())
            builder.add(e.getKey(), e.getValue());
        Request req = new Request.Builder().url(BASE_URL + path).post(builder.build()).build();
        try (Response resp = client.newCall(req).execute()) {
            return resp.body() != null ? resp.body().string() : "";
        }
    }

    /** GET, returns response string */
    public String get(String path) throws IOException {
        Request req = new Request.Builder().url(BASE_URL + path).get().build();
        try (Response resp = client.newCall(req).execute()) {
            return resp.body() != null ? resp.body().string() : "";
        }
    }
}
