package com.smarzbd.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.badge.BadgeDrawable;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.smarzbd.app.R;
import com.smarzbd.app.fragments.CartFragment;
import com.smarzbd.app.fragments.HomeFragment;
import com.smarzbd.app.fragments.OrdersFragment;
import com.smarzbd.app.fragments.ProfileFragment;
import com.smarzbd.app.network.ApiClient;
import com.smarzbd.app.utils.CartManager;

public class MainActivity extends AppCompatActivity implements CartManager.CartCountListener {

    private BottomNavigationView bottomNav;
    private BadgeDrawable cartBadge;
    public static MainActivity instance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        instance = this;

        bottomNav = findViewById(R.id.bottom_navigation);
        cartBadge = bottomNav.getOrCreateBadge(R.id.nav_cart);
        cartBadge.setVisible(false);

        CartManager.getInstance(this).setListener(this);

        loadFragment(new HomeFragment());

        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                loadFragment(new HomeFragment()); return true;
            } else if (id == R.id.nav_categories) {
                loadFragment(new com.smarzbd.app.fragments.CategoriesFragment()); return true;
            } else if (id == R.id.nav_cart) {
                loadFragment(new CartFragment()); return true;
            } else if (id == R.id.nav_orders) {
                loadFragment(new OrdersFragment()); return true;
            } else if (id == R.id.nav_profile) {
                loadFragment(new ProfileFragment()); return true;
            }
            return false;
        });

        // Refresh cart count
        CartManager.getInstance(this).refreshCount();
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }

    public void navigateToCart() {
        bottomNav.setSelectedItemId(R.id.nav_cart);
    }

    public void navigateToOrders() {
        bottomNav.setSelectedItemId(R.id.nav_orders);
    }

    @Override
    public void onCartCountChanged(int count) {
        runOnUiThread(() -> {
            if (count > 0) {
                cartBadge.setVisible(true);
                cartBadge.setNumber(count);
            } else {
                cartBadge.setVisible(false);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        CartManager.getInstance(this).refreshCount();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (instance == this) instance = null;
    }
}
