package com.smarzbd.app.adapters;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.smarzbd.app.R;
import com.smarzbd.app.models.CartItem;
import com.smarzbd.app.network.ApiClient;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.VH> {

    private final List<CartItem> items;
    private final Context context;
    private final Runnable onRemoved;
    private final Gson gson = new Gson();

    public CartAdapter(List<CartItem> items, Context context, Runnable onRemoved) {
        this.items = items;
        this.context = context;
        this.onRemoved = onRemoved;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_cart, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        CartItem item = items.get(pos);
        h.tvName.setText(item.name);
        h.tvPrice.setText(String.format("৳%.0f", item.price));
        h.tvQty.setText("Qty: " + item.quantity);
        h.tvSubtotal.setText(String.format("৳%.0f", item.price * item.quantity));
        if (item.size != null && !item.size.isEmpty()) {
            h.tvSize.setVisibility(View.VISIBLE);
            h.tvSize.setText("Size: " + item.size);
        } else {
            h.tvSize.setVisibility(View.GONE);
        }

        String imgUrl = item.getImageUrl();
        if (!imgUrl.isEmpty()) {
            Glide.with(context).load(imgUrl)
                    .placeholder(R.drawable.placeholder_product)
                    .error(R.drawable.placeholder_product)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .centerCrop().into(h.ivProduct);
        } else {
            h.ivProduct.setImageResource(R.drawable.placeholder_product);
        }

        h.btnRemove.setOnClickListener(v -> removeItem(item));
    }

    private void removeItem(CartItem item) {
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.execute(() -> {
            try {
                Map<String, String> fields = new HashMap<>();
                fields.put("cart_item_id", String.valueOf(item.id));
                String resp = ApiClient.getInstance(context).postForm("/api/cart/remove_item.php", fields);
                JsonObject obj = gson.fromJson(resp, JsonObject.class);
                boolean success = obj.has("success") && obj.get("success").getAsBoolean();
                new Handler(Looper.getMainLooper()).post(() -> {
                    if (success && onRemoved != null) onRemoved.run();
                    else if (!success)
                        Toast.makeText(context, "Failed to remove item", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() ->
                        Toast.makeText(context, "Network error", Toast.LENGTH_SHORT).show());
            }
            exec.shutdown();
        });
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        ImageView ivProduct;
        TextView tvName, tvPrice, tvQty, tvSubtotal, tvSize, btnRemove;

        VH(View v) {
            super(v);
            ivProduct = v.findViewById(R.id.iv_product);
            tvName = v.findViewById(R.id.tv_name);
            tvPrice = v.findViewById(R.id.tv_price);
            tvQty = v.findViewById(R.id.tv_qty);
            tvSubtotal = v.findViewById(R.id.tv_subtotal);
            tvSize = v.findViewById(R.id.tv_size);
            btnRemove = v.findViewById(R.id.btn_remove);
        }
    }
}
