package com.smarzbd.app.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.smarzbd.app.R;
import com.smarzbd.app.activities.OrderDetailActivity;
import com.smarzbd.app.models.Order;

import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.VH> {

    private final List<Order> orders;
    private final Context context;

    public OrderAdapter(List<Order> orders, Context context) {
        this.orders = orders;
        this.context = context;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_order, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Order o = orders.get(pos);
        h.tvOrderNumber.setText("#" + o.order_number);
        h.tvTotal.setText(String.format("৳%.2f", o.total));
        h.tvDate.setText(o.created_at);
        h.tvItems.setText(o.items_count + " item" + (o.items_count != 1 ? "s" : ""));
        h.tvPayment.setText(o.payment_method != null ? o.payment_method.toUpperCase() : "");

        String status = o.status != null ? o.status : "pending";
        h.tvStatus.setText(status.toUpperCase());
        int color;
        switch (status.toLowerCase()) {
            case "delivered": color = context.getColor(R.color.green); break;
            case "shipped": color = context.getColor(R.color.primary); break;
            case "cancelled": color = context.getColor(R.color.red); break;
            default: color = context.getColor(R.color.orange); break;
        }
        h.tvStatus.setTextColor(color);

        h.itemView.setOnClickListener(v -> {
            Intent i = new Intent(context, OrderDetailActivity.class);
            i.putExtra("order_id", o.id);
            context.startActivity(i);
        });
    }

    @Override
    public int getItemCount() { return orders.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvOrderNumber, tvTotal, tvDate, tvItems, tvStatus, tvPayment;

        VH(View v) {
            super(v);
            tvOrderNumber = v.findViewById(R.id.tv_order_number);
            tvTotal = v.findViewById(R.id.tv_total);
            tvDate = v.findViewById(R.id.tv_date);
            tvItems = v.findViewById(R.id.tv_items);
            tvStatus = v.findViewById(R.id.tv_status);
            tvPayment = v.findViewById(R.id.tv_payment);
        }
    }
}
