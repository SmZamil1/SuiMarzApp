package com.smarzbd.app.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.smarzbd.app.R;
import com.smarzbd.app.activities.ProductDetailActivity;
import com.smarzbd.app.models.Product;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.VH> {

    private final List<Product> products;
    private final Context context;

    public ProductAdapter(List<Product> products, Context context) {
        this.products = products;
        this.context = context;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_product, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Product p = products.get(pos);
        h.tvName.setText(p.name);

        // Fix price NaN - use double directly
        double displayPrice = p.getDiscountedPrice();
        h.tvPrice.setText(String.format("৳%.0f", displayPrice));

        if (p.discount > 0) {
            h.tvOldPrice.setVisibility(View.VISIBLE);
            h.tvOldPrice.setPaintFlags(h.tvOldPrice.getPaintFlags() | android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);
            h.tvOldPrice.setText(String.format("৳%.0f", p.price));
            h.tvDiscount.setVisibility(View.VISIBLE);
            h.tvDiscount.setText("-" + p.discount + "%");
        } else {
            h.tvOldPrice.setVisibility(View.GONE);
            h.tvDiscount.setVisibility(View.GONE);
        }

        String imgUrl = p.getImageUrl();
        if (!imgUrl.isEmpty()) {
            Glide.with(context)
                    .load(imgUrl)
                    .placeholder(R.drawable.placeholder_product)
                    .error(R.drawable.placeholder_product)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .centerCrop()
                    .into(h.ivProduct);
        } else {
            h.ivProduct.setImageResource(R.drawable.placeholder_product);
        }

        h.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ProductDetailActivity.class);
            intent.putExtra("product_id", p.id);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() { return products.size(); }

    static class VH extends RecyclerView.ViewHolder {
        ImageView ivProduct;
        TextView tvName, tvPrice, tvOldPrice, tvDiscount;

        VH(View v) {
            super(v);
            ivProduct = v.findViewById(R.id.iv_product);
            tvName = v.findViewById(R.id.tv_name);
            tvPrice = v.findViewById(R.id.tv_price);
            tvOldPrice = v.findViewById(R.id.tv_old_price);
            tvDiscount = v.findViewById(R.id.tv_discount);
        }
    }
}
