package com.smarzbd.app.models;

public class Order {
    public int id;
    public String order_number;
    public double total;
    public String status;
    public String payment_method;
    public String address;
    public String created_at;
    public int items_count;
}
