package com.smarzbd.app.api;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.smarzbd.app.utils.Constants;
import com.smarzbd.app.utils.SessionManager;

import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {

    private static final String TAG    = "ApiClient";
    private static final String MARKER = "SMRZOK";

    private static Retrofit       retrofit       = null;
    private static SessionManager sessionManager = null;

    public static ApiService getService(Context context) {
        if (retrofit == null || sessionManager == null) {
            sessionManager = new SessionManager(context);

            // ── Full browser headers (stops InfinityFree injection) ──
            Interceptor browserHeadersInterceptor = chain -> {
                String cookie = sessionManager.getSessionCookie();
                Request.Builder b = chain.request().newBuilder()
                    .header("User-Agent",
                        "Mozilla/5.0 (Linux; Android 11; Pixel 5) "
                        + "AppleWebKit/537.36 (KHTML, like Gecko) "
                        + "Chrome/112.0.0.0 Mobile Safari/537.36")
                    .header("Accept",
                        "text/html,application/xhtml+xml,application/json,*/*;q=0.8")
                    .header("Accept-Language", "en-US,en;q=0.9")
                    .header("Accept-Encoding", "gzip, deflate, br")
                    .header("Origin",  Constants.BASE_URL.replaceAll("/$", ""))
                    .header("Referer", Constants.BASE_URL)
                    .header("Connection", "keep-alive")
                    .header("Upgrade-Insecure-Requests", "1")
                    .header("Sec-Fetch-Site",  "same-origin")
                    .header("Sec-Fetch-Mode",  "navigate")
                    .header("Sec-Fetch-Dest",  "document")
                    .header("Cache-Control",   "no-cache");
                if (cookie != null && !cookie.isEmpty())
                    b.header("Cookie", cookie);
                Request  req = b.build();
                Response res = chain.proceed(req);
                String setCookie = res.header("Set-Cookie");
                if (setCookie != null && setCookie.contains("PHPSESSID"))
                    sessionManager.saveSessionCookie(setCookie.split(";")[0]);
                return res;
            };

            // ── Smart JSON extractor ─────────────────────────────
            Interceptor jsonExtractor = chain -> {
                Response response = chain.proceed(chain.request());
                try {
                    ResponseBody body = response.body();
                    if (body == null) return response;
                    String raw = body.string();
                    Log.d(TAG, "RAW[" + raw.length() + "]: "
                        + raw.substring(0, Math.min(500, raw.length())));
                    String clean = extractCleanJson(raw);
                    Log.d(TAG, "CLEAN: " + clean);
                    return response.newBuilder()
                        .body(ResponseBody.create(
                            MediaType.parse("application/json; charset=utf-8"),
                            clean))
                        .build();
                } catch (Exception e) {
                    Log.e(TAG, "Extractor: " + e.getMessage());
                }
                return response;
            };

            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(browserHeadersInterceptor)
                    .addInterceptor(jsonExtractor)
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS)
                    .build();

            Gson gson = new GsonBuilder().setLenient().create();

            retrofit = new Retrofit.Builder()
                    .baseUrl(Constants.BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();
        }
        return retrofit.create(ApiService.class);
    }

    private static String extractCleanJson(String raw) {
        // Strategy 1: SMRZOK markers (new PHP files)
        int ms = raw.indexOf(MARKER);
        int me = raw.lastIndexOf(MARKER);
        if (ms != -1 && me != -1 && me > ms) {
            String j = raw.substring(ms + MARKER.length(), me).trim();
            Log.d(TAG, "Strategy1 SMRZOK: " + j);
            return j;
        }

        // Strategy 2: response IS already clean JSON (no injection)
        String trimmed = raw.trim();
        if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
            Log.d(TAG, "Strategy2 clean JSON");
            return trimmed;
        }

        // Strategy 3: find {"success": and extract balanced JSON
        int idx = raw.indexOf("{\"success\":");
        if (idx != -1) {
            String balanced = extractBalanced(raw.substring(idx));
            if (balanced != null) {
                Log.d(TAG, "Strategy3 balanced: " + balanced);
                return balanced;
            }
        }

        // Strategy 4: find ANY complete JSON object
        // Walk from end looking for last "}" that belongs to {"success":
        for (int i = raw.length() - 1; i >= 0; i--) {
            if (raw.charAt(i) == '}') {
                for (int j = i; j >= 0; j--) {
                    if (raw.charAt(j) == '{') {
                        String candidate = raw.substring(j, i + 1);
                        if (candidate.contains("\"success\"")) {
                            Log.d(TAG, "Strategy4 scan: " + candidate);
                            return candidate;
                        }
                        break;
                    }
                }
            }
        }

        Log.w(TAG, "No JSON found in response");
        return "{\"success\":false,\"message\":\"Server not reachable. Please try again.\"}";
    }

    private static String extractBalanced(String s) {
        if (s == null || !s.startsWith("{")) return null;
        int depth = 0; boolean inStr = false; boolean esc = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (esc)          { esc = false; continue; }
            if (c == '\\')    { esc = true;  continue; }
            if (c == '"')     { inStr = !inStr; continue; }
            if (inStr)        continue;
            if (c == '{')     depth++;
            else if (c == '}') { if (--depth == 0) return s.substring(0, i + 1); }
        }
        return null;
    }

    public static void reset() { retrofit = null; sessionManager = null; }
}
