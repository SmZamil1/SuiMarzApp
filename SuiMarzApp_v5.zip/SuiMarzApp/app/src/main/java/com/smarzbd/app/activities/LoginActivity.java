package com.smarzbd.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.smarzbd.app.R;
import com.smarzbd.app.api.ApiClient;
import com.smarzbd.app.models.ApiResponse;
import com.smarzbd.app.api.ApiService;
import com.smarzbd.app.models.LoginResponse;
import com.smarzbd.app.utils.SessionManager;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private Button btnLogin;
    private ProgressBar progressBar;
    private TextView tvRegister;

    private ApiService apiService;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        apiService = ApiClient.getService(this);
        session    = new SessionManager(this);

        etEmail     = findViewById(R.id.et_email);
        etPassword  = findViewById(R.id.et_password);
        btnLogin    = findViewById(R.id.btn_login);
        progressBar = findViewById(R.id.progress_bar);
        tvRegister  = findViewById(R.id.tv_register);

        btnLogin.setOnClickListener(v -> attemptLogin());

        tvRegister.setOnClickListener(v ->
            startActivity(new Intent(this, RegisterActivity.class)));
    }

    private void attemptLogin() {
        String email    = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (email.isEmpty()) { etEmail.setError("Email required"); return; }
        if (password.isEmpty()) { etPassword.setError("Password required"); return; }

        setLoading(true);

        Map<String, String> fields = new HashMap<>();
        fields.put("email",    email);
        fields.put("password", password);

        apiService.login(fields).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                setLoading(false);
                if (response.isSuccessful() && response.body() != null) {
                    LoginResponse body = response.body();
                    if (body.success) {
                        session.saveUserSession(body.userId, body.name, body.email, body.phone);
                        // Send FCM token to server now that we're logged in
                        sendFCMToken();
                        startActivity(new Intent(LoginActivity.this, MainActivity.class));
                        finish();
                    } else {
                        Toast.makeText(LoginActivity.this,
                            body.message != null ? body.message : "Login failed",
                            Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(LoginActivity.this,
                        "Server error. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                setLoading(false);
                Toast.makeText(LoginActivity.this,
                    "Network error: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void sendFCMToken() {
        String token = session.getFCMToken();
        if (token == null || token.isEmpty()) return;

        Map<String, String> fields = new HashMap<>();
        fields.put("fcm_token", token);
        fields.put("user_id",   String.valueOf(session.getUserId()));

        apiService.saveFCMToken(fields).enqueue(new Callback<ApiResponse>() {
            @Override public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {}
            @Override public void onFailure(Call<ApiResponse> call, Throwable t) {}
        });
    }

    private void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        btnLogin.setEnabled(!loading);
    }
}
