package com.smarzbd.app.api;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.smarzbd.app.utils.Constants;
import com.smarzbd.app.utils.SessionManager;

import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {

    private static final String TAG = "ApiClient";
    private static Retrofit       retrofit       = null;
    private static SessionManager sessionManager = null;

    public static ApiService getService(Context context) {
        if (retrofit == null || sessionManager == null) {
            sessionManager = new SessionManager(context);

            // ── Cookie interceptor ────────────────────────────────
            Interceptor cookieInterceptor = chain -> {
                String cookie = sessionManager.getSessionCookie();
                Request.Builder builder = chain.request().newBuilder();
                if (cookie != null && !cookie.isEmpty())
                    builder.addHeader("Cookie", cookie);
                Request  request  = builder.build();
                Response response = chain.proceed(request);
                String setCookie  = response.header("Set-Cookie");
                if (setCookie != null && setCookie.contains("PHPSESSID"))
                    sessionManager.saveSessionCookie(setCookie.split(";")[0]);
                return response;
            };

            // ── JSON Extractor interceptor ────────────────────────
            // InfinityFree injects JavaScript like: var {analytics} = ...
            // which contains { } and breaks naive JSON parsing.
            // We search specifically for {"success": which ALL our APIs return.
            Interceptor jsonExtractorInterceptor = chain -> {
                Response response = chain.proceed(chain.request());
                try {
                    ResponseBody body = response.body();
                    if (body == null) return response;

                    String raw = body.string();
                    Log.d(TAG, "RAW[" + raw.length() + "]: "
                        + raw.substring(0, Math.min(300, raw.length())));

                    String clean = extractJson(raw);
                    Log.d(TAG, "CLEAN: " + clean.substring(0, Math.min(200, clean.length())));

                    return response.newBuilder()
                        .body(ResponseBody.create(
                            MediaType.parse("application/json; charset=utf-8"),
                            clean))
                        .build();

                } catch (Exception e) {
                    Log.e(TAG, "Interceptor error: " + e.getMessage());
                }
                return response;
            };

            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(cookieInterceptor)
                    .addInterceptor(jsonExtractorInterceptor)
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS)
                    .build();

            Gson gson = new GsonBuilder().setLenient().create();

            retrofit = new Retrofit.Builder()
                    .baseUrl(Constants.BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();
        }
        return retrofit.create(ApiService.class);
    }

    /**
     * Extract valid JSON from a response that may contain injected HTML/JS.
     * Strategy: find {"success": which ALL our PHP APIs return.
     * If not found, try {"success" with space, then fall back to first { }.
     */
    private static String extractJson(String raw) {
        // Strategy 1: look for our known response pattern
        String[] patterns = {
            "{\"success\":",
            "{ \"success\":",
            "{\"success\" :"
        };
        for (String pattern : patterns) {
            int start = raw.indexOf(pattern);
            if (start != -1) {
                // Find the matching closing brace by counting depth
                String fromStart = raw.substring(start);
                String balanced = extractBalancedJson(fromStart);
                if (balanced != null) return balanced;
            }
        }

        // Strategy 2: find the last complete JSON object in the response
        // (InfinityFree often injects BEFORE the PHP output)
        int lastBrace = raw.lastIndexOf('}');
        if (lastBrace != -1) {
            // Search backwards for the matching opening {
            String candidate = findJsonEndingAt(raw, lastBrace);
            if (candidate != null) return candidate;
        }

        // Strategy 3: just try first { to last } (old method, last resort)
        int start = raw.indexOf('{');
        int end   = raw.lastIndexOf('}');
        if (start != -1 && end != -1 && end > start) {
            return raw.substring(start, end + 1);
        }

        // Nothing worked — return safe error
        return "{\"success\":false,\"message\":\"Server error. Please try again.\"}";
    }

    /** Extract a balanced JSON object starting at position 0 of the input */
    private static String extractBalancedJson(String s) {
        if (!s.startsWith("{")) return null;
        int depth = 0;
        boolean inString = false;
        boolean escaped  = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (escaped)        { escaped = false; continue; }
            if (c == '\\')      { escaped = true;  continue; }
            if (c == '"')       { inString = !inString; continue; }
            if (inString)       continue;
            if (c == '{')       depth++;
            else if (c == '}')  { depth--; if (depth == 0) return s.substring(0, i + 1); }
        }
        return null;
    }

    /** Find the balanced JSON object that ends at endPos */
    private static String findJsonEndingAt(String s, int endPos) {
        // Walk backwards to find the opening {
        int depth = 0;
        boolean inString = false;
        for (int i = endPos; i >= 0; i--) {
            char c = s.charAt(i);
            if (c == '}') depth++;
            else if (c == '{') {
                depth--;
                if (depth == 0) {
                    String candidate = s.substring(i, endPos + 1);
                    // Validate it contains "success"
                    if (candidate.contains("success")) return candidate;
                    return null;
                }
            }
        }
        return null;
    }

    public static void reset() {
        retrofit       = null;
        sessionManager = null;
    }
}
