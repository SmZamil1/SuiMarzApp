package com.smarzbd.app.models;

import com.google.gson.annotations.SerializedName;

public class Order {
    @SerializedName("id")           public int id;
    @SerializedName("order_number") public String orderNumber;
    @SerializedName("total")        public double total;
    @SerializedName("status")       public String status;
    @SerializedName("created_at")   public String createdAt;
    @SerializedName("items_count")  public int itemsCount;
    @SerializedName("payment_method") public String paymentMethod;
    @SerializedName("address")      public String address;
}
