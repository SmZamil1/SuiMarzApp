package com.smarzbd.app.models;
import com.google.gson.annotations.SerializedName;
public class LoginResponse {
    @SerializedName("success")  public boolean success;
    @SerializedName("message")  public String message;
    @SerializedName("user_id")  public int userId;
    @SerializedName("name")     public String name;
    @SerializedName("email")    public String email;
    @SerializedName("phone")    public String phone;
}
