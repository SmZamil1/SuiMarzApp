package com.smarzbd.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.smarzbd.app.R;
import com.smarzbd.app.models.AppNotification;

import java.util.ArrayList;
import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ViewHolder> {

    private List<AppNotification> notifications = new ArrayList<>();

    public void setData(List<AppNotification> list) {
        this.notifications = list != null ? list : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                     .inflate(R.layout.item_notification, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        AppNotification n = notifications.get(position);
        h.tvTitle.setText(n.title != null ? n.title : "Notification");
        h.tvMessage.setText(n.message != null ? n.message : "");
        h.tvTime.setText(n.createdAt != null ? n.createdAt : "");

        // Unread style
        if (n.isRead == 0) {
            h.itemView.setBackgroundResource(R.color.notification_unread_bg);
        } else {
            h.itemView.setBackgroundResource(android.R.color.white);
        }
    }

    @Override public int getItemCount() { return notifications.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvMessage, tvTime;
        ViewHolder(@NonNull View v) {
            super(v);
            tvTitle   = v.findViewById(R.id.tv_title);
            tvMessage = v.findViewById(R.id.tv_message);
            tvTime    = v.findViewById(R.id.tv_time);
        }
    }
}
