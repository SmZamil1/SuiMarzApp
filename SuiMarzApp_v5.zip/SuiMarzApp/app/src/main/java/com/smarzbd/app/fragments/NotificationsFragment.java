package com.smarzbd.app.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.smarzbd.app.R;
import com.smarzbd.app.activities.MainActivity;
import com.smarzbd.app.adapters.NotificationAdapter;
import com.smarzbd.app.api.ApiClient;
import com.smarzbd.app.api.ApiService;
import com.smarzbd.app.models.AppNotification;
import com.smarzbd.app.models.NotificationResponse;
import com.smarzbd.app.utils.SessionManager;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NotificationsFragment extends Fragment {

    private RecyclerView      rvNotifications;
    private ProgressBar       progressBar;
    private TextView          tvEmpty;
    private SwipeRefreshLayout swipeRefresh;

    private NotificationAdapter adapter;
    private ApiService          apiService;
    private SessionManager      session;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_notifications, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        apiService      = ApiClient.getService(requireContext());
        session         = new SessionManager(requireContext());
        progressBar     = view.findViewById(R.id.progress_bar);
        tvEmpty         = view.findViewById(R.id.tv_empty);
        swipeRefresh    = view.findViewById(R.id.swipe_refresh);
        rvNotifications = view.findViewById(R.id.rv_notifications);

        rvNotifications.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new NotificationAdapter();
        rvNotifications.setAdapter(adapter);

        swipeRefresh.setOnRefreshListener(this::loadNotifications);
        loadNotifications();
    }

    private void loadNotifications() {
        if (!session.isLoggedIn()) {
            tvEmpty.setVisibility(View.VISIBLE);
            tvEmpty.setText("Please login to see notifications");
            progressBar.setVisibility(View.GONE);
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        tvEmpty.setVisibility(View.GONE);

        apiService.getNotifications().enqueue(new Callback<NotificationResponse>() {
            @Override
            public void onResponse(Call<NotificationResponse> call,
                                   Response<NotificationResponse> r) {
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);

                if (r.isSuccessful() && r.body() != null && r.body().success) {
                    List<AppNotification> list = r.body().notifications;
                    if (list != null && !list.isEmpty()) {
                        adapter.setData(list);
                        tvEmpty.setVisibility(View.GONE);
                        // Clear badge in MainActivity
                        if (getActivity() instanceof MainActivity) {
                            ((MainActivity) getActivity()).setNotificationBadge(0);
                        }
                    } else {
                        tvEmpty.setVisibility(View.VISIBLE);
                        tvEmpty.setText("No notifications yet");
                    }
                }
            }

            @Override
            public void onFailure(Call<NotificationResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
                Toast.makeText(getContext(), "Failed to load notifications", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
