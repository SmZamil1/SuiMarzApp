package com.smarzbd.app.models;

import com.google.gson.annotations.SerializedName;

public class AppNotification {
    @SerializedName("id")         public int id;
    @SerializedName("title")      public String title;
    @SerializedName("message")    public String message;
    @SerializedName("type")       public String type;
    @SerializedName("is_read")    public int isRead;
    @SerializedName("created_at") public String createdAt;
    @SerializedName("user_id")    public int userId;
}
