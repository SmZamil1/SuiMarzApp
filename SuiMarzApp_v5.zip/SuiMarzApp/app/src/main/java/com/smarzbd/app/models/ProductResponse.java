package com.smarzbd.app.models;
import com.google.gson.annotations.SerializedName;
import java.util.List;
public class ProductResponse {
    @SerializedName("success")  public boolean success;
    @SerializedName("products") public List<Product> products;
}
