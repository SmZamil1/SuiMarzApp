package com.smarzbd.app.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.smarzbd.app.R;
import com.smarzbd.app.activities.OrderDetailActivity;
import com.smarzbd.app.models.Order;
import com.smarzbd.app.utils.Constants;

import java.util.ArrayList;
import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.ViewHolder> {

    private final Context     context;
    private       List<Order> orders = new ArrayList<>();

    public OrderAdapter(Context context) { this.context = context; }

    public void setData(List<Order> list) {
        this.orders = list != null ? list : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_order, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        Order o = orders.get(position);

        h.tvOrderNum.setText("#" + (o.orderNumber != null ? o.orderNumber : o.id));
        h.tvTotal.setText("৳" + String.format("%.2f", o.total));
        h.tvDate.setText(o.createdAt != null ? o.createdAt : "");
        h.tvStatus.setText(o.status != null ? o.status.toUpperCase() : "PENDING");

        // Status color
        int color;
        String status = o.status != null ? o.status.toLowerCase() : "";
        switch (status) {
            case "delivered":  color = R.color.status_delivered;  break;
            case "shipped":    color = R.color.status_shipped;    break;
            case "processing": color = R.color.status_processing; break;
            case "cancelled":  color = R.color.status_cancelled;  break;
            default:           color = R.color.status_pending;    break;
        }
        h.tvStatus.setBackgroundResource(R.drawable.bg_status);
        h.tvStatus.setTextColor(ContextCompat.getColor(context, color));

        h.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, OrderDetailActivity.class);
            intent.putExtra(Constants.EXTRA_ORDER_ID, o.id);
            context.startActivity(intent);
        });
    }

    @Override public int getItemCount() { return orders.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderNum, tvTotal, tvDate, tvStatus;
        ViewHolder(@NonNull View v) {
            super(v);
            tvOrderNum = v.findViewById(R.id.tv_order_number);
            tvTotal    = v.findViewById(R.id.tv_total);
            tvDate     = v.findViewById(R.id.tv_date);
            tvStatus   = v.findViewById(R.id.tv_status);
        }
    }
}
