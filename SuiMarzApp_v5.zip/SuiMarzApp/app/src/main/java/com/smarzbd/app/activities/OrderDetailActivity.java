package com.smarzbd.app.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.smarzbd.app.R;
import com.smarzbd.app.api.ApiClient;
import com.smarzbd.app.api.ApiService;
import com.smarzbd.app.models.ApiResponse;
import com.smarzbd.app.utils.Constants;
import java.util.HashMap;
import java.util.Map;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OrderDetailActivity extends AppCompatActivity {
    private TextView tvOrderInfo;
    private ProgressBar progressBar;
    private ApiService  apiService;
    private int orderId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> finish());

        apiService   = ApiClient.getService(this);
        tvOrderInfo  = findViewById(R.id.tv_order_info);
        progressBar  = findViewById(R.id.progress_bar);
        orderId      = getIntent().getIntExtra(Constants.EXTRA_ORDER_ID, -1);
        loadOrderDetail();
    }

    private void loadOrderDetail() {
        if (orderId == -1) { finish(); return; }
        progressBar.setVisibility(View.VISIBLE);
        Map<String, String> fields = new HashMap<>();
        fields.put("order_id", String.valueOf(orderId));
        apiService.getOrderDetail(fields).enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> r) {
                progressBar.setVisibility(View.GONE);
                if (r.isSuccessful() && r.body() != null) {
                    tvOrderInfo.setText("Order #" + orderId + "\n" + r.body().message);
                }
            }
            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(OrderDetailActivity.this, "Failed to load", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
