package com.smarzbd.app.models;
import com.google.gson.annotations.SerializedName;
import java.util.List;
public class OrderResponse {
    @SerializedName("success") public boolean success;
    @SerializedName("orders")  public List<Order> orders;
}
