package com.smarzbd.app.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.smarzbd.app.R;
import com.smarzbd.app.adapters.OrderAdapter;
import com.smarzbd.app.api.ApiClient;
import com.smarzbd.app.api.ApiService;
import com.smarzbd.app.models.Order;
import com.smarzbd.app.models.OrderResponse;
import com.smarzbd.app.utils.SessionManager;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OrdersFragment extends Fragment {

    private RecyclerView      rvOrders;
    private ProgressBar       progressBar;
    private TextView          tvEmpty;
    private SwipeRefreshLayout swipeRefresh;
    private OrderAdapter      orderAdapter;
    private ApiService        apiService;
    private SessionManager    session;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_orders, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        apiService   = ApiClient.getService(requireContext());
        session      = new SessionManager(requireContext());
        progressBar  = view.findViewById(R.id.progress_bar);
        tvEmpty      = view.findViewById(R.id.tv_empty);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        rvOrders     = view.findViewById(R.id.rv_orders);

        rvOrders.setLayoutManager(new LinearLayoutManager(getContext()));
        orderAdapter = new OrderAdapter(getContext());
        rvOrders.setAdapter(orderAdapter);

        swipeRefresh.setOnRefreshListener(this::loadOrders);

        if (!session.isLoggedIn()) {
            tvEmpty.setVisibility(View.VISIBLE);
            tvEmpty.setText("Please login to see your orders");
        } else {
            loadOrders();
        }
    }

    private void loadOrders() {
        progressBar.setVisibility(View.VISIBLE);
        apiService.getOrders().enqueue(new Callback<OrderResponse>() {
            @Override
            public void onResponse(Call<OrderResponse> call, Response<OrderResponse> r) {
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
                if (r.isSuccessful() && r.body() != null && r.body().success) {
                    List<Order> orders = r.body().orders;
                    if (orders != null && !orders.isEmpty()) {
                        orderAdapter.setData(orders);
                        tvEmpty.setVisibility(View.GONE);
                    } else {
                        tvEmpty.setVisibility(View.VISIBLE);
                        tvEmpty.setText("No orders yet");
                    }
                }
            }
            @Override
            public void onFailure(Call<OrderResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
                Toast.makeText(getContext(), "Failed to load orders", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
