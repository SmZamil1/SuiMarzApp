package com.smarzbd.app.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.smarzbd.app.R;
import com.smarzbd.app.api.ApiClient;
import com.smarzbd.app.api.ApiService;
import com.smarzbd.app.models.ApiResponse;
import java.util.HashMap;
import java.util.Map;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CheckoutActivity extends AppCompatActivity {
    private EditText etAddress, etPhone, etNote;
    private Button btnPlaceOrder;
    private ProgressBar progressBar;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> finish());

        apiService    = ApiClient.getService(this);
        etAddress     = findViewById(R.id.et_address);
        etPhone       = findViewById(R.id.et_phone);
        etNote        = findViewById(R.id.et_note);
        btnPlaceOrder = findViewById(R.id.btn_place_order);
        progressBar   = findViewById(R.id.progress_bar);

        btnPlaceOrder.setOnClickListener(v -> placeOrder());
    }

    private void placeOrder() {
        String address = etAddress.getText().toString().trim();
        String phone   = etPhone.getText().toString().trim();
        if (address.isEmpty()) { etAddress.setError("Address required"); return; }
        if (phone.isEmpty())   { etPhone.setError("Phone required"); return; }

        progressBar.setVisibility(View.VISIBLE);
        btnPlaceOrder.setEnabled(false);

        Map<String, String> fields = new HashMap<>();
        fields.put("address",        address);
        fields.put("phone",          phone);
        fields.put("note",           etNote.getText().toString().trim());
        fields.put("payment_method", "cod");

        apiService.handlePayment(fields).enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> r) {
                progressBar.setVisibility(View.GONE);
                if (r.isSuccessful() && r.body() != null && r.body().success) {
                    Toast.makeText(CheckoutActivity.this,
                        "Order placed successfully!", Toast.LENGTH_LONG).show();
                    finish();
                } else {
                    btnPlaceOrder.setEnabled(true);
                    Toast.makeText(CheckoutActivity.this,
                        r.body() != null ? r.body().message : "Failed to place order",
                        Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<ApiResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                btnPlaceOrder.setEnabled(true);
                Toast.makeText(CheckoutActivity.this, "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
