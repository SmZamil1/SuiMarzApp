package com.smarzbd.app.models;

import com.google.gson.annotations.SerializedName;

public class Product {
    @SerializedName("id")       public int id;
    @SerializedName("name")     public String name;
    @SerializedName("price")    public double price;
    @SerializedName("old_price") public double oldPrice;
    @SerializedName("image")    public String image;
    @SerializedName("description") public String description;
    @SerializedName("stock")    public int stock;
    @SerializedName("category_id") public int categoryId;
    @SerializedName("rating")   public double rating;
    @SerializedName("sales_count") public int salesCount;
    @SerializedName("sizes")    public String sizes;
    @SerializedName("colors")   public String colors;
    @SerializedName("created_at") public String createdAt;
}
