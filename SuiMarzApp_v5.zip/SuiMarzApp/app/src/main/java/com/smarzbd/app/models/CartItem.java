package com.smarzbd.app.models;

import com.google.gson.annotations.SerializedName;

public class CartItem {
    @SerializedName("id")           public int id;
    @SerializedName("product_id")   public int productId;
    @SerializedName("name")         public String name;
    @SerializedName("price")        public double price;
    @SerializedName("quantity")     public int quantity;
    @SerializedName("image")        public String image;
    @SerializedName("size")         public String size;
    @SerializedName("color")        public String color;
    @SerializedName("subtotal")     public double subtotal;
}
