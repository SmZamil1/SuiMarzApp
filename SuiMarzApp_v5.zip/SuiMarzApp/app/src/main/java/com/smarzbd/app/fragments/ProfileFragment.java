package com.smarzbd.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.smarzbd.app.R;
import com.smarzbd.app.activities.LoginActivity;
import com.smarzbd.app.api.ApiClient;
import com.smarzbd.app.api.ApiService;
import com.smarzbd.app.models.ApiResponse;
import com.smarzbd.app.utils.SessionManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileFragment extends Fragment {

    private TextView tvName, tvEmail, tvPhone;
    private Button   btnLogout;
    private SessionManager session;
    private ApiService     apiService;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        session    = new SessionManager(requireContext());
        apiService = ApiClient.getService(requireContext());

        tvName  = view.findViewById(R.id.tv_name);
        tvEmail = view.findViewById(R.id.tv_email);
        tvPhone = view.findViewById(R.id.tv_phone);
        btnLogout = view.findViewById(R.id.btn_logout);

        if (session.isLoggedIn()) {
            tvName.setText(session.getUserName());
            tvEmail.setText(session.getUserEmail());
            tvPhone.setText(session.getUserPhone());
        } else {
            tvName.setText("Guest");
            tvEmail.setText("Not logged in");
            tvPhone.setText("");
        }

        btnLogout.setOnClickListener(v -> confirmLogout());
    }

    private void confirmLogout() {
        new AlertDialog.Builder(requireContext())
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Logout", (d, w) -> performLogout())
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void performLogout() {
        apiService.logout().enqueue(new Callback<ApiResponse>() {
            @Override public void onResponse(Call<ApiResponse> call, Response<ApiResponse> r) {}
            @Override public void onFailure(Call<ApiResponse> call, Throwable t) {}
        });

        session.logout();
        ApiClient.reset();

        Intent intent = new Intent(getContext(), LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}
