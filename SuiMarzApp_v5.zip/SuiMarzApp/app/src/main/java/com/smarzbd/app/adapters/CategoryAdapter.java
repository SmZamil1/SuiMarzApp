package com.smarzbd.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.smarzbd.app.R;
import com.smarzbd.app.models.Category;

import java.util.ArrayList;
import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {

    public interface OnCategoryClick { void onClick(String categoryId); }

    private List<Category>  categories   = new ArrayList<>();
    private String          selectedId   = "all";
    private OnCategoryClick listener;

    public CategoryAdapter(OnCategoryClick listener) {
        this.listener = listener;
    }

    public void setData(List<Category> list) {
        // Add "All" at front
        categories = new ArrayList<>();
        Category all = new Category();
        all.id   = 0;
        all.name = "All";
        categories.add(all);
        categories.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                     .inflate(R.layout.item_category, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        Category cat     = categories.get(position);
        String   catId   = cat.id == 0 ? "all" : String.valueOf(cat.id);
        boolean  selected = catId.equals(selectedId);

        h.tvName.setText(cat.name);
        h.tvName.setSelected(selected);

        if (selected) {
            h.tvName.setBackgroundResource(R.drawable.bg_category_selected);
            h.tvName.setTextColor(
                ContextCompat.getColor(h.itemView.getContext(), android.R.color.white));
        } else {
            h.tvName.setBackgroundResource(R.drawable.bg_category_normal);
            h.tvName.setTextColor(
                ContextCompat.getColor(h.itemView.getContext(), R.color.text_primary));
        }

        h.itemView.setOnClickListener(v -> {
            selectedId = catId;
            notifyDataSetChanged();
            listener.onClick(catId);
        });
    }

    @Override public int getItemCount() { return categories.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        ViewHolder(@NonNull View v) {
            super(v);
            tvName = v.findViewById(R.id.tv_category_name);
        }
    }
}
