package com.smarzbd.app.models;

import com.google.gson.annotations.SerializedName;

public class Category {
    @SerializedName("id")    public int id;
    @SerializedName("name")  public String name;
    @SerializedName("image") public String image;
}
