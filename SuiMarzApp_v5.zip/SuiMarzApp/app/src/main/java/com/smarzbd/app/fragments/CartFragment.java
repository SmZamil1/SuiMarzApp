package com.smarzbd.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.smarzbd.app.R;
import com.smarzbd.app.activities.CheckoutActivity;
import com.smarzbd.app.activities.LoginActivity;
import com.smarzbd.app.activities.MainActivity;
import com.smarzbd.app.adapters.CartAdapter;
import com.smarzbd.app.api.ApiClient;
import com.smarzbd.app.api.ApiService;
import com.smarzbd.app.models.CartItem;
import com.smarzbd.app.models.CartResponse;
import com.smarzbd.app.utils.SessionManager;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartFragment extends Fragment {

    private RecyclerView rvCart;
    private TextView     tvTotal, tvEmpty;
    private Button       btnCheckout;
    private ProgressBar  progressBar;

    private CartAdapter   cartAdapter;
    private ApiService    apiService;
    private SessionManager session;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cart, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        apiService  = ApiClient.getService(requireContext());
        session     = new SessionManager(requireContext());
        progressBar = view.findViewById(R.id.progress_bar);
        rvCart      = view.findViewById(R.id.rv_cart);
        tvTotal     = view.findViewById(R.id.tv_total);
        tvEmpty     = view.findViewById(R.id.tv_empty);
        btnCheckout = view.findViewById(R.id.btn_checkout);

        rvCart.setLayoutManager(new LinearLayoutManager(getContext()));
        cartAdapter = new CartAdapter(getContext(), this::onItemRemoved);
        rvCart.setAdapter(cartAdapter);

        btnCheckout.setOnClickListener(v -> {
            if (!session.isLoggedIn()) {
                startActivity(new Intent(getContext(), LoginActivity.class));
            } else {
                startActivity(new Intent(getContext(), CheckoutActivity.class));
            }
        });

        if (!session.isLoggedIn()) {
            showLoginPrompt();
        } else {
            loadCart();
        }
    }

    private void loadCart() {
        progressBar.setVisibility(View.VISIBLE);
        apiService.getCart().enqueue(new Callback<CartResponse>() {
            @Override
            public void onResponse(Call<CartResponse> call, Response<CartResponse> r) {
                progressBar.setVisibility(View.GONE);
                if (r.isSuccessful() && r.body() != null && r.body().success) {
                    List<CartItem> items = r.body().items;
                    if (items != null && !items.isEmpty()) {
                        cartAdapter.setData(items);
                        tvEmpty.setVisibility(View.GONE);
                        tvTotal.setText("Total: ৳" + String.format("%.2f", r.body().total));
                        btnCheckout.setEnabled(true);
                        // Update badge
                        if (getActivity() instanceof MainActivity)
                            ((MainActivity) getActivity()).setCartBadge(r.body().count);
                    } else {
                        showEmptyCart();
                    }
                }
            }
            @Override
            public void onFailure(Call<CartResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(getContext(), "Failed to load cart", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void onItemRemoved() {
        loadCart(); // Refresh after removal
    }

    private void showEmptyCart() {
        tvEmpty.setVisibility(View.VISIBLE);
        tvTotal.setText("Total: ৳0.00");
        btnCheckout.setEnabled(false);
        if (getActivity() instanceof MainActivity)
            ((MainActivity) getActivity()).setCartBadge(0);
    }

    private void showLoginPrompt() {
        progressBar.setVisibility(View.GONE);
        tvEmpty.setVisibility(View.VISIBLE);
        tvEmpty.setText("Please login to view your cart");
    }
}
