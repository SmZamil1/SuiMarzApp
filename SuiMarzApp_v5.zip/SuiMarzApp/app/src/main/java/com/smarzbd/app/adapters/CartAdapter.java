package com.smarzbd.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.smarzbd.app.R;
import com.smarzbd.app.api.ApiClient;
import com.smarzbd.app.api.ApiService;
import com.smarzbd.app.models.ApiResponse;
import com.smarzbd.app.models.CartItem;
import com.smarzbd.app.utils.Constants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {

    public interface OnCartChanged { void onChanged(); }

    private final Context        context;
    private       List<CartItem> items    = new ArrayList<>();
    private final OnCartChanged  listener;

    public CartAdapter(Context context, OnCartChanged listener) {
        this.context  = context;
        this.listener = listener;
    }

    public void setData(List<CartItem> list) {
        this.items = list != null ? list : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_cart, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        CartItem item = items.get(position);

        h.tvName.setText(item.name);
        h.tvPrice.setText("৳" + String.format("%.2f", item.price));
        h.tvQty.setText("Qty: " + item.quantity);
        h.tvSubtotal.setText("৳" + String.format("%.2f", item.subtotal));

        if (item.size != null && !item.size.isEmpty()) {
            h.tvSize.setVisibility(View.VISIBLE);
            h.tvSize.setText("Size: " + item.size);
        } else {
            h.tvSize.setVisibility(View.GONE);
        }

        String imgUrl = Constants.BASE_URL + "uploads/products/" + item.image;
        Glide.with(context).load(imgUrl)
             .placeholder(R.drawable.placeholder_product)
             .centerCrop().into(h.ivImage);

        h.btnRemove.setOnClickListener(v -> removeItem(item.id));
    }

    private void removeItem(int cartItemId) {
        ApiService api = ApiClient.getService(context);
        Map<String, String> fields = new HashMap<>();
        fields.put("cart_item_id", String.valueOf(cartItemId));

        api.removeFromCart(fields).enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> call, Response<ApiResponse> r) {
                if (r.isSuccessful() && r.body() != null && r.body().success) {
                    listener.onChanged();
                } else {
                    Toast.makeText(context, "Failed to remove item", Toast.LENGTH_SHORT).show();
                }
            }
            @Override public void onFailure(Call<ApiResponse> call, Throwable t) {
                Toast.makeText(context, "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override public int getItemCount() { return items.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView   ivImage;
        TextView    tvName, tvPrice, tvQty, tvSubtotal, tvSize;
        ImageButton btnRemove;
        ViewHolder(@NonNull View v) {
            super(v);
            ivImage    = v.findViewById(R.id.iv_image);
            tvName     = v.findViewById(R.id.tv_name);
            tvPrice    = v.findViewById(R.id.tv_price);
            tvQty      = v.findViewById(R.id.tv_qty);
            tvSubtotal = v.findViewById(R.id.tv_subtotal);
            tvSize     = v.findViewById(R.id.tv_size);
            btnRemove  = v.findViewById(R.id.btn_remove);
        }
    }
}
