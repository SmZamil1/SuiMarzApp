package com.smarzbd.app.utils;

public class Constants {

    // =============================================
    // TODO: CHANGE THIS TO YOUR ACTUAL DOMAIN/URL
    // Example: "https://yourdomain.com/SuiMarz/"
    // =============================================
    public static final String BASE_URL = "https://smarzbd.42web.io/";

    // API Endpoints
    public static final String EP_GET_PRODUCTS     = "api/get_products.php";
    public static final String EP_GET_ALL_PRODUCTS = "api/get_all_products.php";
    public static final String EP_GET_CATEGORIES   = "api/get_categories.php";
    public static final String EP_GET_NOTIFICATIONS= "api/get_notifications.php";
    public static final String EP_ADD_TO_CART      = "api/add_to_cart.php";
    public static final String EP_SEND_CONTACT     = "api/send_contact.php";
    public static final String EP_SAVE_FCM_TOKEN   = "api/save_fcm_token.php";
    public static final String EP_GET_PAYMENT      = "api/get_payment_settings.php";
    public static final String EP_HANDLE_PAYMENT   = "api/handle_payment.php";
    public static final String EP_SHIPPING_FEE     = "api/get_shipping_fee.php";

    // Auth Endpoints
    public static final String EP_LOGIN    = "api/auth/login.php";
    public static final String EP_REGISTER = "api/auth/register.php";
    public static final String EP_PROFILE  = "api/auth/profile.php";
    public static final String EP_LOGOUT   = "api/auth/logout.php";

    // Orders
    public static final String EP_ORDERS       = "api/orders/get_orders.php";
    public static final String EP_ORDER_DETAIL = "api/orders/get_order_detail.php";

    // SharedPreferences Keys
    public static final String PREF_NAME      = "SuiMarzPrefs";
    public static final String KEY_USER_ID    = "user_id";
    public static final String KEY_USER_NAME  = "user_name";
    public static final String KEY_USER_EMAIL = "user_email";
    public static final String KEY_USER_PHONE = "user_phone";
    public static final String KEY_IS_LOGGED_IN = "is_logged_in";
    public static final String KEY_FCM_TOKEN  = "fcm_token";
    public static final String KEY_SESSION_COOKIE = "session_cookie";

    // Notification Channel
    public static final String NOTIFICATION_CHANNEL_ID   = "smarzbd_channel";
    public static final String NOTIFICATION_CHANNEL_NAME = "SMarZ bd Notifications";

    // Intent Extras
    public static final String EXTRA_PRODUCT_ID    = "product_id";
    public static final String EXTRA_ORDER_ID      = "order_id";
    public static final String EXTRA_CATEGORY_ID   = "category_id";
}
