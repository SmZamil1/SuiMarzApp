package com.smarzbd.app.models;
import com.google.gson.annotations.SerializedName;
import java.util.List;
public class CartResponse {
    @SerializedName("success") public boolean success;
    @SerializedName("items")   public List<CartItem> items;
    @SerializedName("total")   public double total;
    @SerializedName("count")   public int count;
}
