package com.smarzbd.app.models;
import com.google.gson.annotations.SerializedName;
import java.util.List;
public class CategoryResponse {
    @SerializedName("success")    public boolean success;
    @SerializedName("categories") public List<Category> categories;
}
