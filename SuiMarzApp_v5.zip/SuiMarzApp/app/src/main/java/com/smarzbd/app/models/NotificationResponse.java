package com.smarzbd.app.models;
import com.google.gson.annotations.SerializedName;
import java.util.List;
public class NotificationResponse {
    @SerializedName("success")       public boolean success;
    @SerializedName("notifications") public List<AppNotification> notifications;
}
