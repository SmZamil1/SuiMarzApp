package com.smarzbd.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import com.smarzbd.app.R;
import com.smarzbd.app.activities.LoginActivity;
import com.smarzbd.app.activities.MainActivity;
import com.smarzbd.app.api.WebViewApiClient;
import com.smarzbd.app.utils.SessionManager;

public class ProfileFragment extends Fragment {
    private TextView tvName, tvEmail, tvPhone, tvInitial;
    private Button   btnLogout;
    private SessionManager session;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_profile, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);
        session  = new SessionManager(requireContext());
        tvInitial = v.findViewById(R.id.tv_avatar_initial);
        tvName    = v.findViewById(R.id.tv_name);
        tvEmail   = v.findViewById(R.id.tv_email);
        tvPhone   = v.findViewById(R.id.tv_phone);
        btnLogout = v.findViewById(R.id.btn_logout);

        String name = session.isLoggedIn() ? session.getUserName() : "Guest";
        tvName.setText(name);
        tvEmail.setText(session.isLoggedIn() ? session.getUserEmail() : "Not logged in");
        tvPhone.setText(session.isLoggedIn() && !session.getUserPhone().isEmpty() ? session.getUserPhone() : "Not set");
        tvInitial.setText(name.isEmpty() ? "G" : String.valueOf(name.charAt(0)).toUpperCase());

        v.findViewById(R.id.link_orders).setOnClickListener(x -> nav(R.id.nav_orders));
        v.findViewById(R.id.link_cart).setOnClickListener(x -> nav(R.id.nav_cart));
        v.findViewById(R.id.link_notifications).setOnClickListener(x -> nav(R.id.nav_notifications));
        btnLogout.setOnClickListener(x -> confirmLogout());
    }

    private void nav(int id) {
        if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).navigateTo(id);
    }

    private void confirmLogout() {
        new AlertDialog.Builder(requireContext())
            .setTitle("Logout").setMessage("Are you sure?")
            .setPositiveButton("Logout", (d, w) -> {
                WebViewApiClient.get().get("api/auth/logout.php", j -> {});
                session.logout();
                Intent i = new Intent(getContext(), LoginActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
            })
            .setNegativeButton("Cancel", null).show();
    }
}
