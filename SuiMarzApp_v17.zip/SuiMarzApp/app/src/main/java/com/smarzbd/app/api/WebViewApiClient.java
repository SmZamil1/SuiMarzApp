package com.smarzbd.app.api;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.smarzbd.app.utils.Constants;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Makes ALL API calls inside a real Chromium WebView via fetch().
 * InfinityFree uses TLS fingerprinting to block OkHttp.
 * WebView (real Chrome engine) is never blocked.
 */
public class WebViewApiClient {

    private static final String TAG = "WebViewApi";
    private static WebViewApiClient instance;

    private WebView  webView;
    private boolean  ready = false;
    private final AtomicInteger nextId = new AtomicInteger(0);
    private final Map<Integer, ApiCallback> callbacks = new HashMap<>();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public interface ApiCallback { void onResult(String json); }

    public static synchronized WebViewApiClient get() {
        if (instance == null) instance = new WebViewApiClient();
        return instance;
    }

    public void init(Context ctx, Runnable onReady) {
        if (ready) { mainHandler.post(onReady); return; }
        if (webView != null) return; // already initializing

        mainHandler.post(() -> {
            webView = new WebView(ctx.getApplicationContext());
            webView.getSettings().setJavaScriptEnabled(true);
            webView.getSettings().setDomStorageEnabled(true);
            webView.getSettings().setUserAgentString(
                "Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36 "
                + "(KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36");

            webView.addJavascriptInterface(new Object() {
                @JavascriptInterface
                public void result(int id, String json) {
                    Log.d(TAG, "cb[" + id + "]: " + json.substring(0, Math.min(150, json.length())));
                    ApiCallback cb;
                    synchronized (callbacks) { cb = callbacks.remove(id); }
                    if (cb != null) { final ApiCallback f = cb; mainHandler.post(() -> f.onResult(json)); }
                }
            }, "NativeBridge");

            webView.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView v, String url) {
                    Log.d(TAG, "Loaded: " + url);
                    mainHandler.postDelayed(() -> {
                        ready = true;
                        Log.d(TAG, "READY");
                        mainHandler.post(onReady);
                    }, 3000);
                }
            });

            webView.loadUrl(Constants.BASE_URL);
        });
    }

    public void post(String ep, Map<String, String> params, ApiCallback cb) {
        if (!ready) { cb.onResult(fail("Connecting...")); return; }
        int id = nextId.getAndIncrement();
        synchronized (callbacks) { callbacks.put(id, cb); }
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : params.entrySet()) {
            if (sb.length() > 0) sb.append("&");
            try { sb.append(e.getKey()).append("=").append(URLEncoder.encode(e.getValue(), "UTF-8")); }
            catch (Exception x) { sb.append(e.getKey()).append("=").append(e.getValue()); }
        }
        String js = "fetch('" + Constants.BASE_URL + ep + "',"
            + "{method:'POST',credentials:'include',"
            + "headers:{'Content-Type':'application/x-www-form-urlencoded','X-Requested-With':'XMLHttpRequest'},"
            + "body:'" + sb.toString().replace("'", "\\'") + "'})"
            + ".then(r=>r.text()).then(t=>NativeBridge.result(" + id + ",t))"
            + ".catch(e=>NativeBridge.result(" + id + ",'{\"success\":false,\"message\":\"'+e.toString()+'\"}')); void 0;";
        mainHandler.post(() -> webView.evaluateJavascript(js, null));
    }

    public void postJson(String ep, String body, ApiCallback cb) {
        if (!ready) { cb.onResult(fail("Connecting...")); return; }
        int id = nextId.getAndIncrement();
        synchronized (callbacks) { callbacks.put(id, cb); }
        String safe = body.replace("\\", "\\\\").replace("'", "\\'");
        String js = "fetch('" + Constants.BASE_URL + ep + "',"
            + "{method:'POST',credentials:'include',"
            + "headers:{'Content-Type':'application/json','Accept':'application/json','X-Requested-With':'XMLHttpRequest'},"
            + "body:'" + safe + "'})"
            + ".then(r=>r.text()).then(t=>NativeBridge.result(" + id + ",t))"
            + ".catch(e=>NativeBridge.result(" + id + ",'{\"success\":false,\"message\":\"'+e.toString()+'\"}')); void 0;";
        mainHandler.post(() -> webView.evaluateJavascript(js, null));
    }

    public void get(String ep, ApiCallback cb) {
        if (!ready) { cb.onResult(fail("Connecting...")); return; }
        int id = nextId.getAndIncrement();
        synchronized (callbacks) { callbacks.put(id, cb); }
        String js = "fetch('" + Constants.BASE_URL + ep + "',"
            + "{credentials:'include',headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest'}})"
            + ".then(r=>r.text()).then(t=>NativeBridge.result(" + id + ",t))"
            + ".catch(e=>NativeBridge.result(" + id + ",'{\"success\":false,\"message\":\"'+e.toString()+'\"}')); void 0;";
        mainHandler.post(() -> webView.evaluateJavascript(js, null));
    }

    public boolean isReady() { return ready; }

    private String fail(String m) { return "{\"success\":false,\"message\":\"" + m + "\"}"; }
}
