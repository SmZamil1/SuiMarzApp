package com.smarzbd.app.fragments;

import android.os.Bundle;
import android.view.*;
import android.widget.ProgressBar;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.*;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.gson.Gson;
import com.smarzbd.app.R;
import com.smarzbd.app.adapters.OrderAdapter;
import com.smarzbd.app.api.WebViewApiClient;
import com.smarzbd.app.models.OrderResponse;
import com.smarzbd.app.utils.SessionManager;

public class OrdersFragment extends Fragment {
    private RecyclerView rv;
    private ProgressBar pb;
    private View emptyView;
    private SwipeRefreshLayout swipe;
    private OrderAdapter adapter;
    private SessionManager session;
    private final Gson gson = new Gson();

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_orders, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);
        session   = new SessionManager(requireContext());
        pb        = v.findViewById(R.id.progress_bar);
        emptyView = v.findViewById(R.id.tv_empty);
        swipe     = v.findViewById(R.id.swipe_refresh);
        rv        = v.findViewById(R.id.rv_orders);
        swipe.setColorSchemeResources(R.color.primary);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new OrderAdapter(getContext());
        rv.setAdapter(adapter);
        swipe.setOnRefreshListener(this::load);
        if (!session.isLoggedIn()) emptyView.setVisibility(View.VISIBLE);
        else load();
    }

    private void load() {
        pb.setVisibility(View.VISIBLE);
        WebViewApiClient.get().get("api/orders/get_orders.php", json -> {
            pb.setVisibility(View.GONE);
            swipe.setRefreshing(false);
            try {
                OrderResponse r = gson.fromJson(json, OrderResponse.class);
                if (r != null && r.success && r.orders != null && !r.orders.isEmpty()) {
                    adapter.setData(r.orders);
                    emptyView.setVisibility(View.GONE);
                    rv.setVisibility(View.VISIBLE);
                } else { emptyView.setVisibility(View.VISIBLE); rv.setVisibility(View.GONE); }
            } catch (Exception e) { emptyView.setVisibility(View.VISIBLE); }
        });
    }
}
