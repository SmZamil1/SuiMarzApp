package com.smarzbd.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.Gson;
import com.smarzbd.app.R;
import com.smarzbd.app.api.WebViewApiClient;
import com.smarzbd.app.models.LoginResponse;
import com.smarzbd.app.utils.SessionManager;
import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {
    private EditText    etEmail, etPassword;
    private Button      btnLogin;
    private ProgressBar progressBar;
    private SessionManager session;
    private final Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        session     = new SessionManager(this);
        etEmail     = findViewById(R.id.et_email);
        etPassword  = findViewById(R.id.et_password);
        btnLogin    = findViewById(R.id.btn_login);
        progressBar = findViewById(R.id.progress_bar);
        TextView tvReg = findViewById(R.id.tv_register);
        btnLogin.setOnClickListener(v -> attemptLogin());
        tvReg.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
    }

    private void attemptLogin() {
        String email = etEmail.getText().toString().trim();
        String pass  = etPassword.getText().toString().trim();
        if (email.isEmpty()) { etEmail.setError("Required"); return; }
        if (pass.isEmpty())  { etPassword.setError("Required"); return; }
        setLoading(true);
        Map<String, String> p = new HashMap<>();
        p.put("email", email); p.put("password", pass);
        WebViewApiClient.get().post("api/auth/login.php", p, json -> {
            setLoading(false);
            try {
                LoginResponse r = gson.fromJson(json, LoginResponse.class);
                if (r != null && r.success) {
                    session.saveUserSession(r.userId, r.name, r.email, r.phone != null ? r.phone : "");
                    startActivity(new Intent(this, MainActivity.class));
                    finish();
                } else {
                    String msg = (r != null && r.message != null) ? r.message : "Login failed";
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Parse error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void setLoading(boolean on) {
        progressBar.setVisibility(on ? View.VISIBLE : View.GONE);
        btnLogin.setEnabled(!on);
    }
}
