package com.smarzbd.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import com.smarzbd.app.R;
import com.smarzbd.app.api.WebViewApiClient;
import com.smarzbd.app.utils.SessionManager;

public class SplashActivity extends AppCompatActivity {
    private boolean navigated = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        SessionManager session = new SessionManager(this);

        // Hard timeout 12s
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!navigated) navigate(session);
        }, 12000);

        WebViewApiClient.get().init(this, () -> {
            if (!navigated) navigate(session);
        });
    }

    private void navigate(SessionManager s) {
        if (navigated) return;
        navigated = true;
        startActivity(new Intent(this,
            s.isLoggedIn() ? MainActivity.class : LoginActivity.class));
        finish();
    }
}
