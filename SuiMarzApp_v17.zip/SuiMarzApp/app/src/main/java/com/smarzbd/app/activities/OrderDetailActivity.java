package com.smarzbd.app.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.smarzbd.app.R;
import com.smarzbd.app.api.WebViewApiClient;
import com.smarzbd.app.utils.Constants;
import java.net.URLEncoder;

public class OrderDetailActivity extends AppCompatActivity {
    private TextView tvInfo;
    private ProgressBar pb;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_order_detail);
        Toolbar tb = findViewById(R.id.toolbar);
        setSupportActionBar(tb);
        if (getSupportActionBar() != null) { getSupportActionBar().setDisplayHomeAsUpEnabled(true); getSupportActionBar().setTitle("Order Detail"); }
        tb.setNavigationOnClickListener(v -> finish());
        tvInfo = findViewById(R.id.tv_order_info);
        pb     = findViewById(R.id.progress_bar);
        int orderId = getIntent().getIntExtra(Constants.EXTRA_ORDER_ID, -1);
        if (orderId == -1) { finish(); return; }
        pb.setVisibility(View.VISIBLE);
        try {
            WebViewApiClient.get().post("api/orders/get_order_detail.php",
                java.util.Collections.singletonMap("order_id", String.valueOf(orderId)),
                json -> {
                    pb.setVisibility(View.GONE);
                    tvInfo.setText("Order #" + orderId + "\n\n" + json.substring(0, Math.min(300, json.length())));
                });
        } catch (Exception e) { pb.setVisibility(View.GONE); }
    }
}
