package com.smarzbd.app.activities;

import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import com.bumptech.glide.Glide;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.gson.Gson;
import com.smarzbd.app.R;
import com.smarzbd.app.api.WebViewApiClient;
import com.smarzbd.app.models.*;
import com.smarzbd.app.utils.Constants;
import com.smarzbd.app.utils.SessionManager;
import java.util.*;

public class ProductDetailActivity extends AppCompatActivity {
    private ImageView iv;
    private TextView tvName, tvPrice, tvOld, tvDesc, tvStock, tvSelSize;
    private Button btnCart;
    private ProgressBar pb;
    private CardView cardSizes;
    private ChipGroup chipSizes;
    private SessionManager session;
    private int productId;
    private Product current;
    private String selectedSize = "";
    private final Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_product_detail);
        Toolbar tb = findViewById(R.id.toolbar);
        setSupportActionBar(tb);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        tb.setNavigationOnClickListener(v -> finish());

        session   = new SessionManager(this);
        productId = getIntent().getIntExtra(Constants.EXTRA_PRODUCT_ID, -1);
        iv        = findViewById(R.id.iv_product);
        tvName    = findViewById(R.id.tv_name);
        tvPrice   = findViewById(R.id.tv_price);
        tvOld     = findViewById(R.id.tv_old_price);
        tvDesc    = findViewById(R.id.tv_description);
        tvStock   = findViewById(R.id.tv_stock);
        tvSelSize = findViewById(R.id.tv_selected_size);
        btnCart   = findViewById(R.id.btn_add_to_cart);
        pb        = findViewById(R.id.progress_bar);
        cardSizes = findViewById(R.id.card_sizes);
        chipSizes = findViewById(R.id.chip_group_sizes);
        btnCart.setOnClickListener(v -> addToCart());

        if (getIntent().hasExtra("product_name")) {
            Product p = new Product();
            p.id = productId;
            p.name = getIntent().getStringExtra("product_name");
            p.price = getIntent().getDoubleExtra("product_price", 0);
            p.oldPrice = getIntent().getDoubleExtra("product_old_price", 0);
            p.image = getIntent().getStringExtra("product_image");
            p.stock = getIntent().getIntExtra("product_stock", 0);
            p.description = getIntent().getStringExtra("product_desc");
            bind(p); loadSizes();
        } else { loadProduct(); }
    }

    private void loadProduct() {
        pb.setVisibility(View.VISIBLE);
        String body = "{\"product_id\":" + productId + ",\"limit\":1}";
        WebViewApiClient.get().postJson("api/get_products.php", body, json -> {
            pb.setVisibility(View.GONE);
            try {
                ProductResponse r = gson.fromJson(json, ProductResponse.class);
                if (r != null && r.products != null && !r.products.isEmpty()) { bind(r.products.get(0)); loadSizes(); }
            } catch (Exception e) {}
        });
    }

    private void loadSizes() {
        String body = "{\"product_id\":" + productId + "}";
        WebViewApiClient.get().postJson("api/get_product_sizes.php", body, json -> {
            try {
                SizesResponse r = gson.fromJson(json, SizesResponse.class);
                if (r != null && r.hasSizes && r.sizes != null && !r.sizes.isEmpty()) showSizes(r.sizes);
            } catch (Exception e) {}
        });
    }

    private void showSizes(List<String> sizes) {
        cardSizes.setVisibility(View.VISIBLE);
        chipSizes.removeAllViews();
        for (String sz : sizes) {
            Chip c = new Chip(this);
            c.setText(sz); c.setCheckable(true);
            c.setChipBackgroundColorResource(R.color.primary_light);
            c.setOnCheckedChangeListener((v, chk) -> { if (chk) { selectedSize = sz; tvSelSize.setText(sz); } });
            chipSizes.addView(c);
        }
        Chip first = (Chip) chipSizes.getChildAt(0);
        if (first != null) first.setChecked(true);
    }

    private void bind(Product p) {
        current = p;
        if (getSupportActionBar() != null) getSupportActionBar().setTitle(p.name);
        tvName.setText(p.name);
        tvPrice.setText("৳" + String.format("%.0f", p.price));
        tvDesc.setText(p.description != null && !p.description.isEmpty() ? p.description : "No description.");
        boolean ok = p.stock > 0;
        tvStock.setText(ok ? "✓ In Stock: " + p.stock : "Out of Stock");
        tvStock.setTextColor(getResources().getColor(ok ? R.color.primary : R.color.red));
        if (p.oldPrice > 0 && p.oldPrice > p.price) {
            tvOld.setVisibility(View.VISIBLE);
            tvOld.setText("৳" + String.format("%.0f", p.oldPrice));
            tvOld.setPaintFlags(tvOld.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        } else tvOld.setVisibility(View.GONE);
        if (p.image != null && !p.image.isEmpty())
            Glide.with(this).load(Constants.BASE_URL + "uploads/products/" + p.image)
                 .placeholder(R.drawable.placeholder_product).centerCrop().into(iv);
        btnCart.setEnabled(ok);
        btnCart.setText(ok ? "ADD TO CART" : "OUT OF STOCK");
    }

    private void addToCart() {
        if (!session.isLoggedIn()) { Toast.makeText(this,"Please login first",Toast.LENGTH_SHORT).show(); return; }
        if (current == null) return;
        btnCart.setEnabled(false); btnCart.setText("Adding...");
        String body = "{\"product_id\":" + current.id + ",\"quantity\":1,\"size\":\"" + selectedSize + "\"}";
        WebViewApiClient.get().postJson("api/add_to_cart.php", body, json -> {
            btnCart.setEnabled(current != null && current.stock > 0);
            btnCart.setText("ADD TO CART");
            try {
                com.smarzbd.app.models.ApiResponse r = gson.fromJson(json, com.smarzbd.app.models.ApiResponse.class);
                Toast.makeText(this, r != null && r.success ? "✓ Added to cart!" : (r != null ? r.message : "Failed"), Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "Done", Toast.LENGTH_SHORT).show(); }
        });
    }
}
