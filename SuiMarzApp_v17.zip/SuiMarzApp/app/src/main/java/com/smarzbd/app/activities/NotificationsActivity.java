package com.smarzbd.app.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.smarzbd.app.R;
import com.smarzbd.app.fragments.NotificationsFragment;

public class NotificationsActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_notifications);
        Toolbar tb = findViewById(R.id.toolbar);
        setSupportActionBar(tb);
        if (getSupportActionBar() != null) { getSupportActionBar().setTitle("Notifications"); getSupportActionBar().setDisplayHomeAsUpEnabled(true); }
        tb.setNavigationOnClickListener(v -> finish());
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new NotificationsFragment()).commit();
    }
}
