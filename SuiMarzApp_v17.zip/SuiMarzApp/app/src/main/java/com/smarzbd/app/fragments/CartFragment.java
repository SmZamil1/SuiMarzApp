package com.smarzbd.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.*;
import com.google.gson.Gson;
import com.smarzbd.app.R;
import com.smarzbd.app.activities.CheckoutActivity;
import com.smarzbd.app.activities.LoginActivity;
import com.smarzbd.app.activities.MainActivity;
import com.smarzbd.app.adapters.CartAdapter;
import com.smarzbd.app.api.WebViewApiClient;
import com.smarzbd.app.models.CartResponse;
import com.smarzbd.app.utils.SessionManager;
import java.util.List;

public class CartFragment extends Fragment {
    private RecyclerView rv;
    private TextView tvTotal;
    private View emptyView;
    private Button btnCheckout;
    private ProgressBar pb;
    private CartAdapter adapter;
    private SessionManager session;
    private final Gson gson = new Gson();

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_cart, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);
        session     = new SessionManager(requireContext());
        pb          = v.findViewById(R.id.progress_bar);
        rv          = v.findViewById(R.id.rv_cart);
        tvTotal     = v.findViewById(R.id.tv_total);
        emptyView   = v.findViewById(R.id.tv_empty);
        btnCheckout = v.findViewById(R.id.btn_checkout);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new CartAdapter(getContext(), this::loadCart);
        rv.setAdapter(adapter);
        btnCheckout.setOnClickListener(x -> {
            if (!session.isLoggedIn()) startActivity(new Intent(getContext(), LoginActivity.class));
            else startActivity(new Intent(getContext(), CheckoutActivity.class));
        });
        if (!session.isLoggedIn()) showEmpty();
        else loadCart();
    }

    @Override public void onResume() { super.onResume(); if (session != null && session.isLoggedIn()) loadCart(); }

    private void loadCart() {
        pb.setVisibility(View.VISIBLE);
        WebViewApiClient.get().get("api/cart/get_cart.php", json -> {
            pb.setVisibility(View.GONE);
            try {
                CartResponse r = gson.fromJson(json, CartResponse.class);
                if (r != null && r.success && r.items != null && !r.items.isEmpty()) {
                    adapter.setData(r.items);
                    emptyView.setVisibility(View.GONE);
                    rv.setVisibility(View.VISIBLE);
                    tvTotal.setText("৳" + String.format("%.2f", r.total));
                    btnCheckout.setEnabled(true);
                    if (getActivity() instanceof MainActivity)
                        ((MainActivity) getActivity()).setCartBadge(r.count);
                } else showEmpty();
            } catch (Exception e) { showEmpty(); }
        });
    }

    private void showEmpty() {
        emptyView.setVisibility(View.VISIBLE);
        rv.setVisibility(View.GONE);
        tvTotal.setText("৳0.00");
        btnCheckout.setEnabled(false);
    }
}
