package com.smarzbd.app.fragments;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.EditText;
import android.widget.ProgressBar;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.*;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.gson.Gson;
import com.smarzbd.app.R;
import com.smarzbd.app.activities.MainActivity;
import com.smarzbd.app.adapters.CategoryAdapter;
import com.smarzbd.app.adapters.ProductAdapter;
import com.smarzbd.app.api.WebViewApiClient;
import com.smarzbd.app.models.*;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {
    private RecyclerView rvProducts, rvCategories;
    private ProgressBar progressBar;
    private SwipeRefreshLayout swipeRefresh;
    private EditText etSearch;
    private ProductAdapter productAdapter;
    private CategoryAdapter categoryAdapter;
    private List<Product> allProducts = new ArrayList<>();
    private String selectedCat = "all";
    private final Gson gson = new Gson();

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_home, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle s) {
        super.onViewCreated(view, s);
        progressBar  = view.findViewById(R.id.progress_bar);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        etSearch     = view.findViewById(R.id.et_search);
        rvCategories = view.findViewById(R.id.rv_categories);
        rvProducts   = view.findViewById(R.id.rv_products);

        view.findViewById(R.id.btn_notification).setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity)
                ((MainActivity) getActivity()).navigateToNotifications();
        });

        rvCategories.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        categoryAdapter = new CategoryAdapter(catId -> { selectedCat = catId; loadProducts(catId); });
        rvCategories.setAdapter(categoryAdapter);

        rvProducts.setLayoutManager(new GridLayoutManager(getContext(), 2));
        productAdapter = new ProductAdapter(getContext());
        rvProducts.setAdapter(productAdapter);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override public void onTextChanged(CharSequence s, int st, int bf, int ct) { filter(s.toString()); }
        });

        swipeRefresh.setColorSchemeResources(R.color.primary);
        swipeRefresh.setOnRefreshListener(() -> { loadCategories(); loadProducts(selectedCat); });
        loadCategories();
        loadProducts("all");
    }

    private void loadCategories() {
        WebViewApiClient.get().get("api/get_categories.php", json -> {
            try {
                CategoryResponse r = gson.fromJson(json, CategoryResponse.class);
                if (r != null && r.success && r.categories != null)
                    categoryAdapter.setData(r.categories);
            } catch (Exception e) {}
        });
    }

    private void loadProducts(String cat) {
        progressBar.setVisibility(View.VISIBLE);
        String body = "{\"category\":\"" + cat + "\",\"type\":\"featured\",\"limit\":20}";
        WebViewApiClient.get().postJson("api/get_products.php", body, json -> {
            progressBar.setVisibility(View.GONE);
            swipeRefresh.setRefreshing(false);
            try {
                ProductResponse r = gson.fromJson(json, ProductResponse.class);
                if (r != null && r.success && r.products != null) {
                    allProducts = r.products;
                    productAdapter.setData(allProducts);
                }
            } catch (Exception e) {}
        });
    }

    private void filter(String q) {
        if (q.isEmpty()) { productAdapter.setData(allProducts); return; }
        List<Product> f = new ArrayList<>();
        for (Product p : allProducts)
            if (p.name != null && p.name.toLowerCase().contains(q.toLowerCase())) f.add(p);
        productAdapter.setData(f);
    }
}
