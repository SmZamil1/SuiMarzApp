package com.smarzbd.app.models;
import com.google.gson.annotations.SerializedName;
import java.util.List;
public class SizesResponse {
    @SerializedName("success")   public boolean success;
    @SerializedName("sizes")     public List<String> sizes;
    @SerializedName("has_sizes") public boolean hasSizes;
}
