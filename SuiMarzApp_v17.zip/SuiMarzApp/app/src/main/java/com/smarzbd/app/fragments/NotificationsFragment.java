package com.smarzbd.app.fragments;

import android.os.Bundle;
import android.view.*;
import android.widget.ProgressBar;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.*;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.gson.Gson;
import com.smarzbd.app.R;
import com.smarzbd.app.activities.MainActivity;
import com.smarzbd.app.adapters.NotificationAdapter;
import com.smarzbd.app.api.WebViewApiClient;
import com.smarzbd.app.models.NotificationResponse;
import com.smarzbd.app.utils.SessionManager;

public class NotificationsFragment extends Fragment {
    private RecyclerView rv;
    private ProgressBar pb;
    private View emptyView;
    private SwipeRefreshLayout swipe;
    private NotificationAdapter adapter;
    private SessionManager session;
    private final Gson gson = new Gson();

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_notifications, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);
        session   = new SessionManager(requireContext());
        pb        = v.findViewById(R.id.progress_bar);
        emptyView = v.findViewById(R.id.tv_empty);
        swipe     = v.findViewById(R.id.swipe_refresh);
        rv        = v.findViewById(R.id.rv_notifications);
        swipe.setColorSchemeResources(R.color.primary);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new NotificationAdapter();
        rv.setAdapter(adapter);
        swipe.setOnRefreshListener(this::load);
        if (!session.isLoggedIn()) emptyView.setVisibility(View.VISIBLE);
        else load();
    }

    private void load() {
        pb.setVisibility(View.VISIBLE);
        emptyView.setVisibility(View.GONE);
        WebViewApiClient.get().get("api/get_notifications.php", json -> {
            pb.setVisibility(View.GONE);
            swipe.setRefreshing(false);
            try {
                NotificationResponse r = gson.fromJson(json, NotificationResponse.class);
                if (r != null && r.success && r.notifications != null && !r.notifications.isEmpty()) {
                    adapter.setData(r.notifications);
                    rv.setVisibility(View.VISIBLE);
                    emptyView.setVisibility(View.GONE);
                    if (getActivity() instanceof MainActivity)
                        ((MainActivity) getActivity()).setNotificationBadge(0);
                } else {
                    rv.setVisibility(View.GONE);
                    emptyView.setVisibility(View.VISIBLE);
                }
            } catch (Exception e) { emptyView.setVisibility(View.VISIBLE); }
        });
    }
}
