package com.smarzbd.app.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.gson.Gson;
import com.smarzbd.app.R;
import com.smarzbd.app.api.WebViewApiClient;
import com.smarzbd.app.models.ApiResponse;
import com.smarzbd.app.utils.SessionManager;
import java.util.HashMap;
import java.util.Map;

public class CheckoutActivity extends AppCompatActivity {
    private EditText etAddress, etPhone, etNote;
    private Button btnOrder;
    private ProgressBar pb;
    private final Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_checkout);
        Toolbar tb = findViewById(R.id.toolbar);
        setSupportActionBar(tb);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        tb.setNavigationOnClickListener(v -> finish());
        etAddress = findViewById(R.id.et_address);
        etPhone   = findViewById(R.id.et_phone);
        etNote    = findViewById(R.id.et_note);
        btnOrder  = findViewById(R.id.btn_place_order);
        pb        = findViewById(R.id.progress_bar);

        // Pre-fill phone from session
        SessionManager session = new SessionManager(this);
        if (!session.getUserPhone().isEmpty()) etPhone.setText(session.getUserPhone());

        btnOrder.setOnClickListener(v -> placeOrder());
    }

    private void placeOrder() {
        String addr  = etAddress.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        if (addr.isEmpty())  { etAddress.setError("Required"); return; }
        if (phone.isEmpty()) { etPhone.setError("Required"); return; }
        pb.setVisibility(View.VISIBLE); btnOrder.setEnabled(false);
        Map<String, String> p = new HashMap<>();
        p.put("address", addr); p.put("phone", phone);
        p.put("note", etNote.getText().toString().trim());
        p.put("payment_method", "cod");
        WebViewApiClient.get().post("api/handle_payment.php", p, json -> {
            pb.setVisibility(View.GONE);
            try {
                ApiResponse r = gson.fromJson(json, ApiResponse.class);
                if (r != null && r.success) {
                    Toast.makeText(this, "✓ Order placed!", Toast.LENGTH_LONG).show();
                    finish();
                } else {
                    btnOrder.setEnabled(true);
                    Toast.makeText(this, r != null ? r.message : "Failed", Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) { btnOrder.setEnabled(true); }
        });
    }
}
