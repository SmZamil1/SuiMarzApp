package com.smarzbd.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.Gson;
import com.smarzbd.app.R;
import com.smarzbd.app.api.WebViewApiClient;
import com.smarzbd.app.models.LoginResponse;
import com.smarzbd.app.utils.SessionManager;
import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {
    private EditText etName, etEmail, etPhone, etPassword, etConfirm;
    private Button   btnReg;
    private ProgressBar pb;
    private SessionManager session;
    private final Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_register);
        session   = new SessionManager(this);
        etName    = findViewById(R.id.et_name);
        etEmail   = findViewById(R.id.et_email);
        etPhone   = findViewById(R.id.et_phone);
        etPassword= findViewById(R.id.et_password);
        etConfirm = findViewById(R.id.et_confirm_password);
        btnReg    = findViewById(R.id.btn_register);
        pb        = findViewById(R.id.progress_bar);
        TextView tvLogin = findViewById(R.id.tv_login);
        btnReg.setOnClickListener(v -> doRegister());
        tvLogin.setOnClickListener(v -> finish());
    }

    private void doRegister() {
        String name  = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String pass  = etPassword.getText().toString().trim();
        String conf  = etConfirm.getText().toString().trim();
        if (name.isEmpty())  { etName.setError("Required"); return; }
        if (email.isEmpty()) { etEmail.setError("Required"); return; }
        if (phone.isEmpty()) { etPhone.setError("Required"); return; }
        if (pass.isEmpty())  { etPassword.setError("Required"); return; }
        if (pass.length() < 6) { etPassword.setError("Min 6 chars"); return; }
        if (!pass.equals(conf)) { etConfirm.setError("Not matching"); return; }
        pb.setVisibility(View.VISIBLE); btnReg.setEnabled(false);
        Map<String, String> p = new HashMap<>();
        p.put("name", name); p.put("email", email); p.put("phone", phone);
        p.put("password", pass); p.put("confirm_password", conf);
        WebViewApiClient.get().post("api/auth/register.php", p, json -> {
            pb.setVisibility(View.GONE); btnReg.setEnabled(true);
            try {
                LoginResponse r = gson.fromJson(json, LoginResponse.class);
                if (r != null && r.success) {
                    session.saveUserSession(r.userId, r.name, r.email, r.phone != null ? r.phone : "");
                    Intent i = new Intent(this, MainActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                } else {
                    Toast.makeText(this, r != null ? r.message : "Failed", Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
