package com.smarzbd.app.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.messaging.FirebaseMessaging;
import com.smarzbd.app.R;
import com.smarzbd.app.fragments.*;
import com.smarzbd.app.utils.SessionManager;

public class MainActivity extends AppCompatActivity {
    private BottomNavigationView bottomNav;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_main);
        session   = new SessionManager(this);
        bottomNav = findViewById(R.id.bottom_nav);
        load(new HomeFragment());
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home)          { load(new HomeFragment());          return true; }
            if (id == R.id.nav_cart)          { load(new CartFragment());          return true; }
            if (id == R.id.nav_orders)        { load(new OrdersFragment());        return true; }
            if (id == R.id.nav_notifications) { load(new NotificationsFragment()); return true; }
            if (id == R.id.nav_profile)       { load(new ProfileFragment());       return true; }
            return false;
        });
        if (getIntent().getBooleanExtra("open_notifications", false))
            bottomNav.setSelectedItemId(R.id.nav_notifications);
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t -> {
            if (t.isSuccessful()) session.saveFCMToken(t.getResult());
        });
    }

    private void load(Fragment f) {
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, f).commit();
    }

    public void navigateTo(int navId) { bottomNav.setSelectedItemId(navId); }
    public void navigateToNotifications() { navigateTo(R.id.nav_notifications); }
    public void setNotificationBadge(int n) {
        if (n > 0) bottomNav.getOrCreateBadge(R.id.nav_notifications).setNumber(n);
        else bottomNav.removeBadge(R.id.nav_notifications);
    }
    public void setCartBadge(int n) {
        if (n > 0) bottomNav.getOrCreateBadge(R.id.nav_cart).setNumber(n);
        else bottomNav.removeBadge(R.id.nav_cart);
    }
}
