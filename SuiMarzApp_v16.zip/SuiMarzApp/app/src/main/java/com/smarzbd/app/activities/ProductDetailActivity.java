package com.smarzbd.app.activities;

import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;

import com.bumptech.glide.Glide;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.smarzbd.app.R;
import com.smarzbd.app.api.ApiClient;
import com.smarzbd.app.api.ApiService;
import com.smarzbd.app.models.ApiResponse;
import com.smarzbd.app.models.Product;
import com.smarzbd.app.models.ProductResponse;
import com.smarzbd.app.models.SizesResponse;
import com.smarzbd.app.utils.Constants;
import com.smarzbd.app.utils.SessionManager;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductDetailActivity extends AppCompatActivity {

    private ImageView   ivProduct;
    private TextView    tvName, tvPrice, tvOldPrice, tvDescription, tvStock, tvSelectedSize;
    private Button      btnAddToCart;
    private ProgressBar progressBar;
    private CardView    cardSizes;
    private ChipGroup  chipGroupSizes;

    private ApiService     api;
    private SessionManager session;
    private int            productId;
    private Product        currentProduct;
    private String         selectedSize = "";
    private boolean        requiresSize = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null)
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(v -> finish());

        api       = ApiClient.getService(this);
        session   = new SessionManager(this);
        productId = getIntent().getIntExtra(Constants.EXTRA_PRODUCT_ID, -1);

        ivProduct      = findViewById(R.id.iv_product);
        tvName         = findViewById(R.id.tv_name);
        tvPrice        = findViewById(R.id.tv_price);
        tvOldPrice     = findViewById(R.id.tv_old_price);
        tvDescription  = findViewById(R.id.tv_description);
        tvStock        = findViewById(R.id.tv_stock);
        tvSelectedSize = findViewById(R.id.tv_selected_size);
        btnAddToCart   = findViewById(R.id.btn_add_to_cart);
        progressBar    = findViewById(R.id.progress_bar);
        cardSizes      = findViewById(R.id.card_sizes);
        chipGroupSizes = findViewById(R.id.chip_group_sizes);

        btnAddToCart.setOnClickListener(v -> addToCart());

        if (getIntent().hasExtra("product_name")) {
            Product p    = new Product();
            p.id          = productId;
            p.name        = getIntent().getStringExtra("product_name");
            p.price       = getIntent().getDoubleExtra("product_price", 0);
            p.oldPrice    = getIntent().getDoubleExtra("product_old_price", 0);
            p.image       = getIntent().getStringExtra("product_image");
            p.stock       = getIntent().getIntExtra("product_stock", 0);
            p.description = getIntent().getStringExtra("product_desc");
            bindProduct(p);
            loadSizes();
        } else {
            loadProduct();
        }
    }

    private void loadProduct() {
        if (productId == -1) { finish(); return; }
        progressBar.setVisibility(View.VISIBLE);
        Map<String, Object> body = new HashMap<>();
        body.put("product_id", productId);
        body.put("limit", 1);
        api.getProducts(body).enqueue(new Callback<ProductResponse>() {
            @Override
            public void onResponse(Call<ProductResponse> c, Response<ProductResponse> r) {
                progressBar.setVisibility(View.GONE);
                if (r.isSuccessful() && r.body() != null && r.body().products != null
                        && !r.body().products.isEmpty()) {
                    bindProduct(r.body().products.get(0));
                    loadSizes();
                }
            }
            @Override
            public void onFailure(Call<ProductResponse> c, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(ProductDetailActivity.this, "Load failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadSizes() {
        Map<String, Object> body = new HashMap<>();
        body.put("product_id", productId);
        api.getProductSizes(body).enqueue(new Callback<SizesResponse>() {
            @Override
            public void onResponse(Call<SizesResponse> c, Response<SizesResponse> r) {
                if (r.isSuccessful() && r.body() != null && r.body().hasSizes) {
                    showSizes(r.body().sizes);
                }
            }
            @Override public void onFailure(Call<SizesResponse> c, Throwable t) {}
        });
    }

    private void showSizes(List<String> sizes) {
        if (sizes == null || sizes.isEmpty()) return;
        requiresSize = true;
        cardSizes.setVisibility(View.VISIBLE);
        chipGroupSizes.removeAllViews();

        for (String size : sizes) {
            Chip chip = new Chip(this);
            chip.setText(size);
            chip.setCheckable(true);
            chip.setChipBackgroundColorResource(R.color.primary_light);
            chip.setCheckedIconVisible(true);
            chip.setOnCheckedChangeListener((v, checked) -> {
                if (checked) {
                    selectedSize = size;
                    tvSelectedSize.setText(size);
                }
            });
            chipGroupSizes.addView(chip);
        }
        // Auto-select first size
        if (!sizes.isEmpty()) {
            Chip first = (Chip) chipGroupSizes.getChildAt(0);
            if (first != null) first.setChecked(true);
        }
    }

    private void bindProduct(Product p) {
        currentProduct = p;
        if (getSupportActionBar() != null) getSupportActionBar().setTitle(p.name);
        tvName.setText(p.name);
        tvPrice.setText("৳" + String.format("%.0f", p.price));
        tvDescription.setText(p.description != null && !p.description.isEmpty()
            ? p.description : "No description available.");

        boolean inStock = p.stock > 0;
        tvStock.setText(inStock ? "✓ In Stock: " + p.stock : "Out of Stock");
        tvStock.setTextColor(getResources().getColor(inStock ? R.color.primary : R.color.red));

        if (p.oldPrice > 0 && p.oldPrice > p.price) {
            tvOldPrice.setVisibility(View.VISIBLE);
            tvOldPrice.setText("৳" + String.format("%.0f", p.oldPrice));
            tvOldPrice.setPaintFlags(tvOldPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        } else {
            tvOldPrice.setVisibility(View.GONE);
        }

        if (p.image != null && !p.image.isEmpty()) {
            String url = Constants.BASE_URL + "uploads/products/" + p.image;
            Glide.with(this).load(url)
                 .placeholder(R.drawable.placeholder_product)
                 .error(R.drawable.placeholder_product)
                 .centerCrop().into(ivProduct);
        }

        btnAddToCart.setEnabled(inStock);
        btnAddToCart.setText(inStock ? "ADD TO CART" : "OUT OF STOCK");
    }

    private void addToCart() {
        if (!session.isLoggedIn()) {
            Toast.makeText(this, "Please login to add to cart", Toast.LENGTH_SHORT).show();
            return;
        }
        if (currentProduct == null) return;

        btnAddToCart.setEnabled(false);
        btnAddToCart.setText("Adding...");

        Map<String, Object> body = new HashMap<>();
        body.put("product_id", currentProduct.id);
        body.put("quantity",   1);
        body.put("size",       selectedSize);

        api.addToCart(body).enqueue(new Callback<ApiResponse>() {
            @Override
            public void onResponse(Call<ApiResponse> c, Response<ApiResponse> r) {
                boolean ok = r.isSuccessful() && r.body() != null && r.body().success;
                btnAddToCart.setEnabled(currentProduct != null && currentProduct.stock > 0);
                btnAddToCart.setText("ADD TO CART");
                String msg = ok ? "✓ Added to cart!" :
                    (r.body() != null && r.body().message != null ? r.body().message : "Failed");
                Toast.makeText(ProductDetailActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onFailure(Call<ApiResponse> c, Throwable t) {
                btnAddToCart.setEnabled(true);
                btnAddToCart.setText("ADD TO CART");
                Toast.makeText(ProductDetailActivity.this, "Network error", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
