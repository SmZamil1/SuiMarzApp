package com.smarzbd.app.api;

import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.smarzbd.app.utils.Constants;
import com.smarzbd.app.utils.SessionManager;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient {

    private static final String TAG = "ApiClient";
    private static Retrofit       retrofit       = null;
    private static SessionManager sessionManager = null;

    public static ApiService getService(Context context) {
        if (retrofit == null || sessionManager == null) {
            sessionManager = new SessionManager(context);

            // ── 1. Cookie interceptor ─────────────────────────────
            Interceptor cookieInterceptor = chain -> {
                String cookie = sessionManager.getSessionCookie();
                Request.Builder builder = chain.request().newBuilder();
                if (cookie != null && !cookie.isEmpty())
                    builder.addHeader("Cookie", cookie);
                Request  request  = builder.build();
                Response response = chain.proceed(request);
                String setCookie  = response.header("Set-Cookie");
                if (setCookie != null && setCookie.contains("PHPSESSID"))
                    sessionManager.saveSessionCookie(setCookie.split(";")[0]);
                return response;
            };

            // ── 2. JSON cleaner interceptor ───────────────────────
            // InfinityFree free hosting injects HTML ads into responses.
            // This interceptor strips EVERYTHING outside the first { ... last }
            // so Gson always receives clean JSON regardless of server injection.
            Interceptor jsonCleanerInterceptor = chain -> {
                Response response = chain.proceed(chain.request());
                try {
                    ResponseBody body = response.body();
                    if (body != null) {
                        String raw = body.string();
                        Log.d(TAG, "Raw response: " + raw.substring(0, Math.min(200, raw.length())));

                        // Find JSON object boundaries
                        int start = raw.indexOf('{');
                        int end   = raw.lastIndexOf('}');

                        String clean;
                        if (start != -1 && end != -1 && end > start) {
                            clean = raw.substring(start, end + 1);
                        } else {
                            // No JSON found - return safe error JSON
                            clean = "{\"success\":false,\"message\":\"Server error. Please try again.\"}";
                        }

                        Log.d(TAG, "Clean JSON: " + clean.substring(0, Math.min(200, clean.length())));

                        ResponseBody cleanBody = ResponseBody.create(
                            MediaType.parse("application/json; charset=utf-8"),
                            clean
                        );
                        return response.newBuilder().body(cleanBody).build();
                    }
                } catch (Exception e) {
                    Log.e(TAG, "JSON cleaner error: " + e.getMessage());
                }
                return response;
            };

            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(cookieInterceptor)
                    .addInterceptor(jsonCleanerInterceptor)
                    .connectTimeout(30, TimeUnit.SECONDS)
                    .readTimeout(30, TimeUnit.SECONDS)
                    .writeTimeout(30, TimeUnit.SECONDS)
                    .build();

            Gson gson = new GsonBuilder().setLenient().create();

            retrofit = new Retrofit.Builder()
                    .baseUrl(Constants.BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();
        }
        return retrofit.create(ApiService.class);
    }

    public static void reset() {
        retrofit       = null;
        sessionManager = null;
    }
}
