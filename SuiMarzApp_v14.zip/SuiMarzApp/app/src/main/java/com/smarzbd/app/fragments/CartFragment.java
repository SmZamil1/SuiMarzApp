package com.smarzbd.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.smarzbd.app.R;
import com.smarzbd.app.activities.CheckoutActivity;
import com.smarzbd.app.activities.LoginActivity;
import com.smarzbd.app.activities.MainActivity;
import com.smarzbd.app.adapters.CartAdapter;
import com.smarzbd.app.api.ApiClient;
import com.smarzbd.app.api.ApiService;
import com.smarzbd.app.models.CartItem;
import com.smarzbd.app.models.CartResponse;
import com.smarzbd.app.utils.SessionManager;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartFragment extends Fragment {

    private RecyclerView rvCart;
    private TextView     tvTotal;
    private View         emptyView;
    private Button       btnCheckout;
    private ProgressBar  progressBar;
    private CartAdapter  cartAdapter;
    private ApiService   api;
    private SessionManager session;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cart, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        api         = ApiClient.getService(requireContext());
        session     = new SessionManager(requireContext());
        progressBar = view.findViewById(R.id.progress_bar);
        rvCart      = view.findViewById(R.id.rv_cart);
        tvTotal     = view.findViewById(R.id.tv_total);
        emptyView   = view.findViewById(R.id.tv_empty);
        btnCheckout = view.findViewById(R.id.btn_checkout);

        rvCart.setLayoutManager(new LinearLayoutManager(getContext()));
        cartAdapter = new CartAdapter(getContext(), this::onItemRemoved);
        rvCart.setAdapter(cartAdapter);

        btnCheckout.setOnClickListener(v -> {
            if (!session.isLoggedIn()) {
                startActivity(new Intent(getContext(), LoginActivity.class));
            } else {
                startActivity(new Intent(getContext(), CheckoutActivity.class));
            }
        });

        if (!session.isLoggedIn()) {
            showEmpty();
        } else {
            loadCart();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (session != null && session.isLoggedIn()) loadCart();
    }

    private void loadCart() {
        progressBar.setVisibility(View.VISIBLE);
        api.getCart().enqueue(new Callback<CartResponse>() {
            @Override
            public void onResponse(Call<CartResponse> call, Response<CartResponse> r) {
                progressBar.setVisibility(View.GONE);
                if (r.isSuccessful() && r.body() != null && r.body().success) {
                    List<CartItem> items = r.body().items;
                    if (items != null && !items.isEmpty()) {
                        cartAdapter.setData(items);
                        emptyView.setVisibility(View.GONE);
                        rvCart.setVisibility(View.VISIBLE);
                        tvTotal.setText("৳" + String.format("%.2f", r.body().total));
                        btnCheckout.setEnabled(true);
                        if (getActivity() instanceof MainActivity)
                            ((MainActivity) getActivity()).setCartBadge(r.body().count);
                    } else {
                        showEmpty();
                    }
                } else {
                    showEmpty();
                }
            }
            @Override
            public void onFailure(Call<CartResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(getContext(), "Failed to load cart", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void onItemRemoved() { loadCart(); }

    private void showEmpty() {
        emptyView.setVisibility(View.VISIBLE);
        rvCart.setVisibility(View.GONE);
        tvTotal.setText("৳0.00");
        btnCheckout.setEnabled(false);
        if (getActivity() instanceof MainActivity)
            ((MainActivity) getActivity()).setCartBadge(0);
    }
}
