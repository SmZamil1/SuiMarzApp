package com.smarzbd.app.api;

import com.smarzbd.app.models.ApiResponse;
import com.smarzbd.app.models.CartResponse;
import com.smarzbd.app.models.CategoryResponse;
import com.smarzbd.app.models.LoginResponse;
import com.smarzbd.app.models.NotificationResponse;
import com.smarzbd.app.models.OrderResponse;
import com.smarzbd.app.models.ProductResponse;

import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiService {

    // Products (server uses json_decode(php://input) → send @Body JSON)
    @POST("api/get_products.php")
    Call<ProductResponse> getProducts(@Body Map<String, Object> body);

    @GET("api/get_all_products.php")
    Call<ProductResponse> getAllProducts();

    // Categories
    @GET("api/get_categories.php")
    Call<CategoryResponse> getCategories();

    // Notifications
    @GET("api/get_notifications.php")
    Call<NotificationResponse> getNotifications();

    // Auth (FORM data)
    @FormUrlEncoded
    @POST("api/auth/login.php")
    Call<LoginResponse> login(@FieldMap Map<String, String> fields);

    @FormUrlEncoded
    @POST("api/auth/register.php")
    Call<LoginResponse> register(@FieldMap Map<String, String> fields);

    @GET("api/auth/logout.php")
    Call<ApiResponse> logout();

    @GET("api/auth/profile.php")
    Call<LoginResponse> getProfile();

    // Cart — server uses json_decode(php://input) → send @Body JSON
    @POST("api/add_to_cart.php")
    Call<ApiResponse> addToCart(@Body Map<String, Object> body);

    @GET("api/cart/get_cart.php")
    Call<CartResponse> getCart();

    @FormUrlEncoded
    @POST("api/cart/remove_item.php")
    Call<ApiResponse> removeFromCart(@FieldMap Map<String, String> fields);

    // Orders
    @GET("api/orders/get_orders.php")
    Call<OrderResponse> getOrders();

    @FormUrlEncoded
    @POST("api/orders/get_order_detail.php")
    Call<ApiResponse> getOrderDetail(@FieldMap Map<String, String> fields);

    // FCM Token
    @FormUrlEncoded
    @POST("api/save_fcm_token.php")
    Call<ApiResponse> saveFCMToken(@FieldMap Map<String, String> fields);

    // Payment
    @GET("api/get_payment_settings.php")
    Call<ApiResponse> getPaymentSettings();

    @FormUrlEncoded
    @POST("api/handle_payment.php")
    Call<ApiResponse> handlePayment(@FieldMap Map<String, String> fields);

    @FormUrlEncoded
    @POST("api/get_shipping_fee.php")
    Call<ApiResponse> getShippingFee(@FieldMap Map<String, String> fields);

    @FormUrlEncoded
    @POST("api/send_contact.php")
    Call<ApiResponse> sendContact(@FieldMap Map<String, String> fields);
}
