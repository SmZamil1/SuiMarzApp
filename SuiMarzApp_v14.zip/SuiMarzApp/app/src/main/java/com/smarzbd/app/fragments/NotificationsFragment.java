package com.smarzbd.app.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.smarzbd.app.R;
import com.smarzbd.app.activities.MainActivity;
import com.smarzbd.app.adapters.NotificationAdapter;
import com.smarzbd.app.api.ApiClient;
import com.smarzbd.app.api.ApiService;
import com.smarzbd.app.models.AppNotification;
import com.smarzbd.app.models.NotificationResponse;
import com.smarzbd.app.utils.SessionManager;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NotificationsFragment extends Fragment {

    private RecyclerView       rvNotifications;
    private ProgressBar        progressBar;
    private View               emptyView;
    private SwipeRefreshLayout swipeRefresh;
    private NotificationAdapter adapter;
    private ApiService          api;
    private SessionManager      session;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_notifications, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        super.onViewCreated(view, state);
        api          = ApiClient.getService(requireContext());
        session      = new SessionManager(requireContext());
        progressBar  = view.findViewById(R.id.progress_bar);
        emptyView    = view.findViewById(R.id.tv_empty);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        rvNotifications = view.findViewById(R.id.rv_notifications);

        swipeRefresh.setColorSchemeResources(R.color.primary);
        rvNotifications.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new NotificationAdapter();
        rvNotifications.setAdapter(adapter);

        swipeRefresh.setOnRefreshListener(this::loadNotifications);
        loadNotifications();
    }

    private void loadNotifications() {
        if (!session.isLoggedIn()) {
            emptyView.setVisibility(View.VISIBLE);
            rvNotifications.setVisibility(View.GONE);
            return;
        }
        progressBar.setVisibility(View.VISIBLE);
        emptyView.setVisibility(View.GONE);

        api.getNotifications().enqueue(new Callback<NotificationResponse>() {
            @Override
            public void onResponse(Call<NotificationResponse> c, Response<NotificationResponse> r) {
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
                if (r.isSuccessful() && r.body() != null && r.body().success) {
                    List<AppNotification> list = r.body().notifications;
                    if (list != null && !list.isEmpty()) {
                        adapter.setData(list);
                        rvNotifications.setVisibility(View.VISIBLE);
                        emptyView.setVisibility(View.GONE);
                        if (getActivity() instanceof MainActivity)
                            ((MainActivity) getActivity()).setNotificationBadge(0);
                    } else {
                        rvNotifications.setVisibility(View.GONE);
                        emptyView.setVisibility(View.VISIBLE);
                    }
                }
            }
            @Override
            public void onFailure(Call<NotificationResponse> c, Throwable t) {
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
            }
        });
    }
}
