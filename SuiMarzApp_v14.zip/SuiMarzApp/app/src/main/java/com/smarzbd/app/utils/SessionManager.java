package com.smarzbd.app.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {

    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;

    // Extra key for InfinityFree challenge cookies
    private static final String KEY_CHALLENGE_COOKIES = "challenge_cookies";

    public SessionManager(Context context) {
        prefs  = context.getSharedPreferences(Constants.PREF_NAME, Context.MODE_PRIVATE);
        editor = prefs.edit();
    }

    public void saveUserSession(int userId, String name, String email, String phone) {
        editor.putBoolean(Constants.KEY_IS_LOGGED_IN, true);
        editor.putInt(Constants.KEY_USER_ID, userId);
        editor.putString(Constants.KEY_USER_NAME, name);
        editor.putString(Constants.KEY_USER_EMAIL, email);
        editor.putString(Constants.KEY_USER_PHONE, phone);
        editor.apply();
    }

    public boolean isLoggedIn() {
        return prefs.getBoolean(Constants.KEY_IS_LOGGED_IN, false);
    }

    public int getUserId() {
        return prefs.getInt(Constants.KEY_USER_ID, -1);
    }

    public String getUserName() {
        return prefs.getString(Constants.KEY_USER_NAME, "");
    }

    public String getUserEmail() {
        return prefs.getString(Constants.KEY_USER_EMAIL, "");
    }

    public String getUserPhone() {
        return prefs.getString(Constants.KEY_USER_PHONE, "");
    }

    public void saveFCMToken(String token) {
        editor.putString(Constants.KEY_FCM_TOKEN, token);
        editor.apply();
    }

    public String getFCMToken() {
        return prefs.getString(Constants.KEY_FCM_TOKEN, "");
    }

    // PHPSESSID from PHP login response
    public void saveSessionCookie(String cookie) {
        editor.putString(Constants.KEY_SESSION_COOKIE, cookie);
        editor.apply();
    }

    public String getSessionCookie() {
        return prefs.getString(Constants.KEY_SESSION_COOKIE, "");
    }

    // InfinityFree bypass cookies (from WebView challenge)
    public void saveChallengeCookies(String cookies) {
        editor.putString(KEY_CHALLENGE_COOKIES, cookies);
        editor.apply();
    }

    public String getChallengeCookies() {
        return prefs.getString(KEY_CHALLENGE_COOKIES, "");
    }

    // Combined cookies: challenge + PHP session
    public String getAllCookies() {
        String challenge = getChallengeCookies();
        String session   = getSessionCookie();
        if (challenge.isEmpty()) return session;
        if (session.isEmpty())   return challenge;
        return challenge + "; " + session;
    }

    public void logout() {
        String challengeCookies = getChallengeCookies(); // keep challenge cookies
        editor.clear();
        editor.apply();
        // Restore challenge cookies after logout so app still works
        if (!challengeCookies.isEmpty()) {
            saveChallengeCookies(challengeCookies);
        }
    }
}
