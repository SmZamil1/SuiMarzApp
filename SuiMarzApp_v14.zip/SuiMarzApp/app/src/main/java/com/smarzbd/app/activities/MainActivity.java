package com.smarzbd.app.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.messaging.FirebaseMessaging;
import com.smarzbd.app.R;
import com.smarzbd.app.fragments.CartFragment;
import com.smarzbd.app.fragments.HomeFragment;
import com.smarzbd.app.fragments.NotificationsFragment;
import com.smarzbd.app.fragments.OrdersFragment;
import com.smarzbd.app.fragments.ProfileFragment;
import com.smarzbd.app.utils.SessionManager;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView bottomNav;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        session   = new SessionManager(this);
        bottomNav = findViewById(R.id.bottom_nav);
        loadFragment(new HomeFragment());
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home)          { loadFragment(new HomeFragment());          return true; }
            if (id == R.id.nav_cart)          { loadFragment(new CartFragment());          return true; }
            if (id == R.id.nav_orders)        { loadFragment(new OrdersFragment());        return true; }
            if (id == R.id.nav_notifications) { loadFragment(new NotificationsFragment()); return true; }
            if (id == R.id.nav_profile)       { loadFragment(new ProfileFragment());       return true; }
            return false;
        });
        if (getIntent().getBooleanExtra("open_notifications", false))
            bottomNav.setSelectedItemId(R.id.nav_notifications);
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t -> {
            if (t.isSuccessful()) session.saveFCMToken(t.getResult());
        });
    }

    private void loadFragment(Fragment f) {
        getSupportFragmentManager().beginTransaction()
            .replace(R.id.fragment_container, f).commit();
    }

    public void navigateToNotifications() {
        bottomNav.setSelectedItemId(R.id.nav_notifications);
    }

    public void setNotificationBadge(int count) {
        if (count > 0) bottomNav.getOrCreateBadge(R.id.nav_notifications).setNumber(count);
        else           bottomNav.removeBadge(R.id.nav_notifications);
    }

    public void setCartBadge(int count) {
        if (count > 0) bottomNav.getOrCreateBadge(R.id.nav_cart).setNumber(count);
        else           bottomNav.removeBadge(R.id.nav_cart);
    }
}
