package com.smarzbd.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.smarzbd.app.R;
import com.smarzbd.app.activities.LoginActivity;
import com.smarzbd.app.activities.MainActivity;
import com.smarzbd.app.api.ApiClient;
import com.smarzbd.app.api.ApiService;
import com.smarzbd.app.models.ApiResponse;
import com.smarzbd.app.utils.SessionManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileFragment extends Fragment {

    private TextView tvName, tvEmail, tvPhone, tvAvatarInitial;
    private Button   btnLogout;
    private SessionManager session;
    private ApiService     api;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle state) {
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        super.onViewCreated(view, state);
        session  = new SessionManager(requireContext());
        api      = ApiClient.getService(requireContext());

        tvAvatarInitial = view.findViewById(R.id.tv_avatar_initial);
        tvName          = view.findViewById(R.id.tv_name);
        tvEmail         = view.findViewById(R.id.tv_email);
        tvPhone         = view.findViewById(R.id.tv_phone);
        btnLogout       = view.findViewById(R.id.btn_logout);

        if (session.isLoggedIn()) {
            String name = session.getUserName();
            tvName.setText(name);
            tvEmail.setText(session.getUserEmail());
            tvPhone.setText(session.getUserPhone().isEmpty() ? "Not set" : session.getUserPhone());
            // Set initial letter in avatar
            if (!name.isEmpty())
                tvAvatarInitial.setText(String.valueOf(name.charAt(0)).toUpperCase());
        } else {
            tvName.setText("Guest");
            tvEmail.setText("Not logged in");
            tvPhone.setText("");
            tvAvatarInitial.setText("G");
        }

        // Quick link navigation
        view.findViewWithTag("orders_link");
        setupQuickLinks(view);

        btnLogout.setOnClickListener(v -> confirmLogout());
    }

    private void setupQuickLinks(View view) {
        // Find LinearLayouts by position (3rd, 5th, 7th child in the quick links card)
        // Simpler: just navigate on click if we find the nav host
        View card = view.findViewWithTag("quick_links");
    }

    private void confirmLogout() {
        new AlertDialog.Builder(requireContext())
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Yes, Logout", (d, w) -> performLogout())
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void performLogout() {
        api.logout().enqueue(new Callback<ApiResponse>() {
            @Override public void onResponse(Call<ApiResponse> c, Response<ApiResponse> r) {}
            @Override public void onFailure(Call<ApiResponse> c, Throwable t) {}
        });
        session.logout();
        ApiClient.reset();
        Intent intent = new Intent(getContext(), LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}
