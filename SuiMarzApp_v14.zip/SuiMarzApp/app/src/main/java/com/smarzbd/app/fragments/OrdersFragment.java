package com.smarzbd.app.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.smarzbd.app.R;
import com.smarzbd.app.adapters.OrderAdapter;
import com.smarzbd.app.api.ApiClient;
import com.smarzbd.app.api.ApiService;
import com.smarzbd.app.models.Order;
import com.smarzbd.app.models.OrderResponse;
import com.smarzbd.app.utils.SessionManager;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OrdersFragment extends Fragment {

    private RecyclerView       rvOrders;
    private ProgressBar        progressBar;
    private View               emptyView;
    private SwipeRefreshLayout swipeRefresh;
    private OrderAdapter       orderAdapter;
    private ApiService         api;
    private SessionManager     session;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_orders, c, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        super.onViewCreated(view, state);
        api          = ApiClient.getService(requireContext());
        session      = new SessionManager(requireContext());
        progressBar  = view.findViewById(R.id.progress_bar);
        emptyView    = view.findViewById(R.id.tv_empty);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        rvOrders     = view.findViewById(R.id.rv_orders);

        swipeRefresh.setColorSchemeResources(R.color.primary);
        rvOrders.setLayoutManager(new LinearLayoutManager(getContext()));
        orderAdapter = new OrderAdapter(getContext());
        rvOrders.setAdapter(orderAdapter);

        swipeRefresh.setOnRefreshListener(this::loadOrders);

        if (!session.isLoggedIn()) {
            emptyView.setVisibility(View.VISIBLE);
        } else {
            loadOrders();
        }
    }

    private void loadOrders() {
        progressBar.setVisibility(View.VISIBLE);
        api.getOrders().enqueue(new Callback<OrderResponse>() {
            @Override
            public void onResponse(Call<OrderResponse> c, Response<OrderResponse> r) {
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
                if (r.isSuccessful() && r.body() != null && r.body().success) {
                    List<Order> orders = r.body().orders;
                    if (orders != null && !orders.isEmpty()) {
                        orderAdapter.setData(orders);
                        emptyView.setVisibility(View.GONE);
                        rvOrders.setVisibility(View.VISIBLE);
                    } else {
                        emptyView.setVisibility(View.VISIBLE);
                        rvOrders.setVisibility(View.GONE);
                    }
                }
            }
            @Override
            public void onFailure(Call<OrderResponse> c, Throwable t) {
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
            }
        });
    }
}
