package com.smarzbd.app.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.smarzbd.app.R;
import com.smarzbd.app.activities.ProductDetailActivity;
import com.smarzbd.app.models.Product;
import com.smarzbd.app.utils.Constants;

import java.util.ArrayList;
import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHolder> {

    private final Context       context;
    private       List<Product> products = new ArrayList<>();

    public ProductAdapter(Context context) { this.context = context; }

    public void setData(List<Product> list) {
        this.products = list != null ? list : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_product, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        Product p = products.get(position);
        h.tvName.setText(p.name);
        h.tvPrice.setText("৳" + String.format("%.0f", p.price));

        if (p.oldPrice > 0 && p.oldPrice > p.price) {
            h.tvOldPrice.setVisibility(View.VISIBLE);
            h.tvOldPrice.setText("৳" + String.format("%.0f", p.oldPrice));
            h.tvOldPrice.setPaintFlags(h.tvOldPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        } else {
            h.tvOldPrice.setVisibility(View.GONE);
        }

        if (p.image != null && !p.image.isEmpty()) {
            Glide.with(context)
                 .load(Constants.BASE_URL + "uploads/products/" + p.image)
                 .placeholder(R.drawable.placeholder_product)
                 .error(R.drawable.placeholder_product)
                 .centerCrop()
                 .into(h.ivProduct);
        }

        h.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ProductDetailActivity.class);
            intent.putExtra(Constants.EXTRA_PRODUCT_ID, p.id);
            // Pass product data to avoid extra API call
            intent.putExtra("product_name",      p.name);
            intent.putExtra("product_price",     p.price);
            intent.putExtra("product_old_price", p.oldPrice);
            intent.putExtra("product_image",     p.image);
            intent.putExtra("product_stock",     p.stock);
            intent.putExtra("product_desc",      p.description);
            context.startActivity(intent);
        });
    }

    @Override public int getItemCount() { return products.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivProduct;
        TextView  tvName, tvPrice, tvOldPrice;
        ViewHolder(@NonNull View v) {
            super(v);
            ivProduct  = v.findViewById(R.id.iv_product);
            tvName     = v.findViewById(R.id.tv_name);
            tvPrice    = v.findViewById(R.id.tv_price);
            tvOldPrice = v.findViewById(R.id.tv_old_price);
        }
    }
}
