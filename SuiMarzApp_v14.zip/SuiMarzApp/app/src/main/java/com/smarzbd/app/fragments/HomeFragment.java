package com.smarzbd.app.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.smarzbd.app.R;
import com.smarzbd.app.activities.MainActivity;
import com.smarzbd.app.adapters.CategoryAdapter;
import com.smarzbd.app.adapters.ProductAdapter;
import com.smarzbd.app.api.ApiClient;
import com.smarzbd.app.api.ApiService;
import com.smarzbd.app.models.Category;
import com.smarzbd.app.models.CategoryResponse;
import com.smarzbd.app.models.Product;
import com.smarzbd.app.models.ProductResponse;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {

    private RecyclerView      rvProducts, rvCategories;
    private ProgressBar       progressBar;
    private SwipeRefreshLayout swipeRefresh;
    private EditText          etSearch;

    private ProductAdapter  productAdapter;
    private CategoryAdapter categoryAdapter;
    private ApiService      api;
    private List<Product>   allProducts = new ArrayList<>();
    private String          selectedCat = "all";

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        api          = ApiClient.getService(requireContext());
        progressBar  = view.findViewById(R.id.progress_bar);
        swipeRefresh = view.findViewById(R.id.swipe_refresh);
        etSearch     = view.findViewById(R.id.et_search);
        rvCategories = view.findViewById(R.id.rv_categories);
        rvProducts   = view.findViewById(R.id.rv_products);

        // Notification bell → navigate to notifications tab (NO new activity = no crash)
        view.findViewById(R.id.btn_notification).setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity)
                ((MainActivity) getActivity()).navigateToNotifications();
        });

        rvCategories.setLayoutManager(new LinearLayoutManager(
            getContext(), LinearLayoutManager.HORIZONTAL, false));
        categoryAdapter = new CategoryAdapter(catId -> {
            selectedCat = catId; loadProducts(catId);
        });
        rvCategories.setAdapter(categoryAdapter);

        rvProducts.setLayoutManager(new GridLayoutManager(getContext(), 2));
        productAdapter = new ProductAdapter(getContext());
        rvProducts.setAdapter(productAdapter);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override public void onTextChanged(CharSequence s, int st, int bf, int ct) {
                filterProducts(s.toString());
            }
        });

        swipeRefresh.setColorSchemeResources(R.color.primary);
        swipeRefresh.setOnRefreshListener(() -> { loadCategories(); loadProducts(selectedCat); });

        loadCategories();
        loadProducts("all");
    }

    private void loadCategories() {
        api.getCategories().enqueue(new Callback<CategoryResponse>() {
            @Override
            public void onResponse(Call<CategoryResponse> c, Response<CategoryResponse> r) {
                if (r.isSuccessful() && r.body() != null && r.body().success) {
                    List<Category> list = r.body().categories;
                    if (list != null) categoryAdapter.setData(list);
                }
            }
            @Override public void onFailure(Call<CategoryResponse> c, Throwable t) {}
        });
    }

    private void loadProducts(String catId) {
        progressBar.setVisibility(View.VISIBLE);
        Map<String, Object> body = new HashMap<>();
        body.put("category", catId);
        body.put("type", "featured");
        body.put("limit", 20);

        api.getProducts(body).enqueue(new Callback<ProductResponse>() {
            @Override
            public void onResponse(Call<ProductResponse> c, Response<ProductResponse> r) {
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
                if (r.isSuccessful() && r.body() != null && r.body().success) {
                    allProducts = r.body().products != null ? r.body().products : new ArrayList<>();
                    productAdapter.setData(allProducts);
                }
            }
            @Override
            public void onFailure(Call<ProductResponse> c, Throwable t) {
                progressBar.setVisibility(View.GONE);
                swipeRefresh.setRefreshing(false);
            }
        });
    }

    private void filterProducts(String query) {
        if (query.isEmpty()) { productAdapter.setData(allProducts); return; }
        List<Product> filtered = new ArrayList<>();
        for (Product p : allProducts) {
            if (p.name != null && p.name.toLowerCase().contains(query.toLowerCase()))
                filtered.add(p);
        }
        productAdapter.setData(filtered);
    }
}
