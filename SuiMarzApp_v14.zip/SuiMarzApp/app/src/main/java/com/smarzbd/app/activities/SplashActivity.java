package com.smarzbd.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

import com.smarzbd.app.R;
import com.smarzbd.app.utils.Constants;
import com.smarzbd.app.utils.SessionManager;

public class SplashActivity extends AppCompatActivity {

    private static final String TAG = "Splash";
    private WebView  hiddenWebView;
    private boolean  navigated = false;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        session = new SessionManager(this);

        // ── Solve InfinityFree's JavaScript challenge using a real WebView ──
        // InfinityFree serves an AES-encrypted JS challenge to non-browser clients.
        // A WebView is a real Chromium browser — it executes the JS, sets the bypass
        // cookie, and then all subsequent OkHttp requests work fine.

        hiddenWebView = new WebView(this);
        hiddenWebView.getSettings().setJavaScriptEnabled(true);
        hiddenWebView.getSettings().setDomStorageEnabled(true);
        hiddenWebView.getSettings().setUserAgentString(
            "Mozilla/5.0 (Linux; Android 11; SM-G991B) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36"
        );

        // Timeout: if challenge takes > 8 seconds, proceed anyway
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (!navigated) {
                Log.w(TAG, "Challenge timeout — proceeding anyway");
                saveCookiesAndNavigate();
            }
        }, 8000);

        hiddenWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                Log.d(TAG, "WebView loaded: " + url);
                // Give JS challenge a moment to execute and set cookies
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    String cookies = CookieManager.getInstance()
                                        .getCookie(Constants.BASE_URL);
                    Log.d(TAG, "Cookies after challenge: " + cookies);
                    if (!navigated) {
                        saveCookiesAndNavigate();
                    }
                }, 2000); // wait 2s for JS to run
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view,
                                                    WebResourceRequest req) {
                // Let WebView follow all redirects (challenge may redirect)
                return false;
            }
        });

        // Load the website root — this triggers the challenge
        hiddenWebView.loadUrl(Constants.BASE_URL);
    }

    private void saveCookiesAndNavigate() {
        if (navigated) return;
        navigated = true;

        // Extract cookies from WebView (includes challenge bypass cookies)
        String cookies = CookieManager.getInstance().getCookie(Constants.BASE_URL);
        if (cookies != null && !cookies.isEmpty()) {
            session.saveChallengeCookies(cookies);
            Log.d(TAG, "Saved challenge cookies: " + cookies);
        }

        // Destroy WebView
        hiddenWebView.stopLoading();
        hiddenWebView.destroy();

        // Navigate to app
        Intent intent;
        if (session.isLoggedIn()) {
            intent = new Intent(this, MainActivity.class);
        } else {
            intent = new Intent(this, LoginActivity.class);
        }
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (hiddenWebView != null) {
            hiddenWebView.destroy();
        }
    }
}
